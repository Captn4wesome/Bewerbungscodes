Dies ist die Engine, die meine Texas Hold'em-Turniere simuliert.
Die Ausgangssituation wird dabei stets ausgew�rfelt.

Folgende Parameter variieren dabei:
-Stackgr��e (500, 1000, 2500)
-Spieleranzahl (2-10)
-Spielertypen (RandomBot, CardChecker, LoosePlayer)

Die Anzahl der Turniere als Versuchsgr��e kann �ber die Kommandozeile angepasst werden.
Standardm��ig ist 100 eingestellt.
Der erste (und einzige) Parameter bestimmt eine andere, gew�nschte Turnieranzahl.
BITTE nur Zahlen eingeben - Parameter wird n�mlich �ber Integer.parseInt() umgewandelt.

Sobald die Simulation startet, werden die GESAMTEN Turnierverl�ufe (Spieleraktionen, gezogenen Karten,
zusammenfassende Spielerinformationen) ausgegeben.
Ganz zum Schluss findet man Statistiken, die im Laufe des Versuchs gesammelt wurden.

ANMERKUNG: Sollten die Quellen im Rahmen der Abgabe ben�tigt werden, so finden Sie diese ebenfalls im
Git-Lab-Repository; unter dem Ordner "Quellen und Daten"

ANMERKUNG 2: In weiten Phasen der Implementierung kam es bei den Versuchen zu Endlosschleifen, da eine der vielen
Flags nicht richtig gesetzt war und so die Abbruchbedingung einer Wettrunde nie erf�llt wurde.
Diese traten aber erst bei einer hohen Zahl an Turnieren auf (jenseits der 1.000). Sollte bei der
Rekonstruktion des Versuchsaufbaus eine Endlosschleife auftreten --> einfach nochmal versuchen oder die Zahl
der Turniere reduzieren.
In der aktuellsten Version konnte ich aber selbst bei einer Turnieranzahl von 3.000 keine Probleme feststellen!