/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdembots;

import java.util.Scanner;

/**
 * Hauptklasse, die den Kern der Engine stellt.
 * Kümmert sich um den eigentlichen Spielablauf, die Statistiken, Spielertypen etc. * 
 * @author Administrator
 */
public class TexasHoldemBots {
    /**
     * Speichert den Index des Spielers, der gerade am Zug ist
     */
    private static int playerInAction; //Spieler, der die nächste Aktion ausführt
    private int playerLastInAction; //Der Spieler, der die letzte Wette in der Runde gemacht hat
    private static int startingPlayers; //Anzahl der Spieler zum Start
    private int currentPlayers; //Spieler, die noch am Leben sind
    private static int startingChips; //Startchips
    private Player[] player; //Instanzen der Bots
    private static int buttonPlayer; //Spieler, der den Dealer-Button hält   
    private int smallBlindPosition = playerInAction; //Soll festhalten, wer in dieser Runde SmallBlind ist...BugFix
    private Deck deck = new Deck();
    private boolean bigBlindTookAction = false; //Soll Lücke in der While-Schleife PreFlop beheben...hält fest, ob der BigBlind PreFlop schon ne Aktion getätigt hat
    private int time = 0; //Wird benötigt, um ganz grob zu simulieren, wann das nächste BlindLevel anbrechen soll
    private int pot = 0; //Chips im Pot
    private int currentBet = 0; //Die aktuelle Wette in der aktuellen Wettrunde
    private int betNumber = 0; //Die aktuelle Anzahl der Wette in dieser Wettrunde
    private int oldBet = 0; //Die letzte Wette, die vor der aktuellen getätigt wurde; wichtig bei Re-Raises!
    private int bigBlind = 10;
    private int blindLevel = 1; //Bestimmt die Höhe der Blinds und der Ante
    private int ante = 0; //Höhe der Ante zu Beginn der Hand
    private int street = 0; //0=PreFlop; 3=Flop; 4 = Turn; 5 = River
    private Card[] communityCard = new Card[5]; //Instanzen für die fünf Gemeinschaftskarten
    private int playedHands = 1; //Anzahl der aktuellen Hände, die gespielt wurden bzw wird
    private static int currentGame = 0; //zählt die Anzahl des laufenden Spiels
    private int overflow = 0; //Übertrag, falls beim SplitPot nicht glatt geteilt werden kann...landet dann im Pot für die nächste Runde
    public static TexasHoldemBots engine = new TexasHoldemBots(); //Engine-Instanz
    
    //Stats
    //Bei den Arrays haben die verschiedenen Spielertypen (genau wie bei der Zufallsauslosung, welcher Typ zum Turnierbeginn generiert wird),
    //eine bestimmte ID: 0 = RandomBot; 1 = CardChecker; 2 = LoosePlayer
    static int[] participated = {0, 0, 0};        //wenn mind. ein Spieler dieser Instanz am Tournament teilnimmt --> ++
    static int[] won = {0, 0, 0};                 //++, wenn bestimmter Spielertyp gewinnt
    static int opponents = 0;                  //gesamte Anzahl der Gegenspieler (für Durchschnitt benötigt)
    static int[][] knockedPlayerOut = {{0,0,0},  //hält fest, wie oft ein Spielertyp einen jeweils anderen Spielertyp ausgeknockt hat
                                {0,0,0},
                                {0,0,0}};
    static int[][] beenKnockedOut =   {{0,0,0},  //und wie oft er von dieser ausgeknockt wurde
                                {0,0,0},
                                {0,0,0}};
    static int handsPlayed = 0;             //Anzahl der gesamten Hände
    static int levelUps = 0;                //Anzahl der Levelanstiege gesamt (für Hände/Level nützlich)
    
    //Command arguments
    private static int totalNumberOfGames = 100; //Anzahl Tournaments
    private static int matchHistoryOutput = 1; //Matchverlauf --> 0 = nur Konsole; 1 = nur File history.txt; >=2 = beides
    private static int statsOutput = 0; //Sollen Statistiken ausgespuckt werden? 0=nein; größer=ja, in stats.txt
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args){
        //Kommandozeilenparameter werden eingelesen: TexasHoldemBots #games stats history
        /*Scanner scanner = new Scanner(System.in);
        if(scanner.hasNextInt()){
            totalNumberOfGames = scanner.nextInt();
            if(scanner.hasNextInt()){
                statsOutput = scanner.nextInt();
                if(scanner.hasNextInt()){
                    matchHistoryOutput = scanner.nextInt();
                }else{
                    System.err.println("Der dritte Parameter (history) hat keinen gültigen Wert (0=nur Konsole; 1=nur Datei in history.txt; größer=beides); nur Dateiausgabe wurde ausgewählt!");
                }
            }else{
                System.err.println("Der zweite Parameter (stats) hat keinen gültigen Wert (0=nein; größer=ja); Keine Statistikausgabe!");
            }
        }else{
            System.err.println("Der erste Parameter (nrGames) ist keine gültige Zahl; Standardwert von 100 wird genommen!");
        }*/
        int gameNumber;
        if(args.length > 0){
            String games = args[0];
            gameNumber = Integer.parseInt(games);
            if(gameNumber > 0){
                totalNumberOfGames = gameNumber;
            }else{
                System.out.println("Ungültige Parametereingabe - Fahre mit Standard von 100 Turnieren fort.");
            }
        }else{
            System.out.println("Ungültige Parametereingabe - Fahre mit Standard von 100 Turnieren fort.");
        }
        System.out.println("Hello Players");
        while(currentGame < totalNumberOfGames){
            currentGame++;
            System.out.println("");
            System.out.println("SPIEL "+currentGame+"!!!!!!");
            System.out.println("");
            engine = new TexasHoldemBots();
            engine.startGame();
        }
        reportStats();
        System.out.println("Simulation erfolgreich abgeschlossen!");
    }
    /**
     * Startet ein neues Turnier mit zufälligen Startchips (50, 100 oder 250 BigBlinds)
     * und einem zufälligen Starterfeld von 2-10 Spieler an einem Tisch.
     * Wickelt das Turnier so lange ab, bis der Sieger feststeht.
     */
    public void startGame(){
        //Hier wird zufällig der Startstack bestimmt; 50, 100 oder 250 BigBlinds      
        double i = Math.random();        
        if(i<0.333){
            startingChips = 500;
        }else if(i<0.667){
            startingChips = 1000;
        }else{
            startingChips = 2500;
        }
        //Hier werden die Anzahl der Spielertypen getrackt
        int trackRandomBot = 0, trackCardChecker = 0, trackLoosePlayer = 0;
        
        //Startspieler: 2-10, auch durch Zufall bestimmt
        startingPlayers = (int) (Math.random() * 8 + 2);
        //Spielerinstanzen kreieren
        player = new Player[startingPlayers];
        for(int j = 0; j < startingPlayers; j++){
            int type = ((int)(Math.random()*3));//Hier wird der Spielertyp ermittelt
            switch(type){
                case 0:
                    player[j] = new Player(startingChips);
                    trackRandomBot ++;
                    break;
                case 1:
                    player[j] = new CardChecker(startingChips);
                    trackCardChecker ++;
                    break;
                case 2:
                    player[j] = new LoosePlayer(startingChips);
                    trackLoosePlayer ++;
                    break;
                default:
                    player[j] = new Player(startingChips);
                    trackRandomBot ++;
            }            
        }
        //Statistik, die die teilnehmenden Spieler trackt, wird geupdated
        if(trackRandomBot > 0){participated[0]++;}
        if(trackCardChecker > 0){participated[1]++;}
        if(trackLoosePlayer > 0){participated[2]++;}
        opponents = opponents + startingPlayers - 1;

        //CommunityCards als null initialisieren (da noch keine Gemeinschaftskarten auf dem Tisch)
        for(int c = 0; c < 5; c++){
           communityCard[c] = null;
        }
        //Zufälliger Startspieler
        buttonPlayer = (int) (Math.random() * startingPlayers);
        //Gibt Infos über Spieleranzahl, Startchips und Startspieler aus
        System.out.println("Anzahl Startchips: "+startingChips);
        System.out.println("Anzahl Spieler: "+player.length);
        System.out.println("Die Kontrahenten:");
        for(int z = 0; z < startingPlayers; z++){
            System.out.println("Spieler "+z+" ("+player[z].getTypeName()+")");
        }
        System.out.println("");
        System.out.println("StartButton: "+buttonPlayer);
        
        //So lange es mehr als einen Spieler gibt, läuft die Partie weiter
        while(this.getPlayersInGame() > 1){
            this.dealHoleCards();   //verteilt Handkarten an alle lebenden Spielern
            this.playPreFlop();     //Spielt Pre-Flop aus
            //Falls mehr als ein Spieler noch in der Hand ist, wird mit dem Flop fortgefahren
            System.out.println("Spieler übrig: "+getPlayersInHand());
            if(getPlayersInHand() > 1){
               this.playFlop(); 
            }
            //...dann mit dem Turn...
            if(getPlayersInHand() > 1){
               this.playTurn(); 
            }
            //....und zum Schluss kommt der River.
            if(getPlayersInHand() > 1){
               this.playRiver(); 
            }
            //Sobald die Wettrunde vorbei ist (unabhängig davon, wann abgebraochen wurde) wird alles abgewickelt, damit
            //eine neue Wettrunde gestartet werden kann
            this.resetForNewRound();
        }
        //Gewinner wird getrackt
        this.nextPlayer();
        System.out.println(""+player[playerInAction].getClass().getName());
        switch(player[playerInAction].getClass().getName()){
            case "texasholdembots.CardChecker":     won[1]++;
                                                    break;
            case "texasholdembots.LoosePlayer":     won[2]++;
                                                    break;
            default:    won[0]++;
        }
    }
    /**
     * Gibt den Dealer-Button an den nächsten, noch im Turnier befindlichen Spieler.
     */
    public void passButton(){
        //gibt den Button an den nächsten Spieler
        TexasHoldemBots.buttonPlayer ++;
        if(buttonPlayer>=startingPlayers){
            buttonPlayer = 0;
        }
        //falls der Spieler schon ausgeschieden ist, ist er natürlich nicht im Button
        while(player[buttonPlayer].getIsAlive() == false){
            TexasHoldemBots.buttonPlayer ++;
            if(buttonPlayer>=startingPlayers){
                buttonPlayer = 0;
            }
        }           
    }
    /**
     * Teilt je zwei Handkarten an alle noch teilnehmenden Spieler aus.
     */
    public void dealHoleCards(){
        
        //Erste HoleCard wird verteilt, an alle noch, lebende Spieler
        for(int i = buttonPlayer+1; i != buttonPlayer; i++){            
            if(i>=startingPlayers){
                i = 0;
            }
            if(this.player[i].getIsAlive() == true){ //jeder, der noch lebt, kriegt dann eine HoleCard
                player[i].setHoleOne(this.drawCard());
            }
            //Hier gibt es einen Bug, der eine Endlosschleife verursacht, wenn Spieler 0
            //gerade im Button ist....dieser Block sorgt dafür, dass die Abbruchbedingung
            //erreicht wird
            if(buttonPlayer == 0 && i == 0){
                i = -1;
            }
        }
        if(buttonPlayer!=0){
            player[buttonPlayer].setHoleOne(this.drawCard());  
        }
        
        //Und nun die zweite
        for(int j = buttonPlayer+1; j != buttonPlayer; j++){
            if(j>=startingPlayers){
                j = 0;
            }
            if(this.player[j].getIsAlive() == true){ //jeder, der noch lebt, kriegt dann eine HoleCard
                player[j].setHoleTwo(this.drawCard());              
                System.out.println("Spieler "+j+" zieht: "+player[j].getHoleOne().getSuitSymbol()+player[j].getHoleOne().getActualValue()+"|"+player[j].getHoleTwo().getSuitSymbol()+player[j].getHoleTwo().getActualValue());
            }
            //Hier gibt es einen Bug, der eine Endlosschleife verursacht, wenn Spieler 0
            //gerade im Button ist....dieser Block sorgt dafür, dass die Abbruchbedingung
            //erreicht wird
            if(buttonPlayer == 0 && j == 0){
                j = -1;
            }
        }
        if(buttonPlayer!=0){
            player[buttonPlayer].setHoleTwo(this.drawCard());
            System.out.println("Spieler "+buttonPlayer+" zieht: "+player[buttonPlayer].getHoleOne().getSuitSymbol()+player[buttonPlayer].getHoleOne().getActualValue()+"|"+player[buttonPlayer].getHoleTwo().getSuitSymbol()+player[buttonPlayer].getHoleTwo().getActualValue());
        }
        
        
    }
    
    /**
     * Zieht eine zufällige Karte und markiert diese in der Klasse "Deck" als gezogen.
     * @return Ein Objekt vom Typ Karte mit zufälligem Wert und Farbe.
     */
    public Card drawCard(){
        int randValue, randSuit;
        Card randCard;
        while(true){
            randValue = ((int)(Math.random() * 13));
            randSuit = ((int)(Math.random() * 4));
            if(deck.getCardAvailable(randSuit, randValue) == true){
                deck.setCardUsed(randSuit, randValue);
                randCard = new Card(randSuit, randValue);
                return randCard;
            }
        }
    }
    /**
     * Gibt die Aktion an den nächsten Spieler weiter, der eine Aktion ausführen darf.
     */
    public void nextPlayer(){
        /*if(this.getPlayerInAction() == this.getPlayersAllIn() || this.getPlayerInAction() == this.getPlayersAllIn() + 1){
            this.nextPlayerForAllInMethod();
            return;
        }*/
        //gibt die Action an den nächsten Spieler
        TexasHoldemBots.playerInAction ++;
        if(playerInAction>=startingPlayers){
            playerInAction = 0;
        }
        //falls der Spieler schon ausgeschieden ist, ist er natürlich nicht in Action...selbiges gilt, wenn er schon AllIn ist
        while(player[playerInAction].getIsAlive() == false || player[playerInAction].getIsInGame() == false || player[playerInAction].getAllIn() == true){
            if(player[playerInAction].getAllIn() == true && playerInAction == playerLastInAction){
                System.out.println("AllInner war zuletzt dran, also Abbruch!");
                return;
            }
            
            TexasHoldemBots.playerInAction ++;
            if(playerInAction>=startingPlayers){
                playerInAction = 0;            
            }
            
        }  
    }
    /**
     * Hilfsmethode, die eine Endlosschleife beenden soll, wenn gerade der All-In-Showdown abgewickelt wird,
     * da sonst wegen den ODER-Fall mit "allIn == true" (der im normalem Spielverlauf sinnvoll ist) endlos läuft,
     * falls der letzte Spieler ebenfalls All-In gegangen ist
     *
     */
    public void nextPlayerForAllInMethod(){
        //gibt die Action an den nächsten Spieler
        TexasHoldemBots.playerInAction ++;
        if(playerInAction>=startingPlayers){
            playerInAction = 0;
        }
        //falls der Spieler schon ausgeschieden ist, ist er natürlich nicht in Action...selbiges gilt, wenn er schon AllIn ist
        while(player[playerInAction].getIsAlive() == false || player[playerInAction].getIsInGame() == false){
            if(player[playerInAction].getAllIn() == true && playerInAction == playerLastInAction){
                System.out.println("AllInner war zuletzt dran, also Abbruch!");
                return;
            }
            
            TexasHoldemBots.playerInAction ++;
            if(playerInAction>=startingPlayers){
                playerInAction = 0;            
            }
            
        }  
    }
    
    /**
     * Dies ist lediglich eine Hilfsmethode, die einfach nur zum nächsten Spieler springt;
     * Hat keine spielbedeutende Funktion, hebt aber die Endlosschleife auf, wenn der letzte Nicht-All-In-Spieler foldet
     * und this.nextPlayer() keinen neuen Spieler findet und so endlos sucht...
     */
    public void skipToAllInPlayer(){
        //gibt die Action an den nächsten Spieler
        TexasHoldemBots.playerInAction ++;
        if(playerInAction>=startingPlayers){
            playerInAction = 0;
        }
        //falls der Spieler NICHT All-In ist
        while(player[playerInAction].getAllIn() == false){            
            TexasHoldemBots.playerInAction ++;
            if(playerInAction>=startingPlayers){
                playerInAction = 0;            
            }            
        }
    }
    /**
     * Hilfsmethode, die zum nächsten Spieler führt, der in der Hand ist (auch, wenn er All-In ist und somit keine Aktion ausführen kann).
     * Essenziell, wenn im Showdown die Gewinnerhände ermittelt werden müssen.
     */
    public void nextHand(){
        //betrachtet nächste Hand (Player in Action ersetzt für den Fall die eigentliche Funktion und betrachtet nur im Showdown ausnahmsweise ALLE aktiven Hände)
        TexasHoldemBots.playerInAction ++;
        if(playerInAction>=startingPlayers){
            playerInAction = 0;
        }
        //falls der Spieler schon ausgeschieden ist, ist er natürlich nicht in Action...hier findet der AllIn-Fall aber seine Ausnahme
        while(player[playerInAction].getIsAlive() == false || player[playerInAction].getIsInGame() == false){
            TexasHoldemBots.playerInAction ++;
            if(playerInAction>=startingPlayers){
                playerInAction = 0;            
            }
            
        }  
    }
    /**
     * Wickelt den kompletten Pre-Flop ab.
     */
    public void playPreFlop(){
        //hier muss jetzt erstmal der Preflop gespielt werden
        //Nach dem Button ist der Spieler in Action
        //Daher Fallunterscheidung wegen Ende des Arrays
        if(buttonPlayer == startingPlayers - 1){
            this.playerInAction = 0;
        }else{
            this.playerInAction = buttonPlayer + 1;
        }
        //Falls wir schon die Ante erreicht haben, wird diese jetzt gesetzt
        if(this.ante > 0){
            this.betAnte();
        }
        this.betSmallBlind(); //Small Blind wird hier gesetzt
        int bigBlindPosition = playerInAction; //Soll festhalten, wer in dieser Wettrunde der BigBlind ist
        this.betBigBlind(); //Und der Big Blind wird gesetzt
        //BugFix, wenn die Blinds schon dann AllIn sind
        if(player[bigBlindPosition].getAllIn()){
            if(player[smallBlindPosition].getAllIn()){
                if(this.getPlayersInHand() == this.getPlayersAllIn() || this.getPlayersInHand() == this.getPlayersAllIn()+1 || (this.getPlayersAllIn() > 0 && this.getPlayersInHand() == 2)){
                    return;
                }
                playerInAction = buttonPlayer;
            }
            playerInAction = smallBlindPosition;
        }
        boolean instaFold = false; //Hilfsvariable, um zu checken, ob der Spieler under the gun, also direkt nach dem BigBlind, sofort gefoldet hat....purer Bugfix
        int utg = playerInAction; //Hier wird der Spieler under the gun gespeichert...für InstaFold-Check
        player[playerInAction].reactionTest(); //Under-The-Gun-Spieler macht seine Aktion
        //Hat er sofort gefoldet, wird die Flag gesetzt
        if(player[utg].getIsInGame() == false){
            instaFold = true;
        }
        //Dasselbe Problem wie bei Flop (Abbruchbedingung)
        //Solange noch nicht alle auf die letzte Bet reagiert haben oder der BigBlind seine Aktion noch nicht gemacht hat
        //(oder weil Bugfix solange noch ein Spieler übrig ist), läuft der PreFlop noch weiter
        while(playerInAction != playerLastInAction || bigBlindTookAction == false || this.getPlayersInHand() == 1){
            //Falls nur noch ein Spieler übrig ist, bekommt er kampflos den Pot überreicht (musste hier rein weil Bug)
            if(this.getPlayersInHand() == 1){ 
                if(this.getPlayersAllIn() == 1){
                    this.skipToAllInPlayer();
                }else{
                    this.nextPlayer();
                }                
                System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                this.pot = 0;
                System.out.println(""+player[playerInAction].getChips());
                return;
            //Falls (bis auf eine Ausnahme) alle Spieler AllIn gegangen sind, kann dieser noch eine letzte Aktion starten
            }else if(this.getPlayersInHand() == this.getPlayersAllIn()+1){
                player[playerInAction].reactionTest();
                if(this.getPlayersInHand() == 1){
                    //Falls der letzte Spieler, der noch ne Aktion machen kann, foldet, und somit nur noch einer übrig bleibt, kriegt der letzte verbliebene
                    //den Pot (Bugfix)
                    //System.out.println("Give last man handing his pot!");
                    //this.nextPlayer();
                    System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                    player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                    this.pot = 0;
                    System.out.println(""+player[playerInAction].getChips());
                    return;
                }
                //Amsonsten wird der PreFlop beendet und man skippt in den Showdown
                return;
            }else if(((playerInAction == smallBlindPosition && player[bigBlindPosition].getAllIn()) || playerInAction == bigBlindPosition) && bigBlindTookAction == false){
                //Hier wird nun die Flag gesetzt, ab da gelten wieder die normalen Abbruchbedingungen
                this.bigBlindTookAction = true;
                player[playerInAction].reactionTest(); //BigBlind macht jetzt seine erste Aktion
                if(player[bigBlindPosition].getPutIntoPot() == this.bigBlind && bigBlindPosition == playerLastInAction){
                    //In dem Fall hat der BigBlind seinen Blind nur gecallt oder gar gefoldet
                    return;
                //Bugfix
                }else if(instaFold){
                    //this.nextPlayer();
                }
            }
            //normale Aktion eines Spielers
            player[playerInAction].reactionTest();
        }
    }
    /**
     * Wickelt den kompletten Flop ab.
     */
    public void playFlop(){
        this.time += 15; //Zeit schreitet um 15 Sek. vorran
        this.betNumber = 0;
        this.currentBet = 0;    //Da eine neue Wettrunde gestartet ist, ist die aktuelle Wette logischerweise 0
        this.oldBet = 0; //dito
        this.street = 3; //Da drei Gemeinschaftskarten aufm Tisch kommen, zählt dies als "Third Street", dies ist ne Hilfsvariable dazu
        //Der Spieler nach dem Button beginnt dieses Mal
        playerInAction = buttonPlayer;
        if(this.getPlayersInHand() == this.getPlayersAllIn()){
            this.nextPlayerForAllInMethod();
        }else{
            this.nextPlayer();
        } 
        
        /*if(buttonPlayer == startingPlayers - 1){
            this.playerInAction = 0;
        }else{
            this.playerInAction = buttonPlayer + 1;
        }*/
        this.playerDidAction(); //ist dann die Abbruchbedingung, falls durchgecheckt wird
        //Neue Setzrunde...also werden wettrundenrelevanten Variablen zurückgesetzt
        for(int i = 0; i < startingPlayers; i++){
            if(player[i].getIsInGame() == true){
                player[i].resetForNewBettingRound();
            }
        }
        //Der Flop kommt aufm Tisch
        deck.burnCard(); //verbrennt vorher eine Karte (was beim Real-Life-Poker stets so gehandhabt wird)
        System.out.println("");
        System.out.print("Flop: ");
        for(int c = 0; c < 3; c++){
            this.communityCard[c] = this.drawCard();
            System.out.print(communityCard[c].getSuitSymbol()+""+communityCard[c].getActualValue()+" ");
        }
        System.out.println("");
        //Hier werden nochmal die Karten der Spieler gezeigt
        for(int i = 0; i < startingPlayers; i++){
            if(player[i].getIsAlive() && player[i].getIsInGame()){
                System.out.println("Spieler "+i+": "+player[i].getHoleOne().getSuitSymbol()+player[i].getHoleOne().getActualValue()+"|"+player[i].getHoleTwo().getSuitSymbol()+player[i].getHoleTwo().getActualValue());
            }
        }
        
        //Normalerweise würde die folgende while-Schleife die neue Setzrunde abwickeln, bis jeder
        //agiert hat...da aber zu Beginn die Abbruchbedingung schon direkt am Anfang gegeben ist
        //anstatt wie geplant erst nach einer Runde, kommt der spezielle Zwischensschritt zu Beginn,
        //denn theoretisch könnte in der Setzrunde davor schon alle AllIn gegangen sein und es wird nur geskippt
        if(this.getPlayersAbleToAct() < 2){
            return;
        }
        player[playerInAction].reactionTest(); //ansonsten normale Aktion des ersten Spielers
        while(playerInAction != playerLastInAction || this.getPlayersInHand() == 1 || this.getPlayersInHand() == this.getPlayersAllIn()+1){
            if(this.getPlayersInHand() == 1){
                if(this.getPlayersAllIn() == 1){
                    this.skipToAllInPlayer();
                }else{
                    this.nextPlayer();
                }     
                System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                this.pot = 0;
                System.out.println(""+player[playerInAction].getChips());
                return;
            }else if(this.getPlayersInHand() == this.getPlayersAllIn()+1){
                player[playerInAction].reactionTest();
                this.nextPlayerForAllInMethod();
                if(this.getPlayersInHand() == 1){
                    //Falls der letzte Spieler, der noch ne Aktion machen kann, foldet, und somit nur noch einer übrig bleibt, kriegt der letzte verbliebene
                    //den Pot (Bugfix)
                    //System.out.println("Give last man handing his pot!");
                    //this.nextPlayer();
                    System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                    player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                    this.pot = 0;
                    System.out.println(""+player[playerInAction].getChips());
                    return;
                }else{
                    return; 
                }
            }
            player[playerInAction].reactionTest();
        }
    }
    /**
     * Wickelt den kompletten Turn ab.
     */
    public void playTurn(){
        this.time += 10;
        this.currentBet = 0;
        this.betNumber = 0;
        this.oldBet = 0;
        this.street = 4;
        //Der Spieler nach dem Button beginnt dieses Mal
        //Die Fallunterscheidung kommt wegen Ende des Arrays
        playerInAction = buttonPlayer;
        if(this.getPlayersInHand() == this.getPlayersAllIn()){
            this.nextPlayerForAllInMethod();
        }else{
            this.nextPlayer();
        }       
        
        this.playerDidAction(); //ist dann die Abbruchbedingung, falls durchgecheckt wird
        //Neue Setzrunde...also werden wettrundenrelevanten Variablen zurückgesetzt
        for(int i = 0; i < startingPlayers; i++){
            if(player[i].getIsInGame() == true){
                player[i].resetForNewBettingRound();
            }
        }
        //Der Turn kommt aufm Tisch
        deck.burnCard();
        System.out.println("");
        System.out.print("Turn: ");       
        this.communityCard[3] = this.drawCard();
        for(int c = 0; c < 4; c++){
            System.out.print(communityCard[c].getSuitSymbol()+""+communityCard[c].getActualValue()+" ");
        }
        //Hier werden nochmal die Spielerkarten gezeigt
        System.out.println("");
        for(int i = 0; i < startingPlayers; i++){
            if(player[i].getIsAlive() && player[i].getIsInGame()){
                System.out.println("Spieler "+i+": "+player[i].getHoleOne().getSuitSymbol()+player[i].getHoleOne().getActualValue()+"|"+player[i].getHoleTwo().getSuitSymbol()+player[i].getHoleTwo().getActualValue());
            }
        }
        //Normalerweise würde die folgende while-Schleife die neue Setzrunde abwickeln, bis jeder
        //agiert hat...da aber zu Beginn die Abbruchbedingung schon direkt am Anfang gegeben ist
        //anstatt wie geplant erst nach einer Runde, kommt der spezielle Zwischensschritt zu Beginn
        if(this.getPlayersAbleToAct() < 2){
            return;
        }
        player[playerInAction].reactionTest();
        while((playerInAction != playerLastInAction && this.getPlayersInHand() > 1)|| this.getPlayersInHand() == 1 || this.getPlayersInHand() == this.getPlayersAllIn()+1){
            if(this.getPlayersInHand() == 1){
                if(this.getPlayersAllIn() == 1){
                    this.skipToAllInPlayer();
                }else{
                    this.nextPlayer();
                }     
                System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                this.pot = 0;
                System.out.println(""+player[playerInAction].getChips());
                return;
            }else if(this.getPlayersInHand() == this.getPlayersAllIn()+1){
                player[playerInAction].reactionTest();
                this.nextPlayerForAllInMethod();
                if(this.getPlayersInHand() == 1){
                    //Falls der letzte Spieler, der noch ne Aktion machen kann, foldet, und somit nur noch einer übrig bleibt, kriegt der letzte verbliebene
                    //den Pot (Bugfix)
                    //System.out.println("Give last man handing his pot!");
                    //this.nextPlayer();
                    System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                    player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                    this.pot = 0;
                    System.out.println(""+player[playerInAction].getChips());
                    return;
                }else{
                    return;
                }
            }
            player[playerInAction].reactionTest();
        }
    }
    /**
     * Wickelt den kompletten River ab.
     * Sollte es zum Showdown kommen, wird auch dieser hier ausgeführt.
     */
    public void playRiver(){
        this.time += 10;
        this.currentBet = 0;
        this.betNumber = 0;
        this.oldBet = 0;
        this.street = 5;
        //Der Spieler nach dem Button beginnt dieses Mal
        //Die Fallunterscheidung kommt wegen Ende des Arrays
        playerInAction = buttonPlayer;
        if(this.getPlayersInHand() == this.getPlayersAllIn()){
            this.nextPlayerForAllInMethod();
        }else{
            this.nextPlayer();
        } 
        this.playerDidAction(); //ist dann die Abbruchbedingung, falls durchgecheckt wird
        //Neue Setzrunde...also werden wettrundenrelevanten Variablen zurückgesetzt
        for(int i = 0; i < startingPlayers; i++){
            if(player[i].getIsInGame() == true){
                player[i].resetForNewBettingRound();
            }
        }
        //Der River kommt aufm Tisch
        deck.burnCard();
        System.out.println("");
        System.out.print("River: ");
        this.communityCard[4] = this.drawCard();
        for(int c = 0; c < 5; c++){
            System.out.print(communityCard[c].getSuitSymbol()+""+communityCard[c].getActualValue()+" ");
        }
        System.out.println("");
        //Hier werden nochmal die Spielerkarten gezeigt
        for(int i = 0; i < startingPlayers; i++){
            if(player[i].getIsAlive() && player[i].getIsInGame()){
                System.out.println("Spieler "+i+": "+player[i].getHoleOne().getSuitSymbol()+player[i].getHoleOne().getActualValue()+"|"+player[i].getHoleTwo().getSuitSymbol()+player[i].getHoleTwo().getActualValue());
            }
        }
        //Normalerweise würde die folgende while-Schleife die neue Setzrunde abwickeln, bis jeder
        //agiert hat...da aber zu Beginn die Abbruchbedingung schon direkt am Anfang gegeben ist
        //anstatt wie geplant erst nach einer Runde, kommt der spezielle Zwischensschritt zu Beginn
        if(this.getPlayersAbleToAct() < 2){
            //System.out.println("Skip to Showdown cuz of AllIn!");
        }else{
            player[playerInAction].reactionTest();
            loop:
            while((playerInAction != playerLastInAction && this.getPlayersInHand() > 1)|| this.getPlayersInHand() == 1 || this.getPlayersInHand() == this.getPlayersAllIn()+1){
                if(this.getPlayersInHand() == 1){
                    if(this.getPlayersAllIn() == 1){
                        this.skipToAllInPlayer();
                    }else{
                        this.nextPlayer();
                    }     
                    System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                    player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                    this.pot = 0;
                    System.out.println(""+player[playerInAction].getChips());
                    return;
                }else if(this.getPlayersInHand() == this.getPlayersAllIn()+1){
                    player[playerInAction].reactionTest();
                    this.nextPlayerForAllInMethod();
                    if(this.getPlayersInHand() == 1){
                        //Falls der letzte Spieler, der noch ne Aktion machen kann, foldet, und somit nur noch einer übrig bleibt, kriegt der letzte verbliebene
                        //den Pot (Bugfix)
                        //System.out.println("Give last man handing his pot!");
                        //this.nextPlayer();
                        System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                        player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                        this.pot = 0;
                        System.out.println(""+player[playerInAction].getChips());
                        return;
                    }
                    break loop;
                }
                player[playerInAction].reactionTest();
            }
        }            
        //Ist mindestens ein Spieler All-In gegangen, wird der Showdown gesondert geregelt!
        if(this.getPlayersAllIn() > 0){
            this.handleAllInPots();
            return;
        }
        //Nun kommt der Moment der Wahrheit....Showdown!!
        this.time += 15;
        if(this.getPlayersInHand() > 1){
            Hand[] showdownHand = new Hand[this.getPlayersInHand()];
            //gebe den Spielern inGame nach und nach deren besten Hände
            //Diese werden auch präsentiert
            for(int a = 0; a < this.getPlayersInHand(); a++){
                showdownHand[a] = player[playerInAction].getBestHand();
                System.out.print("Spieler "+playerInAction+" hält: ");
                for(int b = 0; b < 5; b++){
                    System.out.print(showdownHand[a].getSortedCard(b).getSuitSymbol()+""+showdownHand[a].getSortedCard(b).getActualValue()+"-");
                }
                System.out.println("");
                this.nextHand();
            }
            //Hier soll nun verglichen werden, wer gewinnt!!
            //Gibt es nur eine Gewinnerhand?
            int winners = 0;
            int maxrank = 0;
            int maxkicker = 0;
            this.nextHand();
            for(int b = 0; b < this.getPlayersInHand(); b++){
                if(player[playerInAction].getBestHand().evaluateHand() > maxrank || (player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() > maxkicker)){
                    maxrank = player[playerInAction].getBestHand().evaluateHand();
                    //System.out.println("Tiebreaker: "+player[playerInAction].getKickerCache());
                    maxkicker = player[playerInAction].getKickerCache();
                    //maxkicker = player[playerInAction].getBestHand().getKicker();
                }
                this.nextHand();
            }
            //System.out.println("Maxrank: "+maxrank+" Maxkicker: "+maxkicker);
            //Hier wird nun die Anzahl der Gewinnerhände gezählt
            for(int c = 0; c < this.getPlayersInHand(); c++){
                if((player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() == maxkicker)){
                    winners++;
                }
                this.nextHand();
            }
            if(winners > 1){
                //System.out.println("SPLITPOT - MaxRank: "+maxrank+", MaxKicker: "+maxkicker);
                //SplitPot
                int[] winnerids = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
                int helpid = 0; //um den Array mit Winner-IDs zu füllen
                for(int z = 0; z < this.getPlayersInHand(); z++){
                    //System.out.println("PlayerInAction: "+playerInAction+", HandRank: "+player[playerInAction].getBestHand().evaluateHand()+", Kicker: "+player[playerInAction].getKickerCache());
                    if((player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() == maxkicker)){
                        winnerids[helpid] = playerInAction;
                        helpid++;
                    }
                    this.nextHand();
                }
                //Jetzt sind erstmal alle Winner eingetragen im WinnerIDs-Array, jetzt wird ausgezahlt;
                System.out.print("Spieler ");
                for(int y = 0; y < winners; y++){
                    System.out.print(winnerids[y]+" ");
                    player[winnerids[y]].setChips(player[winnerids[y]].getChips()+(this.pot/winners));
                }
                System.out.println("teilen sich den Pot in Höhe von "+this.pot);
                overflow = this.pot%winners;
            }else{
                //Ansonsten räumt der Gewinner den Pot ab, der hier ermittelt wird
                int winnerid = -1;
                for(int c = 0; c < this.getPlayersInHand(); c++){
                    if((player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() == maxkicker)){
                        winnerid = playerInAction;
                    }
                    this.nextHand();
                }
                System.out.print("Spieler "+winnerid+" gewinnt mit "+this.getWinningHand(maxrank)+" den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                player[winnerid].setChips(player[winnerid].getChips() + this.pot);
                this.pot = 0;
                System.out.println(""+player[winnerid].getChips());
            }
               
        }else{
            this.nextPlayer();
                System.out.print("Spieler "+playerInAction+" gewinnt den Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                this.pot = 0;
                System.out.println(""+player[playerInAction].getChips());
        }
    }
    /**
     * Setzt sämtliche Variablen zurück, die im Laufe einer laufenden Hand von Bedeutung sind.
     * So kann eine neue Hand von vorne gespielt werden.
     */
    public void resetForNewRound(){
        //Hier wird alles zurückgesetzt, damit man in die neue Runde starten kann
        this.handsPlayed++;
        for(int i = 0; i < startingPlayers; i++){
            player[i].resetForNewHand();
        }
        System.out.println("");
        this.time += 20;
        this.betNumber = 0;
        this.passButton();
        deck.shuffleDeck();
        for(int i = 0; i < 5; i++){
            this.communityCard[i] = null;
        }
        
        pot = overflow;
        overflow = 0;
        //Falls über 20 Minuten simuliert worden sind
        if(time > 1200){
            this.nextLevel();
        }
        currentBet = 0;
        oldBet = 0;
        street = 0;
        
        //Und hier die Infos....Spieler noch in Game und die jeweiligen Stacks
        System.out.println("Spieler übrig: "+this.getPlayersInGame());
        System.out.println("Neuer Button: "+buttonPlayer);
        this.playedHands ++;
        System.out.println("Hand #"+this.playedHands);
        for(int j = 0; j < startingPlayers; j++){
            if(player[j].getIsAlive()){
                System.out.println("Spieler "+j+"("+player[j].getTypeName()+"): "+player[j].getChips()+" Chips");
            }
        }
        System.out.println("");
    }
    /**
     * Setzt sämtliche Variablen zurück, die im Laufe eines Turniers relevant sind.
     * Somit kann in einer Schleife ein komplett neues Turnier von vorne beginnen.
     */
    public void resetForNewGame(){
        time = 0;
        betNumber = 0;
        bigBlind = 10;
        blindLevel = 1;
        ante = 0;
        playedHands = 0;
    }
    
    /**
     * Simuliert eine bestimmte Zeitspanne, die vergehen soll.
     * Wichtig, um zu ermitteln, wann die Blinds erhöht werden sollen.
     * @param seconds Zeit in Sekunden 
     */
    public void passTime(int seconds){
        this.time += seconds;
    }
    /**
     * Erhöht nach 20 simulierten Minuten das Blindlevel und somit die Blinds.
     */
    public void nextLevel(){
        this.blindLevel++;
        this.levelUps++;
        this.time = this.time - 1200;
        int newBB = 0;
        int newAnte = 0;
        switch(this.blindLevel){
            case 1: newBB = 10; break;
            case 2: newBB = 20; break;
            case 3: newBB = 30; break;
            case 4: newBB = 50; break;
            case 5: newBB = 70; break;
            case 6: newBB = 90; break;
            case 7: newBB = 120; newAnte = 12; break;
            case 8: newBB = 160; newAnte = 16; break; 
            case 9: newBB = 200; newAnte = 20; break;
            case 10: newBB = 250; newAnte = 25;  break;
            case 11: newBB = 300; newAnte = 30; break;
            case 12: newBB = 350; newAnte = 35; break;
            case 13: newBB = 400; newAnte = 40; break;
            case 14: newBB = 500; newAnte = 50; break;
            case 15: newBB = 600; newAnte = 60; break;
            case 16: newBB = 700; newAnte = 70; break;
            case 17: newBB = 800; newAnte = 80; break;
            case 18: newBB = 1000; newAnte = 100; break;
            case 19: newBB = 1200; newAnte = 120; break;
            case 20: newBB = 1600; newAnte = 160; break;
            case 21: newBB = 2000; newAnte = 200; break;
            case 22: newBB = 2500; newAnte = 250; break;
            case 23: newBB = 3000; newAnte = 300; break;
            case 24: newBB = 4000; newAnte = 400; break;
            case 25: newBB = 5000; newAnte = 500; break;
            case 26: newBB = 6000; newAnte = 600; break;
            case 27: newBB = 8000; newAnte = 800; break;
            default: newBB = 100000; break; //AutoAllIn hier!
        }
        this.bigBlind = newBB;
        this.ante = newAnte;
        System.out.println("Blind-Level "+this.blindLevel+" startet jetzt! Neue Blinds: "+(this.bigBlind/2)+"/"+this.bigBlind+" Ante: "+this.ante);
    }
    /**
     * Lässt alle noch teilnehmenden Spielern die Ante bezahlen, falls es eine gibt.
     */
    public void betAnte(){
        for(int i = 0; i < startingPlayers; i++){
            //Falls der Spieler ausgeschieden ist, muss er die Ante natürlich nicht zahlen...kann er ja auch nicht
            if(player[i].getChips() == 0){
            //Falls der Spieler noch Chips hat, aber zu wenig, um die Ante zu bezahlen, geht er All-In
            }else if(player[i].getChips() <= this.ante && player[i].getChips() > 0){
                //this.pot = this.pot + player[i].getChips();
                player[i].allIn();
                System.out.println("Spieler "+i+" setzt Ante von "+this.ante+" (Pot: "+this.pot+") - verbl. Chips: ALL IN!");
            }else{
                //sonst zahlt er normal die Ante
                this.pot = this.pot + this.ante;
                player[i].addChips(0-this.ante);
                System.out.println("Spieler "+i+" setzt Ante von "+this.ante+" (Pot: "+this.pot+") - verbl. Chips: "+player[i].getChips());
            }
        }
    }
    /**
     * Lässt den SmallBlind seinen Zwangseinsatz setzen.
     */
    public void betSmallBlind(){
        //Erstmal wird dafür gesorgt, dass der neue SmallBlind definitiv als playerInAction markiert wird
        playerInAction = buttonPlayer;
        this.nextPlayer();
        smallBlindPosition = playerInAction; //Bugfix wegen PreFlop-All-In-Endlosschleife
        //Falls der aktive Spieler zu wenige oder gerade mal genug Chips für den Blind hat-->AllIn
        if(player[playerInAction].getChips() <= (this.bigBlind/2)){
            player[playerInAction].allIn();
            System.out.println("Spieler "+playerInAction+" setzt Small Blind von "+(this.bigBlind/2)+" (Pot: "+this.pot+") - verbl. Chips: "+player[playerInAction].getChips());
        }else{
            //Sonst normal Small Blind setzen
            this.pot = this.pot + (bigBlind/2);
            player[playerInAction].addChips(0-(this.bigBlind/2));
            player[playerInAction].addPutIntoPot(this.bigBlind/2);
            System.out.println("Spieler "+playerInAction+" setzt Small Blind von "+(this.bigBlind/2)+" (Pot: "+this.pot+") - verbl. Chips: "+player[playerInAction].getChips());
        }
        this.nextPlayer();
    }
    /**
     * Lässt den BigBlind seinen Zwangseinsatz setzen.
     */
    public void betBigBlind(){
        //Falls der aktive Spieler zu wenige oder gerade mal genug Chips für den Blind hat-->AllIn
        if(player[playerInAction].getChips() <= (this.bigBlind)){
            //this.pot = this.pot + player[playerInAction].getChips();            
            player[playerInAction].allIn();
            System.out.println("Spieler "+playerInAction+" setzt Big Blind von "+this.bigBlind+" (Pot: "+this.pot+") - verbl. Chips: "+player[playerInAction].getChips());
        }else{
            //Sonst normal Big Blind setzen
            this.pot = this.pot + (bigBlind);
            player[playerInAction].addChips(0-(this.bigBlind));
            player[playerInAction].addPutIntoPot(this.bigBlind);
            System.out.println("Spieler "+playerInAction+" setzt Big Blind von "+this.bigBlind+" (Pot: "+this.pot+") - verbl. Chips: "+player[playerInAction].getChips());
        }
        currentBet = bigBlind;
        playerLastInAction = playerInAction;
        bigBlindTookAction = false;
        this.nextPlayer();
    }
    /**
     * Wickelt den Fall ab, wenn mindestens einer All-In gegangen ist und es zum Showdown gekommen ist.
     * Wichtig, da die Spieler nie um mehr Chips pro Person spielen können als sie selber gesetzt haben.
     */
    public void handleAllInPots(){
        //TOGO: get eingezahlt von kleinsten Spieler
        int minShove = 2500000; //hält die Anzahl der Chips von denjenigen fest, der am wenigsten in den aktuellen Pot eingezahlt hat
        int awardedPot = 0; //gibt die Größe des Pots an, der gerade verteilt wird
        int minPlayer = -1; //speichert die ID des Spielers, der in dem Pot mitspielen darf, aber nicht in den anderen
        int alreadyPaid = 0; //Hilfsvariable, die abwickelt, wie viele Chips pro Spieler schon im Umlauf waren (für die Größe der SidePots wichtig)
        while(this.pot > 0){
            for(int i = 0; i < startingPlayers; i++){
                if(player[i].getIsInGame() && (player[i].getTotalPutIntoPot()-alreadyPaid) < minShove){
                    minShove = player[i].getTotalPutIntoPot()-alreadyPaid;
                    minPlayer = i;
                }
            }
            /*System.out.println("MinShove: "+minShove);
            System.out.println("MinPlayer: "+minPlayer);
            System.out.println("awardedPot: "+awardedPot);
            System.out.println("alreadyPaid: "+alreadyPaid);
            System.out.println("Pot: "+this.pot);
            System.out.println("Spieler übrig: "+this.getPlayersInHand());*/
            //Dann wird der aktuelle Pot gebildet
            if(alreadyPaid == 0){
                for(int j = 0; j < startingPlayers; j++){
                    if(player[j].getIsAlive() && player[j].getTotalPutIntoPot() < minShove && alreadyPaid == 0){
                        awardedPot += player[j].getTotalPutIntoPot(); //Falls der Spieler vorhin gefoldet hat und deswegen nicht so viele Chips
                                                                  //eingezahlt hat, aber trotzdem schon Chips setzen musste, gilt nur für den MainPot
                    }else if(player[j].getIsAlive()){
                        awardedPot += minShove;                         //sonst normal einzahlen
                    }
                }
            }else{                
                awardedPot = minShove * this.getPlayersInHand();
            }
            //Showdown
            this.time += 15;
            if(this.getPlayersInHand() > 1){
                Hand[] showdownHand = new Hand[this.getPlayersInHand()];
                //gebe den Spielern inGame nach und nach deren besten Hände
                //Diese werden auch präsentiert
                for(int a = 0; a < this.getPlayersInHand(); a++){
                    showdownHand[a] = player[playerInAction].getBestHand();
                    System.out.print("Spieler "+playerInAction+" hält: ");
                    for(int b = 0; b < 5; b++){
                        System.out.print(showdownHand[a].getSortedCard(b).getSuitSymbol()+""+showdownHand[a].getSortedCard(b).getActualValue()+"-");
                    }
                    System.out.println("");
                    this.nextHand();
                }
                //Hier soll nun verglichen werden, wer gewinnt!!
                //Gibt es nur eine Gewinnerhand?
                int winners = 0;
                int maxrank = 0;
                int maxkicker = 0;
                this.nextHand();
                for(int b = 0; b < this.getPlayersInHand(); b++){
                    if(player[playerInAction].getBestHand().evaluateHand() > maxrank || (player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() > maxkicker)){
                        maxrank = player[playerInAction].getBestHand().evaluateHand();
                        //System.out.println("Tiebreaker: "+player[playerInAction].getKickerCache());
                        maxkicker = player[playerInAction].getKickerCache();
                        //maxkicker = player[playerInAction].getBestHand().getKicker();
                    }
                    this.nextHand();
                }
                //System.out.println("Maxrank: "+maxrank+" Maxkicker: "+maxkicker);
                //Hier wird nun die Anzahl der Gewinnerhände gezählt
                for(int c = 0; c < this.getPlayersInHand(); c++){
                    if((player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() == maxkicker)){
                        winners++;
                    }
                    this.nextHand();
                }
                if(winners > 1){
                    //System.out.println("SPLITPOT - MaxRank: "+maxrank+", MaxKicker: "+maxkicker);
                    //SplitPot
                    int[] winnerids = new int[]{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
                    int helpid = 0; //um den Array mit Winner-IDs zu füllen
                    for(int z = 0; z < this.getPlayersInHand(); z++){
                        //System.out.println("PlayerInAction: "+playerInAction+", HandRank: "+player[playerInAction].getBestHand().evaluateHand()+", Kicker: "+player[playerInAction].getKickerCache());
                        if((player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() == maxkicker)){
                            winnerids[helpid] = playerInAction;
                            helpid++;
                        }
                        this.nextHand();
                    }
                    //Jetzt sind erstmal alle Winner eingetragen im WinnerIDs-Array, jetzt wird ausgezahlt;
                    System.out.print("Spieler ");
                    for(int y = 0; y < winners; y++){
                        System.out.print(winnerids[y]+" ");
                        player[winnerids[y]].setChips(player[winnerids[y]].getChips()+(awardedPot/winners));
                    }
                    if(alreadyPaid == 0){
                        System.out.println("teilen sich den Main-Pot in Höhe von "+awardedPot);
                    }else{
                        System.out.println("teilen sich den Side-Pot in Höhe von "+awardedPot);
                    }                    
                    overflow = awardedPot%winners;
                    this.pot = this.pot - awardedPot - overflow;
                    alreadyPaid = alreadyPaid + minShove;
                    awardedPot = 0;
                }else{
                    //Ansonsten räumt der Gewinner den Pot ab, der hier ermittelt wird
                    int winnerid = -1;
                    for(int c = 0; c < this.getPlayersInHand(); c++){
                        if((player[playerInAction].getBestHand().evaluateHand() == maxrank && player[playerInAction].getKickerCache() == maxkicker)){
                            winnerid = playerInAction;
                        }
                        this.nextHand();
                    }
                    if(alreadyPaid == 0){
                        System.out.print("Spieler "+winnerid+" gewinnt mit "+this.getWinningHand(maxrank)+" den Main-Pot in Höhe von "+awardedPot+"! Neuer Stack: ");
                    }else{
                        System.out.print("Spieler "+winnerid+" gewinnt mit "+this.getWinningHand(maxrank)+" den Side-Pot in Höhe von "+awardedPot+"! Neuer Stack: ");
                    }
                    player[winnerid].setChips(player[winnerid].getChips() + awardedPot);
                    this.pot -= awardedPot;
                    alreadyPaid += minShove;
                    awardedPot = 0;
                    System.out.println(""+player[winnerid].getChips());
                }

            }else{
                this.nextPlayerForAllInMethod();
                /*if(alreadyPaid == 0){
                    System.out.print("Spieler "+playerInAction+" gewinnt den Main-Pot in Höhe von "+awardedPot+"! Neuer Stack: ");
                }else{*/
                System.out.print("Spieler "+playerInAction+" gewinnt den Side-Pot in Höhe von "+this.pot+"! Neuer Stack: ");
                //}
                player[playerInAction].setChips(player[playerInAction].getChips() + this.pot);
                //this.pot -= awardedPot;
                //alreadyPaid += minShove;
                //awardedPot = 0;
                System.out.println(""+player[playerInAction].getChips());
                return;
            }
            //auszahlen und Pot reduzieren
            //Hilfsvariable erhöhen
            //kleinsten Spieler aus der Hand flaggen
            player[minPlayer].setIsInGame(false);
            minPlayer = -1;
            minShove = 250000;
            //Repeat TOGO
        }
        return;
    }
    
    //Getter
    /**
     * Gibt die Anzahl der Gemeinschaftskarten auf dem Tisch zurück.
     * @return 0=PreFlop, 3=Flop, 4=Turn, 5=River
     */
    public int getStreet(){
        return this.street;
    }
    /**
     * Gibt den Spieler zurück, der gerade in Aktion tritt.
     * @return ID des Spielers
     */
    public int getPlayerInAction(){
        return this.playerInAction;
    }
    /**
     * Gibt die Höhe der aktuellen Wette zurück.
     * @return Wette in Chips
     */
    public int getCurrentBet(){
        return this.currentBet;
    }
    /**
     * Gibt die Größe des Pots zurück.
     * @return Potgröße in Chips
     */
    public int getPot(){
        return this.pot;
    }
    /**
     * Gibt die Höhe des BigBlinds zurück.
     * @return Wette in Chips
     */
    public int getBigBlind(){
        return this.bigBlind;
    }
    /**
     * Gibt die Höhe der letzten Wette zurück.
     * Wichtig, um die Mindestgröße eines Re-Raises zu ermitteln.
     * @return Wette in Chips
     */
    public int getOldBet(){
        return this.oldBet;
    }
    /**
     * Gibt die Anzahl der Spieler zurück, die noch im Spiel sind.
     * @return Spieleranzahl
     */
    public int getPlayersInGame(){
        int players = 0;
        for(int i = 0; i < player.length; i++){
            if(player[i].getIsAlive() == true){
                players++;
            }
        }
        return players;
    }
    /**
     * Gibt die Anzahl der Spieler zurück, die in Moment in der Hand sind.
     * @return Spieleranzahl
     */
    public int getPlayersInHand(){
        int players = 0;
        for(int i = 0; i < player.length; i++){
            if(player[i].getIsInGame()== true && player[i].getIsAlive()){
                players++;
            }
        }
        return players;
    }
    /**
     * Gibt eine Nachricht aus, die mitteilen soll, mit welcher Hand ein Spieler gewinnt.
     * @param rank Handrang
     * @return Namen des Ranges (z.B.: einem Paar)
     */
    public String getWinningHand(int rank){
        String hand = "";
        switch(rank){
            case 10: hand = "EINEM ROYAL FLUSH"; break;
            case 9: hand = "einem Straight Flush"; break;
            case 8: hand = "einem Vierling"; break;
            case 7: hand = "einem Full House"; break;
            case 6: hand = "einem Flush"; break;
            case 5: hand = "einer Straight"; break;
            case 4: hand = "einem Drilling"; break;
            case 3: hand = "zwei Paaren"; break;
            case 2: hand = "einem Paar"; break;
            default: hand = "einer High Card";
        }
        return hand;
    }
    /**
     * Gibt die Anzahl der Spieler zurück, die in Moment noch eine Aktion ausführen können.
     * All-In-Spieler sind zwar in der Hand, aber aktionsunfähig, da sie bereits alles gesetzt haben.
     * @return Spieleranzahl
     */
    public int getPlayersAbleToAct(){
        int players = 0;
        for(int i = 0; i < player.length; i++){
            if(player[i].getIsInGame()== true && player[i].getAllIn() == false){
                players++;
            }
        }
        return players;
    }
  
    /**
     * Gibt die Karte zurück, die als Gemeinschaftskarte auf dem Tisch liegt
     * @param i Array-ID der Gemeinschaftskarte (0-4)
     * @return gewählte Karte
     */
    public Card getCommunityCard(int i){
        return communityCard[i];
    }
    /**
     * Gibt die Anzahl der bereits getätigten Wette in der aktuellen Wettrunde zurück.
     * Im PreFlop zählt der BigBlind intern nicht als eigenständige Wette.
     * @return Anzahl getätigter Wetten
     */
    public int getBetNumber(){
        return this.betNumber;
    }
    /**
     * Gibt die Anzahl der Spieler zurück, die aktuell All-In gegangen sind.
     * @return Spieleranzahl
     */
    public int getPlayersAllIn(){
        int players = 0;
        for(int i = 0; i < player.length; i++){
            if(player[i].getAllIn()== true){
                players++;
            }
        }
        return players;
    }
    /**
     * Diese Methode sorgt einfach dafür, dass der aktuelle Spieler als
     * Spieler mit der letzten Aktion markiert wird, sollte er
     * gebettet haben...die Player-Klasse kann so darauf zugreifen
     */
    public void playerDidAction(){
        this.playerLastInAction = this.playerInAction;
    }
    /**
     * Lässt die Spieler Chips in den Pot legen.
     * @param chips Anzahl der Chips
     */
    public void putIntoPot(int chips){
        //System.out.println("Stack:"+player[playerInAction].getChips()+" Bet:"+chips+" already put:"+player[playerInAction].getPutIntoPot());
        player[playerInAction].setChips(player[playerInAction].getChips() - (chips-player[playerInAction].getPutIntoPot()));
        this.pot = this.pot + (chips-player[playerInAction].getPutIntoPot());
        player[playerInAction].addPutIntoPot(chips-player[playerInAction].getPutIntoPot());
    }
    /**
     * Wickelt interne Variablen ab, falls ein Spieler eine neue Wette tätigt.
     * @param newBet Wette in Chips
     */
    public void newBet(int newBet){
        this.oldBet = this.currentBet;
        //System.out.println("Old Bet: "+oldBet);
        this.currentBet = newBet;
        this.betNumber++;
        //System.out.println("New current Bet: " + currentBet);
    }
    
    //Statistik-Methoden
    public static void reportStats(){
        //gespielte Turniere und Hände
        System.out.println("Turniere gesamt:" + totalNumberOfGames);
        System.out.println("Hände gespielt: " + handsPlayed);
        System.out.println("Hände pro Turnier: " + ((double)(handsPlayed/totalNumberOfGames)));
        System.out.println("Hände pro Level: "+((double)(handsPlayed/levelUps)));
        //Zuerst wird gezeigt, wie oft ein bestimmter Typ an einem Spiel teilnehmen konnte (nur Tournaments mit mind. 1 von diesem Typ wird getrackt)
        System.out.println("");
        System.out.println("Spiele teilgenommen:");
        System.out.println("RandomBot - "+participated[0]);
        System.out.println("CardChecker - "+participated[1]);
        System.out.println("LoosePlayer - "+participated[2]);
        //Und nun wie viele Turniere dieser Typ gewinnen konnte
        System.out.println("");
        System.out.println("Spiele gewonnen:");
        System.out.println("RandomBot - "+won[0]+" ("+(won[0]*100/participated[0])+"%)");
        System.out.println("CardChecker - "+won[1]+" ("+(won[1]*100/participated[1])+"%)");
        System.out.println("LoosePlayer - "+won[2]+" ("+(won[2]*100/participated[2])+"%)");
        //Durchschnittliche Anzahl der Gegenspieler
        double avgOpponents = opponents/totalNumberOfGames;
        System.out.println("");
        System.out.println("Durchschnittliche Anzahl der Gegner: " + avgOpponents);
    }
}

