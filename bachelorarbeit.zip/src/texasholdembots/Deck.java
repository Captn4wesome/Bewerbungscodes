/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdembots;

/**
 * Kümmert sich um das Kartendeck und organisiert, welche Karten gezogen worden sind, verteilt Karten, etc.
 * @author Administrator
 */
public class Deck {
    boolean card[][]; //Kartenmatrix, die jede Karte im Deck je einmal markiert (burned=false, available = true)
    //für i: 1=Club; 2=Diamond; 3= Heart; 4=Spade
    //für j: Kartenwert-2 (weil 2 die niedrigste ist, bei nem Index von 0)
    /**
     * Konstruktor, der ein neues, komplett gefülltes Deck aus 52 Karten
     * (Kreuz, Karo, Herz, Pik, je Ass bis 2) repräsentiert.
     */
    public Deck(){
        this.card = new boolean[4][13];
        for(int i = 0; i < 4; i++){
            for(int j = 0; j < 13; j++){
                this.card[i][j] = true; //Alle Karten werden ins Deck gemischt
            }
        }
    }
    /**
     * Verbraucht eine Karte, ohne sie zu nutzen, was auf offiziellen Pokerturnieren stets gemacht wird,
     * bevor eine neue Gemeinschaftskarte aufgedeckt wird.
     */
    public void burnCard(){
        int randValue, randSuit;
        while(true){
            randValue = ((int)(Math.random() * 13));
            randSuit = ((int)(Math.random() * 4));
            if(card[randSuit][randValue] == true){
                setCardUsed(randSuit, randValue);
                return;
            }
        }
    }
    
    /**
     * Mischt alle Karten wieder zurück ins Deck
     */
    public void shuffleDeck(){
        for(int i = 0; i < 4; i++){
            for(int j = 0; j < 13; j++){
                this.card[i][j] = true; //Alle Karten werden ins Deck gemischt
            }
        }
    }
    
    //Setter und Getter
    /**
     * Setzt Flag bei der in den Parametern angegebene Karte auf "gezogen"
     * @param suit interne ID der Kartenfarbe
     * @param value interne ID des Kartenwertes
     */
    public void setCardUsed(int suit, int value){
        this.card[suit][value] = false;
    }
    /**
     * Checkt, ob die Karte noch im Deck ist.
     * @param suit interne ID der Kartenfarbe
     * @param value interne ID des Kartenwertes
     * @return true = noch im Deck; false = bereits gezogen
     */
    public boolean getCardAvailable(int suit, int value){
        return this.card[suit][value];
    }
    
}
