/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdembots;

import static texasholdembots.TexasHoldemBots.engine;
/**                             
 * Repräsentiert den Spielertyp "CardChecker".
 * Erbt von der Player-Klasse.
 * @author Administrator
 */
public class CardChecker extends Player{
   //13x13-Entscheidungstabellen werden hier generiert. Sowohl Zeilen- als auch Spaltenindex richten sich nach den Indizes der HoleCard-Werten (Ace = 12; King = 11, etc.)
   //Dies ist eine HeadsUp-AllIn-oder-Fold-Tabelle nach der Nash-Spieltheorie 
   //Die Zahl sagt an, mit wie vielen BigBlinds ein AllIn mit der gegebenen Hand profitabel ist
   //WICHTIG: Die Hälfte unten rechts stehen für suited Handkarten, oben links für offsuit!! Die Diagonale dazwischen bilden Paare auf der Hand ab 
   //Hier als derjenige, der AllIn stellen könnte
    private double[][] nash_push =        {{20, 1.4, 1.4, 1.5, 1.5, 1.6, 1.8, 2.2, 2.9, 4.6, 7.0, 11.6, 20},
                                           {1.7, 20, 1.6, 1.8, 1.7, 1.8, 1.9, 2.5, 3.4, 5.0, 7.5, 12.2, 20},
                                           {1.8, -1, 20, 2.1, 2.0, 2.1, 2.3, 2.7, 3.8, 5.4, 7.9, 13.1, 20},
                                           {2.0, -1, 20, 20, 2.4, 2.6, 3.0, 3.5, 4.1, 6.0, 8.9, 14.2, 20},
                                           {2.0, -1, 16.3, 20, 20, 10.7, 7.0, 5.2, 5.7, 6.5, 9.6, 15.1, 20},
                                           {2.1, 2.5, 13.9, 20, 20, 20, 14.7, 10.8, 9.0, 8.5, 10.3, 16.1, 20},
                                           {2.5, 2.7, 10.1, 18.8, 20, 20, 20, 20, 17.5, 13.3, 13.0, 18.0, 20},
                                           {3.7, 4.9, 6.9, 14.4, 20, 20, 20, 20, 20, 20, 20, 20, 20},
                                           {6.5, 7.7, 10.5, 11.9, 20, 20, 20, 20, 20, 20, 20, 20, 20},
                                           {8.5, 10.6, 13.5, 14.7, 18.6, 20, 20, 20, 20, 20, 20, 20, 20},
                                           {12.7, 13.5, 16.3, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20},
                                           {19.3, 19.9, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20},
                                           {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}};

    //analog, wenn man überlegt, ob man callt
    private double[][] nash_call          = {{15.0, 2.6, 2.7, 2.8, 2.7, 2.6, 2.8, 3.0, 3.5, 4.2, 5.6, 8.1, 15.8},
                                             {3.3, 20, 3.0, 3.1, 2.9, 2.9, 2.9, 3.1, 3.6, 4.5, 5.9, 8.7, 16.6},
                                             {3.4, 3.8, 20, 3.5, 3.3, 3.2, 3.2, 3.3, 3.8, 4.7, 6.2, 9.1, 18.3},
                                             {3.6, 4.0, 4.6, 20, 3.7, 3.6, 3.6, 3.7, 4.0, 5.1, 6.8, 10.2, 20},
                                             {3.3, 3.8, 4.3, 4.9, 20, 4.0, 4.1, 4.2, 4.6, 5.4, 7.3, 11.0, 20},
                                             {3.3, 3.6, 4.1, 4.8, 5.4, 20, 4.7, 5.0, 5.5, 6.4, 8.0, 12.4, 20},
                                             {3.5, 3.6, 4.1, 4.8, 5.6, 6.5, 20, 6.0, 6.6, 7.6, 9.7, 13.8, 20},
                                             {3.9, 4.1, 4.3, 5.0, 5.8, 7.0, 8.2, 20, 8.4, 9.5, 11.7, 17.1, 20},
                                             {4.5, 4.8, 5.2, 5.2, 6.3, 7.4, 9.3, 11.5, 20, 12.7, 15.3, 20, 20},
                                             {5.6, 5.8, 6.1, 6.9, 7.0, 8.8, 10.6, 13.4, 18.0, 20, 19.5, 20, 20},
                                             {7.2, 7.8, 8.4, 8.9, 9.9, 10.5, 13.0, 16.1, 20, 20, 20, 20, 20},
                                             {10.7, 11.4, 12.1, 13.2, 14.3, 15.2, 17.6, 20, 20, 20, 20, 20, 20},
                                             {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}};
    //PreFlop-Tabelle, die die Handkarten analog repräsentiert
    //Allerdings sind die Werte nicht in BigBlind gehalten...sie repräsentieren das Perzentil der jeweiligen Karte, mit AA im oberem 0,45% als stärkste Karte
    private double[][] preFlop            = {{60.48, 100.0,  97.28,  95.47,  98.19,  99.09,  96.83,  92.76,  87.33,  82.20,  71.34,  60.03,  40.87},//2
                                            {83.71, 47.66,  91.85,  89.14,  90.95,  93.66,  94.57,  90.04,  84.61,  77.97,  68.62,  56.71,  35.89}, //3
                                            {79.18, 70.13,  36.34,  80.09,  83.40,  85.52,  86.42,  88.23,  81.29,  72.54,  61.68,  49.77,  33.18}, //4
                                            {74.96, 66.51,  57.61,  24.43,  73.45,  74.66,  76.16,  78.88,  77.07,  69.53,  58.52,  46.60,  28.05}, //5
                                            {80.39, 69.83,  58.82,  48.86,  16.13,  63.19,  65.30,  67.42,  66.21,  64.10,  53.69,  42.68,  31.07}, //6
                                            {82.50, 71.64,  60.78,  50.07,  43.28,  10.25,  54.60,  55.80,  52.18,  50.98,  48.56,  37.55,  25.64}, //7
                                            {75.26, 73.75,  62.29,  52.79,  44.79,  34.99,  5.27,  44.49,  41.77,  39.66,  38.76,  32.27,  21.87}, //8
                                            {70.43, 67.72,  64.40,  54.90,  45.39,  34.69,  25.94,  3.01,  30.16,  28.95,  26.84,  23.07,  18.55}, //9
                                            {61.99, 59.12,  57.01,  52.48,  43.58,  34.08,  24.73,  19.15,  2.26,  20.36,  17.04,  15.08,  11.16}, //T
                                            {57.31, 51.28,  47.20,  45.70,  42.98,  33.48,  23.68,  17.64,  11.46,  1.8,  13.87,  12.36,  8.29}, //J
                                            {46.90, 45.09,  39.96,  36.65,  33.78,  29.26,  22.17,  15.38,  9.50,  7.08,  1.35,  9.20,  6.48}, //Q
                                            {37.85, 34.38,  31.37,  27.14,  23.98,  20.96,  19.45,  12.97,  7.39,  6.78,  4.82,  0.9,  4.22}, //K
                                            {23.37, 20.66,  18.85,  15.68,  17.34,  14.17,  12.66,  9.80,  5.58,  4.52,  3.31,  2.56,  0.45}};//A
    
    //analog, wenn man überlegt, ob man callt
    private double[][] streets            = {{15.0, 2.6, 2.7, 2.8, 2.7, 2.6, 2.8, 3.0, 3.5, 4.2, 5.6, 8.1, 15.8},
                                             {3.3, 20, 3.0, 3.1, 2.9, 2.9, 2.9, 3.1, 3.6, 4.5, 5.9, 8.7, 16.6},
                                             {3.4, 3.8, 20, 3.5, 3.3, 3.2, 3.2, 3.3, 3.8, 4.7, 6.2, 9.1, 18.3},
                                             {3.6, 4.0, 4.6, 20, 3.7, 3.6, 3.6, 3.7, 4.0, 5.1, 6.8, 10.2, 20},
                                             {3.3, 3.8, 4.3, 4.9, 20, 4.0, 4.1, 4.2, 4.6, 5.4, 7.3, 11.0, 20},
                                             {3.3, 3.6, 4.1, 4.8, 5.4, 20, 4.7, 5.0, 5.5, 6.4, 8.0, 12.4, 20},
                                             {3.5, 3.6, 4.1, 4.8, 5.6, 6.5, 20, 6.0, 6.6, 7.6, 9.7, 13.8, 20},
                                             {3.9, 4.1, 4.3, 5.0, 5.8, 7.0, 8.2, 20, 8.4, 9.5, 11.7, 17.1, 20},
                                             {4.5, 4.8, 5.2, 5.2, 6.3, 7.4, 9.3, 11.5, 20, 12.7, 15.3, 20, 20},
                                             {5.6, 5.8, 6.1, 6.9, 7.0, 8.8, 10.6, 13.4, 18.0, 20, 19.5, 20, 20},
                                             {7.2, 7.8, 8.4, 8.9, 9.9, 10.5, 13.0, 16.1, 20, 20, 20, 20, 20},
                                             {10.7, 11.4, 12.1, 13.2, 14.3, 15.2, 17.6, 20, 20, 20, 20, 20, 20},
                                             {20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20}};
    
    /**
     * Konstruktor der Spielerklasse.
     * Abgesehen von anderem Typnamen wird eine Instanz genauso konstruiert wie die Vaterklasse.
     * @param c 
     */
    public CardChecker(int c){
        super(c); //erbt von Player-Klasse
        this.setTypeName("CardChecker");
        this.setID(1);
    }
    
    /**
     * Überschreibt die reactionTest()-Methode der Vaterklasse und stattet diesen Spielertyp
     * mit neuen Verhaltensweisen aus.
     */
    @Override public void reactionTest(){
        double bluff = Math.random();
        if(bluff >= 0.95){
            int bluffsize = ((int)(Math.random()*this.getChips()));
            this.bet(bluffsize);
        }else{
            engine.passTime(5); //simuliert 5 Sekunden
            //Hier wird gecheckt, ob wir im PreFlop sind
            if(engine.getStreet() == 0){
                //wenn JA: sind wir im HeadsUp?
                if(engine.getPlayersInGame() == 2){
                    //wenn JA: ist der Stack kleiner gleich 20 bigBlinds?
                    if(this.getChips() <= (engine.getBigBlind() * 20)){
                        //wenn JA: ist der Spieler in der Initiative?
                        if(engine.getCurrentBet() == engine.getBigBlind()){
                            /*dann handel hier die Pusher-Tabelle ab
                            //Dabei die -1-Sonderfälle abarbeiten*/
                            if(this.getValueFromDoubleDecisionTable(nash_push, this.getHoleOne(), this.getHoleTwo()) == -1){
                                //Hat der Spieler 63suited?
                                if((this.getHoleOne().getValue() == 4 && this.getHoleTwo().getValue() == 1) || (this.getHoleOne().getValue() == 1 && this.getHoleTwo().getValue() == 4)){
                                    //Sonderfall: entweder 8.9-4.7 oder unter 2.8 spielbar
                                    if(this.getChips() < (engine.getBigBlind() * 2.8) || (this.getChips() < (engine.getBigBlind()*8.9) && this.getChips() > (engine.getBigBlind()*4.7))){
                                        this.bet(10000000); //AllIn!!!!
                                    }else{
                                        this.fold();
                                    }
                                ///oder 53suited?
                                }else if((this.getHoleOne().getValue() == 3 && this.getHoleTwo().getValue() == 1) || (this.getHoleOne().getValue() == 1 && this.getHoleTwo().getValue() == 3)){
                                    //Sonderfall: entweder 15.2-3.8 oder unter 2.9 spielbar
                                    if(this.getChips() < (engine.getBigBlind() * 2.9) || (this.getChips() < (engine.getBigBlind()*15.2) && this.getChips() > (engine.getBigBlind()*3.8))){
                                        this.bet(10000000); //AllIn!!!!
                                    }else{
                                        this.fold();
                                    }
                                }else{
                                    //ansonsten hat er 43suited
                                    //Sonderfall: entweder 11.5-4.7 oder unter 2.6 spielbar
                                    if(this.getChips() < (engine.getBigBlind() * 2.6) || (this.getChips() < (engine.getBigBlind()*11.5) && this.getChips() > (engine.getBigBlind()*4.7))){
                                        this.bet(10000000); //AllIn!!!!
                                    }else{
                                        this.fold();
                                    }
                                }
                            }
                            //Ansonsten normal Push oder Fold
                            else if((this.getChips()/engine.getBigBlind()) <= this.getValueFromDoubleDecisionTable(nash_push, this.getHoleOne(), this.getHoleTwo())){
                                this.bet(10000000); //ALL-IN GEHEN!!!!!
                            }else{
                                this.fold();
                            }
                        }else{
                            //Ansonsten nach der Nash-Caller-Tabelle arbeiten, da der Spieler als zweiter an der Reihe ist
                            if((this.getChips()/engine.getBigBlind()) <= this.getValueFromDoubleDecisionTable(nash_call, this.getHoleOne(), this.getHoleTwo())){
                                this.bet(10000000); //ALL-IN GEHEN!!!!!
                            }else{
                                this.fold();
                            }
                        }
                    }

                }else{
                    //ansonsten nach der PreFlop-Tabelle arbeiten
                    //Dabei werden die Werte invertiert, sodass zB: AA im oberem 0,45-Perzentil einen Spielwert von 100% hat, 32offsuit mit 100er-Perzentil
                    //nur n Spielwert von 0,45%.
                    //Der Wert wird mit der Anzahl der Spieler in der Hand zusammengerechnet...falls sich die Hand lohnt, wird gespielt
                    //Drei Fälle: Raise = wenn DEUTLICH höher; Call = höher; sonst fold
                    if((80/(engine.getPlayersInHand()+engine.getBetNumber()) > this.getValueFromDoubleDecisionTable(preFlop, this.getHoleOne(), this.getHoleTwo()))){
                        int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                        this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                           //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                           //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                    }else if((120/(engine.getPlayersInHand()+engine.getBetNumber()) > this.getValueFromDoubleDecisionTable(preFlop, this.getHoleOne(), this.getHoleTwo()))){
                        this.call();
                    }else{
                        this.fold();
                    }
                }
            }else{
                //ansonsten hier weitere KI-Entscheidungen nach dem Pre-Flop
                if(engine.getStreet() == 3){ //sind wir im Flop?
                    Hand flopHand = new Hand(this.getHoleOne(), this.getHoleTwo(), engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2));
                    if(flopHand.evaluateHand() == 1){
                        if(super.getHoleOne().getValue() > flopHand.getSortedCard(2).getValue() && super.getHoleTwo().getValue() > flopHand.getSortedCard(2).getValue()){
                            //Sollten die beiden Handkarten die höchsten Karten sein, so spekuliert der Bot, dass er damit noch was gutes auf dem Turn oder River trifft
                            double weakBluff = Math.random();
                            if(weakBluff < 0.2){
                                //Soll er versuchen, die Leute rauszubluffen? 20%
                                int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                                this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                                    //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                                    //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                            }else{
                                //Sonst lieber callen
                                super.call();
                            }
                        }else{
                            //Sollten die Handkarten zu schwach sein --> Fold
                            super.fold();
                        }
                    }else if(flopHand.evaluateHand() >= 2 && flopHand.evaluateHand() <= 4 && flopHand.getSortedCard(0).getValue() == flopHand.getSortedCard(1).getValue()){ //Falls der Spieler entweder Drilling, oder minimum 1 Paar hält und dabei die höchsten Karten gepaart sind
                        //Ohh cool! Mindestens ein TopPair...falls noch keine Wette gesetzt wurde, hier wetten...ansonsten einfach callen
                        if(engine.getCurrentBet() == 0){
                            int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                            this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                                    //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                                    //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                        }else{
                            super.call();
                        }
                    }else if(flopHand.evaluateHand() > 4){
                        double slowPlay = Math.random();
                        if(slowPlay < 0.4){
                            super.call(); //40%-ige Chance für einen SlowPlay (d.h. man callt mit ner starken Hand in der Hoffnung, dass der Gegner das als Schwäche sieht und dementsprechend raist)
                        }else{
                            int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                            this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                               //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                               //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                        }                        
                    }else{
                        super.fold();
                    }
                }else if(engine.getStreet() == 4){   //sind wir im Turn?                 
                    Hand turnHand = super.getBestTurnHand();;
                    if(turnHand.evaluateHand() == 1){
                        if(super.getHoleOne().getValue() > turnHand.getSortedCard(2).getValue() && super.getHoleTwo().getValue() > turnHand.getSortedCard(2).getValue()){
                            //Hier geht der Spieler genau so vor wie im Flop....trotzdem ist es wahrscheinlicher, dass er rausgeht, weil auf dem Turn eine hohe Karte kommen kann, womit der Spieler trotzdem keinen Paar bilden kann...so wird seine Hanf geschwächt, was Grund fürn Fold wäre
                            double weakBluff = Math.random();
                            if(weakBluff < 0.2){
                                //Soll er versuchen, die Leute rauszubluffen? 20%
                                int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                                this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                                    //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                                    //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                            }else if(engine.getBetNumber()<2){
                                //sollte max. eine Bet getätigt worden sein, callt er, anderfalls wird es zu riskant
                                super.call();
                            }
                        }else{
                            //Sollten die Handkarten zu schwach sein --> Fold
                            super.fold();
                        }
                    }else if(turnHand.evaluateHand() >= 2 && turnHand.evaluateHand() <= 4 && turnHand.getSortedCard(0).getValue() == turnHand.getSortedCard(1).getValue()){ //Falls der Spieler entweder Drilling, oder minimum 1 Paar hält und dabei die höchsten Karten gepaart sind
                        //Ohh cool! Mindestens ein TopPair...falls noch keine Wette gesetzt wurde, hier wetten...ansonsten einfach callen
                        if(engine.getCurrentBet() == 0){
                            int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                            this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                                    //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                                    //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                        }else{
                            super.call();
                        }
                    }else{
                        double slowPlay = Math.random();
                        if(slowPlay < 0.4){
                            super.call(); //40%-ige Chance für einen SlowPlay (d.h. man callt mit ner starken Hand in der Hoffnung, dass der Gegner das als Schwäche sieht und dementsprechend raist)
                        }else{
                            int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                            this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                               //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                               //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                        }                        
                    }
                }else{ //wir sind im River
                    Hand riverHand = super.getBestHand();;
                    if(riverHand.evaluateHand() == 1){
                        if(super.getHoleOne().getValue() > riverHand.getSortedCard(2).getValue() && super.getHoleTwo().getValue() > riverHand.getSortedCard(2).getValue()){
                            //Hier geht der Spieler genau so vor wie im Flop....trotzdem ist es wahrscheinlicher, dass er rausgeht, weil auf dem Turn eine hohe Karte kommen kann, womit der Spieler trotzdem keinen Paar bilden kann...so wird seine Hanf geschwächt, was Grund fürn Fold wäre
                            double weakBluff = Math.random();
                            if(weakBluff < 0.2){
                                //Soll er versuchen, die Leute rauszubluffen? 20%
                                int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                                this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                                    //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                                    //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                            }else if(engine.getBetNumber()<2){
                                //sollte max. eine Bet getätigt worden sein, callt er, anderfalls wird es zu riskant
                                super.call();
                            }
                        }else{
                            //Sollten die Handkarten zu schwach sein --> Fold
                            super.fold();
                        }
                    }else if(riverHand.evaluateHand() >= 2 && riverHand.evaluateHand() <= 4 && riverHand.getSortedCard(0).getValue() == riverHand.getSortedCard(1).getValue()){ //Falls der Spieler entweder Drilling, oder minimum 1 Paar hält und dabei die höchsten Karten gepaart sind
                        //Ohh cool! Mindestens ein TopPair...falls noch keine Wette gesetzt wurde, hier wetten...ansonsten einfach callen
                        if(engine.getCurrentBet() < 2){
                            int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                            this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                                    //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                                    //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                        }else{
                            super.call();
                        }
                    }else{
                        double slowPlay = Math.random();
                        if(slowPlay < 0.4){
                            super.call(); //40%-ige Chance für einen SlowPlay (d.h. man callt mit ner starken Hand in der Hoffnung, dass der Gegner das als Schwäche sieht und dementsprechend raist)
                        }else{
                            int betsize = ((int)(((Math.random() * engine.getPlayersInHand())+2)*engine.getCurrentBet()));
                            this.bet(betsize); //Betsize wird zufällig ausgesucht, wobei die Anzahl der Spieler mit einbezogen wird
                                               //Bei zwei Spieler passt es super, da wird eine zufällige Erhöhung zwischen 2x und 4x der aktuellen Bet,
                                               //Jeder weiterer Spieler erhöht die Streuung der Betsize nach obenhin
                        }                        
                    }
                }
            }
        }        
    }
    
    /**
     * Sucht anhand der Handkarten in einer gewünschten Entscheidungstabelle nach einem Spielwert und gibt diese zurück.
     * Anhand des Spielwerts kann die KI entscheiden, welcher Spielzug angebracht ist.
     * @param table gewünschte Entscheidungstabelle als 2-dimensionaler Array
     * @param c1 erste Handkarte
     * @param c2 zweite Handkarte
     * @return Spielwert (abhängig von übergebenen Entscheidungstabelle)
     */
    public double getValueFromDoubleDecisionTable(double[][] table, Card c1, Card c2){
        double value; //Rückgabewert
        int card1val;   //Hilfsvariablen, die die Kartenwerte speichert und dann als Indizes für die Tabelle nutzt
        int card2val;
        //Zunächst wird gecheckt, ob es sich um ein Paar handelt, dann ist die Reihenfolge der Karten unerheblich
        if(c1.getValue() == c2.getValue()){
            card1val = c1.getValue();
            card2val = c2.getValue();
        //Sollten die Karten suited sein und die Kartenreihenfolge stimmen ( zuerst), oder die Karten offsuit und die Reihenfolge stimmen ( zuerst)
        //wird hier genau wie oben gespeichert
        }else if((c1.getSuit() == c2.getSuit() && c1.getValue() > c2.getValue())||(c1.getSuit() != c2.getSuit() && c1.getValue() < c2.getValue())){
            card1val = c1.getValue();
            card2val = c2.getValue();
        //anderfalls werden die Reihenfolgen vertauscht, damit in der richtigen Hälfte der Nash-Tabelle geschaut wird
        }else{
            card1val = c2.getValue();
            card2val = c1.getValue();
        }
        //Wert wird aus der Tabelle ausgelesen und zurückgegeben
        value = table[card1val][card2val];
        return value;
    }
}
