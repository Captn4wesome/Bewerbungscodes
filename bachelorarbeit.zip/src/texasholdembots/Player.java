/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdembots;

import static texasholdembots.TexasHoldemBots.engine;

/**
 * Klasse, die einzelne Spieler repräsentiert.
 * Wickelt Parameter wie Handkarten, Chips, etc. ab; die wichtigste Funktion ist aber, wie die Spielertypen
 * in verschiedenen Spielsituationen agieren.
 * In Urform repräsentiert diese Klasse "RandomBot", wird aber auch verwendet, um an weitere Spielertypen zu vererben.
 * @author Administrator
 */
public class Player {
    private int chipStack = 0;
    private Card holeOne = null;
    private Card holeTwo = null;
    private boolean isAlive = true;
    private boolean isInGame = true; //zeigt an, ob er noch in der Runde ist
    private boolean isAllIn = false;
    private char action = ' ';
    private String type = "RandomBot"; //zeigt den Namen dieses Spielertyps an
    private int putIntoPot = 0; //Zeigt an, wie viel Player in den Pot in dieser Runde gepackt hat,
                                //sodass nur noch aufgestockt werden muss, falls eine neue Bet kommt.
    private int totalPutIntoPot = 0; //zeigt, wie viel insgesamt in der Hand eingezahlt wurde
                                     //spielt nur bei SidePots eine Rolle, dann aber ne wichtige
    
    private int kickerCache = 0; //hilft hoffentlich beim Debuggen vom Kicker
    
    private int id = 0; //interne ID, die für das Tracken der Statistiken hilfreich ist    
    
    /**
     * Konstruktor für den Spielertyp "RandomBot".
     * @param c Startstack in Chips
     */
    public Player(int c){
        this.chipStack = c;
        this.isAlive = true;
    }
    /**
     * Lässt den Spieler All-In gehen und setzt entsprechende Flags.
     */
    public void allIn(){
        //Falls der Spieler raist, sprich: verbliebener Stack + Das, was schon gesetzt wurde, größer als der current Bet ist
        if(chipStack+putIntoPot > engine.getCurrentBet()){
            engine.newBet(chipStack+putIntoPot);
        }
        engine.putIntoPot(chipStack+putIntoPot);
        this.isAllIn = true;
    }
    /**
     * Lässt den Spieler agieren, sobald dieser an der Reihe ist.
     * Da die Methode bei den Kinderklassen überschrieben wird, werden HIER die Unterschiede der Spielertypen am deutlichsten.
     * Hier werden nämlich die Verhaltensregeln festgelegt.
     */
    public void reactionTest(){
        //DAS IST DER KERN!!! DAS HIER IST DEINE BACHELORARBEIT!!!!!!!!!!
        engine.passTime(5);
        double randReaction = Math.random();        //Zufall
        if(engine.getStreet() == 0){            //sind wir im Preflop?
            if(randReaction < 0.4){             //40% Fold
                if(engine.getCurrentBet() != 0){
                    this.fold();
                }else{
                    this.call();
                }                
            }else if(randReaction < 0.7){       //30% Call
                this.call();
            }else{                              //30% Raise bis auf das Fuenffache der aktuellen Wette
                int newBet = ((int)(Math.random()*5*engine.getCurrentBet()));
                this.bet(newBet);
            }
        }else{
            //Falls wir nicht mehr im Preflop sind
            if(randReaction < 0.15){
                if(engine.getCurrentBet() != 0){
                    this.fold();
                }else{
                    this.call();
                }  
            }else if(randReaction < 0.7){
                this.call();
            }else{
                //System.out.println("RAISE!! Alter currentBet: "+engine.getCurrentBet());
                int newBet = ((int)(Math.random()*5*engine.getCurrentBet()));
                this.bet(newBet);
            }
        }
    }
    
    /**
     * Bildet mit 5 von 7 Karten die beste Kombination, die man mit den Karten bilden kann.
     * Durch Brute-Force werden alle 21 möglichen Kombinationen einmal durchgegangen und abgeglichen.
     * @return Hand-Objekt mit den fünf Karten, die die beste Kombination bilden.
     */
    public Hand getBestHand(){
        int rank = 0;
        int kicker = 0;
        Hand test; //Diese Hand wird geprüft
        Hand hand; //Falls die geprüfte Hand die Beste ist, wird sie hier gespeichert
        //Jetzt wird geBruteForced!
        test = new Hand(this.getHoleOne(), this.getHoleTwo(), engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2));
        rank = test.evaluateHand(); //Der Rang der Karten wird ermittelt
        kicker = test.getKicker();
        hand = new Hand(this.getHoleOne(), this.getHoleTwo(), engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2)); //Die erste Hand ist zunächst die beste
        //Jetzt starten auch die Vergleiche
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3));  
            }
        }
        //Nr3: H1-H2-0-1-4
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(4));  
            }
        }
        //Nr4: H1-H2-0-2-3
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr5: H1-H2-0-2-4
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(4));  
            }
        }
        //Nr6: H1-H2-0-3-4
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr7: H1-H2-1-2-3
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr8: H1-H2-1-2-4
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));  
            }
        }
        //Nr9: H1-H2-1-3-4
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr10: H1-H2-2-3-4
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr11: H1-0-1-2-3
        test = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr12: H1-0-1-2-4
        test = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));  
            }
        }
        //Nr13: H1-0-1-3-4
        test = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr14: H1-0-2-3-4
        test = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr15: H1-1-2-3-4
        test = new Hand(this.holeOne, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr16: H2-0-1-2-3
        test = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr17: H2-0-1-2-4
        test = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(4));  
            }
        }
        //Nr18: H2-0-1-3-4
        test = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr19: H1-0-2-3-4
        test = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr20: H1-1-2-3-4
        test = new Hand(this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        //Nr21: 0-1-2-3-4
        test = new Hand(engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3), engine.getCommunityCard(4));  
            }
        }
        this.kickerCache = kicker;
        return hand;
    }
    /**
     * Hilfsmethode, die die beste Hand bilden soll, die die Kinderklassen nutzen können, um die eigene Handstärke im Turn zu evaluieren.
     * @return Hand-Objekt, die beste Kombination von 5 aus 6 Karten repräsentiert
     */
    public Hand getBestTurnHand(){
        int rank = 0;
        int kicker = 0;
        Hand test; //Diese Hand wird geprüft
        Hand hand; //Falls die geprüfte Hand die Beste ist, wird sie hier gespeichert
        //Jetzt wird geBruteForced!
        test = new Hand(this.getHoleOne(), this.getHoleTwo(), engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2));
        rank = test.evaluateHand(); //Der Rang der Karten wird ermittelt
        kicker = test.getKicker();
        hand = new Hand(this.getHoleOne(), this.getHoleTwo(), engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2)); //Die erste Hand ist zunächst die beste
        //Jetzt starten auch die Vergleiche
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(3));  
            }
        }
        //Nr3: H1-H2-0-2-3
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr4: H1-H2-1-2-3
        test = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, this.holeTwo, engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr5: H1-0-1-2-3
        test = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeOne, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        //Nr6: H2-0-1-2-3
        test = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        if(test.evaluateHand() > rank){
            rank = test.evaluateHand();
            kicker = test.getKicker();
            hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));
        }else if(test.evaluateHand() == rank){
            if(test.getKicker() > kicker){
                rank = test.evaluateHand();
                kicker = test.getKicker();
                hand = new Hand(this.holeTwo, engine.getCommunityCard(0), engine.getCommunityCard(1), engine.getCommunityCard(2), engine.getCommunityCard(3));  
            }
        }
        this.kickerCache = kicker;
        return hand;
    }
    
    //Aktionen des Spielers
    /**
     * Falls der Spieler callen kann, ohne weitere Chips zu setzen (vor allem, wenn er im BigBlind ist oder gecheckt wurde),
     * wird gecallt. Ansonsten legt der Spieler seine Hand nieder.
     */
    public void fold(){        
        //Quasi der Check, folden würde hier keinen Sinn machen
        if(engine.getCurrentBet() == this.putIntoPot){
            this.call();
        }else{        
            System.out.println("Spieler "+engine.getPlayerInAction()+" foldet!");
            this.isInGame = false;
            if(engine.getPlayersAllIn() >= engine.getPlayersInHand()){
                engine.skipToAllInPlayer();
                return;
            }else{
                engine.nextPlayer();  
            }
        }
    }
    /**
     * Lässt den Spieler callen, d.h. die Wette mitgehen.
     */
    public void call(){
        if(engine.getCurrentBet() >= this.chipStack){
            System.out.print("Spieler "+engine.getPlayerInAction()+" geht All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
            this.allIn();
            System.out.println("(Pot: "+engine.getPot()+")");
        }else{
            engine.putIntoPot(engine.getCurrentBet());
            System.out.println("Spieler "+engine.getPlayerInAction()+" callt "+engine.getCurrentBet()+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
        }
        engine.nextPlayer();
    }
    /**
     * Lässt den Spieler eine neue, regelkonforme Wette setzen.
     * @param bet Wette in Chips
     */
    public void bet(int bet){
        engine.passTime(5);
        if(engine.getCurrentBet() != 0){
            if(engine.getOldBet() != 0){
                if(this.chipStack > (engine.getCurrentBet() * 2 - engine.getOldBet())){
                    if(this.chipStack > bet){
                        if(bet >= (engine.getCurrentBet()*2 - engine.getOldBet())){
                            engine.putIntoPot(bet);
                            engine.newBet(bet);
                            System.out.println("Spieler "+engine.getPlayerInAction()+" raist auf "+bet+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
                        }else{
                            engine.putIntoPot(engine.getCurrentBet()*2 - engine.getOldBet());
                            System.out.println("Spieler "+engine.getPlayerInAction()+" raist auf "+(engine.getCurrentBet()*2 - engine.getOldBet())+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
                            engine.newBet(engine.getCurrentBet()*2 - engine.getOldBet());
                        }
                    }else{                        
                        System.out.print("Spieler "+engine.getPlayerInAction()+" raist All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
                        this.allIn();
                        engine.newBet(chipStack+putIntoPot);
                        System.out.println("(Pot: "+engine.getPot()+")");
                    }
                }else{
                    System.out.print("Spieler "+engine.getPlayerInAction()+" geht All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
                    this.allIn();
                    System.out.println("(Pot: "+engine.getPot()+")");
                }
            }else if(this.chipStack > (2*engine.getCurrentBet())){
                if(this.chipStack > bet){
                    if(bet >= (2*engine.getCurrentBet())){                        
                        engine.putIntoPot(bet);
                        engine.newBet(bet);
                        System.out.println("Spieler "+engine.getPlayerInAction()+" raist auf "+bet+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
                    }else{
                        engine.putIntoPot(2*engine.getCurrentBet());
                        System.out.println("Spieler "+engine.getPlayerInAction()+" raist auf "+(2*engine.getCurrentBet())+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
                        engine.newBet(2*engine.getCurrentBet());
                    }
                }else{                    
                    System.out.print("Spieler "+engine.getPlayerInAction()+" raist All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
                    this.allIn();
                    engine.newBet(chipStack+putIntoPot);
                    System.out.println("(Pot: "+engine.getPot()+")");
                }
            }else{
                System.out.print("Spieler "+engine.getPlayerInAction()+" geht All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
                this.allIn();
                System.out.println("(Pot: "+engine.getPot()+")");
            }
        }else{
            if(this.chipStack > engine.getBigBlind()){
                if(this.chipStack > bet){
                    if(bet >= engine.getBigBlind()){
                        engine.putIntoPot(bet);
                        engine.newBet(bet);
                        System.out.println("Spieler "+engine.getPlayerInAction()+" bettet "+bet+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
                    }else{
                        engine.putIntoPot(engine.getBigBlind());
                        System.out.println("Spieler "+engine.getPlayerInAction()+" bettet "+engine.getBigBlind()+"! (Pot:"+engine.getPot()+") - verbl. Chips: "+this.chipStack);
                        engine.newBet(engine.getBigBlind());
                    }
                }else{
                    System.out.print("Spieler "+engine.getPlayerInAction()+" raist All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
                    this.allIn();
                    engine.newBet(chipStack+putIntoPot);
                    System.out.println("(Pot: "+engine.getPot()+")");
                }
            }else{
                System.out.print("Spieler "+engine.getPlayerInAction()+" geht All-In mit "+(this.chipStack+this.putIntoPot)+"!!! ");
                this.allIn();
                System.out.println("(Pot: "+engine.getPot()+")");
            }
        }
        engine.playerDidAction();
        engine.nextPlayer();
    }
    
    //Setter
    /**
     * Fügt neue Chips für den Spieler hinzu. Negative Parameter ziehen stattdessen Chips ab.
     * @param c Anzahl der Chips
     */
    public void addChips(int c){
        this.chipStack = chipStack + c;
    }
    /**
     * Legt die erste der beiden Handkarten fest.
     * @param c1 erste Handkarte
     */
    public void setHoleOne(Card c1){
        this.holeOne = c1;
    }
    /**
     * Legt die zweite der beiden Handkarten fest.
     * @param c2 zweite Handkarte
     */
    public void setHoleTwo(Card c2){
        this.holeTwo = c2;
    }
    /**
     * Setzt die Flag dafür, ob der Spieler noch am Spiel teilnimmt.
     * @param live false = Spieler ausgeschieden
     */
    public void setIsAlive(boolean live){
        this.isAlive = live;
    }
    /**
     * Setzt die Flag dafür, ob der Spieler noch in der Hand ist.
     * @param game false = hat gefoldet
     */
    public void setIsInGame(boolean game){
        this.isInGame = game;
    }
    /**
     * Setzt die Flag dafür, ob der Spieler All-In gegangen ist.
     * @param allIn true = ist All-In
     */
    public void setAllIn(boolean allIn){
        this.isAllIn = allIn;
    }
    /**
     * Setzt die Stackgröße des Spielers.
     * @param chips Anzahl der Chips
     */
    public void setChips(int chips){
        this.chipStack = chips;
    }
    /**
     * Setzt den Wert der Hilfvariable, die festhält, wie viel in der Wettrunde von dem Spieler bereits gesetzt wurde.
     * Wichtig, falls er beim Call oder Re-Raise nur noch ergänzen muss.
     * @param chips Anzahl der Chips
     */
    public void addPutIntoPot(int chips){
        this.putIntoPot += chips;
        this.totalPutIntoPot += chips;
    }
    /**
     * Setzt alle Variablen zurück, die für eine neue Wettrunde relevant sind.
     */
    public void resetForNewBettingRound(){
        this.putIntoPot = 0;
    }
    /**
     * Setzt alle Variablen zurück, die für eine neue Hand relevant sind.
     */
    public void resetForNewHand(){
        if(this.chipStack <= 0){
            this.isAlive = false;
            this.isInGame = false;
            this.isAllIn = false;
        }
        this.putIntoPot = 0;
        this.totalPutIntoPot = 0;
        this.setHoleOne(null);
        this.setHoleTwo(null);
        this.kickerCache = 0;
        if(this.isAlive){
            this.isAllIn = false;
            this.isInGame = true;
        }
    }
    /**
     * Setzt den Namen des Spielertyps, den dieser Spieler repräsentiert.
     * Wichtig für die Ausgabe, damit mal den Typ nachvollziehen kann.
     * @param name Name des Spielertyps
     */
    public void setTypeName(String name){
        this.type = name;
    }
    /**
     * Setzt die interne ID auf den Parameter-Wert; nur sinnvoll in Konstruktoren der Kinder
     * @param newID interne ID
     */
    public void setID(int newID){
        this.id = newID;
    }
    
    //Getter
    /**
     * Gibt die Anzahl der eigenen Chips zurück.
     * @return Anzahl der Chips
     */
    public int getChips(){
        return this.chipStack;
    }
    /**
     * Gibt die erste Handkarte als Objekt wieder.
     * @return erste Handkarte
     */
    public Card getHoleOne(){
        return this.holeOne;
    }
    /**
     * Gibt die zweite Handkarte als Objekt wieder.
     * @return zweite Handkarte
     */
    public Card getHoleTwo(){
        return this.holeTwo;
    }
    /**
     * Gibt die Flag zurück, ob der Spieler noch am Spiel teilnimmt.
     * @return false = ist ausgeschieden
     */
    public boolean getIsAlive(){
        return this.isAlive;
    }
    /**
     * Gibt die Flag zurück, ob der Spieler noch in der Hand ist.
     * @return false = hat gefoldet
     */
    public boolean getIsInGame(){
        return this.isInGame;
    }
    /**
     * Gibt die Flag zurück, ob der Spieler All-In gegangen ist.
     * @return true = ist All-In
     */
    public boolean getAllIn(){
        return this.isAllIn;
    }
    /**
     * Gibt die Anzahl der Chips wieder, die in der Wettrunde bereits von dem Spieler gesetzt worden sind.
     * @return Anzahl der Chips
     */
    public int getPutIntoPot(){
        return this.putIntoPot;
    }
    /**
     * Gibt die Anzahl der Chips wieder, die insgesamt in der Hand von diesem Spieler gesetzt worden sind.
     * Wichtig für die Entscheidungsfindung, um zu wissen, wie viel der Spieler schon investiert hat.
     * @return Anzahl der Chips
     */
    public int getTotalPutIntoPot(){
       return this.totalPutIntoPot;
    }
    /**
     * Gibt die Hilfsvariable wieder, die den Kicker der aktuell gehaltenen Hand repräsentiert.
     * @return interne ID der Kicker-Karten
     */
    public int getKickerCache(){
        return this.kickerCache;
    }
    /**
     * Gibt den Namen des Spielertyps wieder. Wichtig für die Identifizierung der Spieler.
     * @return Name des Spielertyps
     */
    public String getTypeName(){
        return this.type;
    }
    /**
     * Gibt die interne ID zurück; sinnvoll für das Festhalten der Statistiken
     * @return interne ID
     */
    public int getID(){
        return this.id;
    }
}
