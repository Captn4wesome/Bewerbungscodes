/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdembots;

/**
 * Repräsentiert eine Karte, die sich im Spiel befindet.
 * @author Administrator
 */
public class Card {
    int cardSuit; //In folgender Reihenfolge (0=Club, 1=Diamond, 2=Heart, 3=Spade)
    int cardValue; //Wert der Karte -2 (da bei 0 anfängt); mit J=11, Q=12, K=13, A=14
    /**
     * Konstruktor für die Klasse Card, die mit den Parametern für die Farbe und den Wert der Karte gestartet werden muss.
     * @param suit interne ID der Farbe (0 = Kreuz; 1 = Karo; 2 = Herz; 3 = Pik)
     * @param value interne ID des Wertes (12 = Ass; 11 = König; 10 = Dame; etc.)
     */
    public Card(int suit, int value){
        this.cardSuit = suit;
        this.cardValue = value;
    }
    
    
    //Setter & Getter
    /**
     * Setzt die Farbe der Karte auf den Parameter.
     * @param s 0 = Kreuz; 1 = Karo; 2 = Herz; 3 = Pik
     */
    public void setSuit(char s){
        this.cardSuit = s;
    }
    /**
     * Setzt den Wert der Karte auf den Parameter.
     * @param v 12 = Ass; 11 = König; 10 = Dame; etc.
     */
    public void setValue(int v){
        this.cardValue = v;
    }
    /**
     * Gibt die interne ID der Kartenfarbe zurück.
     * @return 0 = Kreuz; 1 = Karo; 2 = Herz; 3 = Pik
     */
    public int getSuit(){
        return this.cardSuit;
    }
    /**
     * Gibt die interne ID des Kartenwertes zurück.
     * @return 12 = Ass; 11 = König; 10 = Dame; etc.
     */
    public int getValue(){
        return this.cardValue;
    }
    /**
     * Gibt die eigentliche Farbe als char zurück.
     * Vereinfacht somit die Identifizierung dieser Karte.
     * @return c = Club; d = Diamond; h = Heart; s = Spade
     */
    public char getSuitSymbol(){
        char symbol = ' ';
        switch(this.cardSuit){
            case 0: symbol = 'c'; break;
            case 1: symbol = 'd'; break;
            case 2: symbol = 'h'; break;
            case 3: symbol = 's'; break;
            default: System.err.println("Probleme mit dem Symbol?");                    
        }
        return symbol;
    }
    /**
     * Gibt den tatsächlichen Wert der Karte als char zurück.
     * Vereinfacht so die Identifizierung der Karte.
     * @return T = 10; J = Bube; Q = Dame; K = König; A = Ass, Rest numerisch
     */
    public char getActualValue(){
        char actValue =' ';
        switch(this.cardValue){
            case 0: actValue = '2'; break;
            case 1: actValue = '3'; break;
            case 2: actValue = '4'; break;
            case 3: actValue = '5'; break;
            case 4: actValue = '6'; break;
            case 5: actValue = '7'; break;
            case 6: actValue = '8'; break;
            case 7: actValue = '9'; break;
            case 8: actValue = 'T'; break;
            case 9: actValue = 'J'; break;
            case 10: actValue = 'Q'; break;
            case 11: actValue = 'K'; break;
            case 12: actValue = 'A'; break;
            default: System.err.println("Probleme mit dem Symbol?");                    
        }
        return actValue;
    }
}
