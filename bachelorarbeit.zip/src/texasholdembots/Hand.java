/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package texasholdembots;
/**
 * Repräsentiert eine Hand, die man aus fünf Card-Objekten bilden kann.
 * Checkt auch, was für einen Rang diese Hand besitzt.
 * @author Administrator
 */
public class Hand {
    private Card[] c;    
    private int tieBreaker = 0;
    private int tieBreaker2 = 0;
    private int tieBreaker3 = 0;
    private int tieBreaker4 = 0;
    private int tieBreaker5 = 0;
    private int kicker = 0;
    private Card[] cs = new Card[5]; //Die sortierten Karten
    
    /**
     * Konstruktor für die Klasse Hand, die aus fünf Karten gebildet werden kann.
     * @param card1 Objekt der ersten Karte
     * @param card2 Objekt der zweiten Karte
     * @param card3 Objekt der dritten Karte
     * @param card4 Objekt der vierten Karte
     * @param card5 Objekt der fünften Karte
     */
    public Hand(Card card1, Card card2, Card card3, Card card4, Card card5){
        c = new Card[5];
        c[0] = card1;
        c[1] = card2;
        c[2] = card3;
        c[3] = card4;
        c[4] = card5;
        this.sortCards(c);
    }
    /**
     * Überprüft die Hand auf den Rang und den Kicker.
     * @return Handrang (10 = Royal Flush, 9 = Straight Flush, usw.)
     */
    public int evaluateHand(){
        if(this.checkForRoyalFlush()){
            kicker = this.tieBreaker();
            return 10;
        }else if(this.checkForStraightFlush()){
            kicker = this.tieBreaker();
            return 9;
        }else if(this.checkForQuads()){
            kicker = this.tieBreaker();
            return 8;
        }else if(this.checkForFullHouse()){
            kicker = this.tieBreaker();
            return 7;
        }else if(this.checkForFlush()){
            kicker = this.tieBreaker();
            return 6;
        }else if(this.checkForStraight()){
            kicker = this.tieBreaker();
            return 5;
        }else if(this.checkForTrips()){
            kicker = this.tieBreaker();
            return 4;
        }else if(this.checkForTwoPairs()){
            kicker = this.tieBreaker();
            return 3;
        }else if(this.checkForPair()){
            kicker = this.tieBreaker();
            return 2;
        }else{
            this.tieBreaker = cs[0].getValue();
            this.tieBreaker2 = cs[1].getValue();
            this.tieBreaker3 = cs[2].getValue();
            this.tieBreaker4 = cs[3].getValue();
            this.tieBreaker5 = cs[4].getValue();
            kicker = this.tieBreaker * 100000000;
            kicker = kicker + this.tieBreaker2 * 1000000;
            kicker = kicker + this.tieBreaker3 * 10000;
            kicker = kicker + this.tieBreaker4 * 100;
            kicker = kicker + this.tieBreaker5;
            return 1;
        }
    }
    
    /**
     * Sortiert die Handkarten, die im Konstruktor übergeben worden sind, der Größe nach absteigend
     * und bildet daraus einen neuen, sortierten Array.
     * @param k Array der Karten in dieser Hand.
     */
    private void sortCards(Card[] k){
        int value = -1;
        int id = -1;
        int id2 = -1;
        int id3 = -1;
        int id4 = -1;
        int id5 = -1;
        for(int i = 0; i < 5; i++){
            if(c[i].getValue() > value){
                value = c[i].getValue();
                id = i;
            }
        }
        value = -1;
        for(int i = 0; i < 5; i++){
            if(c[i].getValue() > value && i != id){
                value = c[i].getValue();
                id2 = i;
            }
        }
        value = -1;
        for(int i = 0; i < 5; i++){
            if(c[i].getValue() > value && (i != id && i != id2)){
                value = c[i].getValue();
                id3 = i;
            }
        }
        value = -1;
        for(int i = 0; i < 5; i++){
            if(c[i].getValue() > value && (i != id && i != id2 && i != id3)){
                value = c[i].getValue();
                id4 = i;
            }
        }
        value = -1;
        for(int i = 0; i < 5; i++){
            if(c[i].getValue() > value && (i != id && i != id2 && i != id3 && i != id4)){
                value = c[i].getValue();
                id5 = i;
            }
        }
        cs[0] = k[id];
        cs[1] = k[id2];
        cs[2] = k[id3];
        cs[3] = k[id4];
        cs[4] = k[id5];
    }
    /**
     * Überprüft, ob ein Royal Flush vorliegt.
     * @return true = Royal Flush
     */
    private boolean checkForRoyalFlush(){
        int suit = -1;
        if(cs[0].getValue() == 12){
            suit = cs[0].getSuit();
            if(cs[1].getValue() == 11 && cs[1].getSuit() == suit){
                if(cs[2].getValue() == 10 && cs[2].getSuit() == suit){
                    if(cs[3].getValue() == 9 && cs[3].getSuit() == suit){
                        if(cs[4].getValue() == 8 && cs[4].getSuit() == suit){
                            return true;
                        }
                    }
                }
            }
        }
        
        return false;
    }
    /**
     * Überprüft, ob ein Straight Flush vorliegt und übernimmt die höchste Karte als Kicker.
     * @return true = Straight Flush
     */
    private boolean checkForStraightFlush(){
        int suit = cs[0].getSuit();
        suit = cs[0].getSuit();
        if(cs[1].getValue() == (cs[0].getValue() - 1) && cs[1].getSuit() == suit){
            if(cs[2].getValue() == (cs[1].getValue() - 1) && cs[2].getSuit() == suit){
                if(cs[3].getValue() == (cs[2].getValue() - 1) && cs[3].getSuit() == suit){
                    if((cs[4].getValue() == (cs[3].getValue() - 1) || (cs[3].getValue() == 0 && cs[4].getValue() == 12)) && cs[4].getSuit() == suit){
                        this.tieBreaker = cs[0].getValue();
                        return true;
                    }
                }
            }
        }
        return false;
    }
    /**
     * Überprüft, ob ein Vierling vorliegt und speichert dessen Höhe und die des Kickers.
     * @return true = Vierling
     */
    private boolean checkForQuads(){
        if(cs[0].getValue() == cs[1].getValue() && cs[1].getValue() == cs[2].getValue() && cs[2].getValue() == cs[3].getValue()){
            this.tieBreaker = cs[0].getValue();
            this.tieBreaker2 = cs[4].getValue();            
            return true;
        }else if(cs[1].getValue() == cs[2].getValue() && cs[2].getValue() == cs[3].getValue() && cs[3].getValue() == cs[4].getValue()){
            this.tieBreaker = cs[1].getValue();
            this.tieBreaker2 = cs[0].getValue();
            return true;
        }else{
            return false;
        }
    }
    /**
     * Überprüft, ob ein Full House vorliegt und speichert die Kartenhöhen des Drillings bzw. Paares.
     * @return true = Full House
     */
    private boolean checkForFullHouse(){
        if(cs[0].getValue() == cs[1].getValue() && cs[3].getValue() == cs[4].getValue()){
            if(cs[2].getValue() == cs[0].getValue()){
                this.tieBreaker = cs[0].getValue();
                this.tieBreaker2 = cs[4].getValue();
                return true;
            }else if(cs[2].getValue() == cs[4].getValue()){
                this.tieBreaker2 = cs[0].getValue();
                this.tieBreaker = cs[4].getValue();
                return true;
            }
        }
        return false;
    }
    /**
     * Überprüft, ob ein Flush vorliegt und speichert die Kartenhöhen als Kicker.
     * @return true = Flush
     */
    private boolean checkForFlush(){
        int suit = cs[0].getSuit();
        if(cs[1].getSuit() == suit && cs[2].getSuit() == suit && cs[3].getSuit() == suit && cs[4].getSuit() == suit){
            this.tieBreaker = cs[0].getValue();
            this.tieBreaker2 = cs[1].getValue();
            this.tieBreaker3 = cs[2].getValue();
            this.tieBreaker4 = cs[3].getValue();
            this.tieBreaker5 = cs[4].getValue();           
            return true;
        }
        return false;
    }
    /**
     * Überprüft, ob eine Straße vorliegt und speichert auch dessen Wert.
     * @return true = Straight
     */
    private boolean checkForStraight(){
        if(cs[1].getValue() == (cs[0].getValue() - 1)){
            if(cs[2].getValue() == (cs[1].getValue() - 1)){
                if(cs[3].getValue() == (cs[2].getValue() - 1)){
                    if((cs[4].getValue() == (cs[3].getValue() - 1) || (cs[3].getValue() == 0 && cs[4].getValue() == 12))){
                        this.tieBreaker = cs[0].getValue();
                        return true;
                    }
                }
            }
        }
        return false;
    }
    /**
     * Überprüft, ob ein Drilling vorliegt und speichert dessen Höhe als auch die der Kicker.
     * @return true = Drilling
     */
    private boolean checkForTrips(){
        if(cs[0].getValue() == cs[1].getValue() && cs[1].getValue() == cs[2].getValue()){
            this.tieBreaker = cs[0].getValue();
            this.tieBreaker2 = cs[3].getValue();
            this.tieBreaker3 = cs[4].getValue();            
            return true;
        }else if(cs[1].getValue() == cs[2].getValue() && cs[2].getValue() == cs[3].getValue()){
            this.tieBreaker = cs[1].getValue();
            this.tieBreaker2 = cs[0].getValue();
            this.tieBreaker3 = cs[4].getValue();
            return true;
        }else if(cs[2].getValue() == cs[3].getValue() && cs[3].getValue() == cs[4].getValue()){
            this.tieBreaker = cs[2].getValue();
            this.tieBreaker2 = cs[0].getValue();
            this.tieBreaker3 = cs[1].getValue(); 
            return true;
        }
        return false;
    }
    /**
     * Überprüft, ob zwei Paare vorliegen und speichert deren Höhen als auch die des Kickers.
     * @return true = zwei Paare
     */
    private boolean checkForTwoPairs(){
        if(cs[0].getValue() == cs[1].getValue()){
            if(cs[2].getValue() == cs[3].getValue()){
                this.tieBreaker = cs[0].getValue();
                this.tieBreaker2 = cs[2].getValue();
                this.tieBreaker3 = cs[4].getValue();
                return true;
            }else if(cs[3].getValue() == cs[4].getValue()){
                this.tieBreaker = cs[0].getValue();
                this.tieBreaker2 = cs[3].getValue();
                this.tieBreaker3 = cs[2].getValue();
                return true;
            }
        }else if(cs[1].getValue() == cs[2].getValue()){
            if(cs[3].getValue() == cs[4].getValue()){
                this.tieBreaker = cs[1].getValue();
                this.tieBreaker2 = cs[3].getValue();
                this.tieBreaker3 = cs[0].getValue();
                return true;
            }
        }
        return false;
    }
    /**
     * Überprüft, ob nur ein Paar vorliegt und speichert die Kartenhöhen.
     * @return true = ein Paar
     */
    private boolean checkForPair(){
        if(cs[0].getValue() == cs[1].getValue()){
            this.tieBreaker = cs[0].getValue();
            this.tieBreaker2 = cs[2].getValue();
            this.tieBreaker3 = cs[3].getValue();
            this.tieBreaker4 = cs[4].getValue();
            return true;
        }else if(cs[1].getValue() == cs[2].getValue()){
            this.tieBreaker = cs[1].getValue();
            this.tieBreaker2 = cs[0].getValue();
            this.tieBreaker3 = cs[3].getValue();
            this.tieBreaker4 = cs[4].getValue();
            return true;
        }else if(cs[2].getValue() == cs[3].getValue()){
            this.tieBreaker = cs[2].getValue();
            this.tieBreaker2 = cs[0].getValue();
            this.tieBreaker3 = cs[1].getValue();
            this.tieBreaker4 = cs[4].getValue();
            return true;
        }else if(cs[3].getValue() == cs[4].getValue()){
            this.tieBreaker = cs[3].getValue();
            this.tieBreaker2 = cs[0].getValue();
            this.tieBreaker3 = cs[1].getValue();
            this.tieBreaker4 = cs[2].getValue();
            return true;
        }
        return false;
    }
    /**
     * Rechnet die Kicker zusammen, um so einen internen Tiebreaker-Wert zu ermitteln, die beim Showdown entscheiden,
     * welche der Hände vom selbem Rang stärker sind.
     * @return ermittelter Wert
     */
    public int tieBreaker(){
        int score = this.tieBreaker * 100000000;
        score = score + this.tieBreaker2 * 1000000;
        score = score + this.tieBreaker3 * 10000;
        score = score + this.tieBreaker4 * 100;
        score = score + this.tieBreaker5;
        return score;
    }
    
    /**
     * Gibt den Wert des internen Tiebreakers zurück.
     * @return interner Wert des Kickers
     */
    public int getKicker(){
        return this.kicker;
    }
    
    //NUR TESTGETTER!!!
    /**
     * Gibt die sortierte Hand als Card-Array zurück.
     * @return sortierte Hand aus fünf Karten.
     */
    public Card[] getSortedHand(){
        return this.cs;
    }
    /**
     * Gibt die gewünschte Karte innerhalb der sortierten Hand wieder.
     * @param id Array-ID der gesuchten, sortierten Karte
     * @return Karte als Card-Objekt
     */
    public Card getSortedCard(int id){
        return this.cs[id];
    }
}
