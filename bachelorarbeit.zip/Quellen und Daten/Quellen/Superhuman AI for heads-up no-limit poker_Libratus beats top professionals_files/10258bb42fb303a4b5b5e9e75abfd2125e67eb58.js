hawkeye_target={"content": ["181116-WebinarTarget", "020519-CERNET-Sci", "021819-FNP-Chem", "190214-Eppendorf", "030119-CYRUS", "030119-10X"], "madgex": [{"campaignid": 71, "jobcount": 57, "campaignname": "Computer Science"}, {"campaignid": 81, "jobcount": 45, "campaignname": "Mathematics"}]};
hawkeye_insert_madgex_widget(hawkeye_target.madgex);
