(function ($) {
  // Store our function as a property of Drupal.behaviors.
  Drupal.behaviors.highwire_citation_export = { attach: function (context, settings) {
    var success = false;

    $('.highwire-citation-export-link-ajax', context).click(function(){
      $('.highwire-citation-export-link-ajax-popup').dialog({modal:true, draggable:false, maxWidth:700});
      return false;
    });

  }};
}(jQuery));
