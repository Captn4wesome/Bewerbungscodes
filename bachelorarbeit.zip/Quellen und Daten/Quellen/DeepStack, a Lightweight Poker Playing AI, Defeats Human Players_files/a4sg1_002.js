!function(){"use strict";if("querySelector"in document&&"addEventListener"in window){Element.prototype.matches||(Element.prototype.matches=Element.prototype.msMatchesSelector||Element.prototype.webkitMatchesSelector),Element.prototype.closest||(Element.prototype.closest=function(e){var t=this;if(!document.documentElement.contains(this))return null;do{if(t.matches(e))return t;t=t.parentElement}while(null!==t);return null});for(var d=document.querySelectorAll(".menu-toggle"),e=document.querySelectorAll("nav .dropdown-menu-toggle"),t=document.querySelectorAll("nav ul a"),c=document.body,u=document.documentElement,o=function(e,t){if(!t)t=this;if(t.getAttribute("data-nav"))var o=document.getElementById(t.getAttribute("data-nav"));else o=document.getElementById(t.closest("nav").getAttribute("id"));var n=o.getElementsByTagName("ul")[0];if(o.classList.contains("toggled")){if(o.classList.remove("toggled"),u.classList.remove("mobile-menu-open"),n.setAttribute("aria-hidden","true"),t.setAttribute("aria-expanded","false"),c.classList.contains("dropdown-hover"))for(var r=n.querySelectorAll("li.menu-item-has-children"),l=0;l<r.length;l++)r[l].querySelector(".dropdown-menu-toggle").removeAttribute("tabindex"),r[l].querySelector(".dropdown-menu-toggle").setAttribute("role","presentation"),r[l].querySelector(".dropdown-menu-toggle").removeAttribute("aria-expanded")}else if(o.classList.add("toggled"),u.classList.add("mobile-menu-open"),n.setAttribute("aria-hidden","false"),t.setAttribute("aria-expanded","true"),c.classList.contains("dropdown-hover"))for(r=n.querySelectorAll("li.menu-item-has-children"),l=0;l<r.length;l++)r[l].querySelector(".dropdown-menu-toggle").setAttribute("tabindex","0"),r[l].querySelector(".dropdown-menu-toggle").setAttribute("role","button"),r[l].querySelector(".dropdown-menu-toggle").setAttribute("aria-expanded","false")},n=0;n<d.length;n++)d[n].addEventListener("click",o,!1);var r=function(e,t){if(!t)t=this;if((t.closest("nav").classList.contains("toggled")||u.classList.contains("slide-opened"))&&!c.classList.contains("dropdown-click")){e.preventDefault();var o=t.closest("li"),n=o.querySelector(".dropdown-menu-toggle");if("false"!==n.getAttribute("aria-expanded")&&n.getAttribute("aria-expanded")?n.setAttribute("aria-expanded","false"):n.setAttribute("aria-expanded","true"),o.querySelector(".sub-menu"))var r=o.querySelector(".sub-menu");else r=o.querySelector(".children");o.classList.toggle("sfHover"),r.classList.toggle("toggled-on")}e.stopPropagation()};for(n=0;n<e.length;n++)e[n].addEventListener("click",r,!1),e[n].addEventListener("keypress",function(e){13===(e.which||e.keyCode)&&r(e,this)},!1);var l=function(){for(var e=0;e<d.length;e++)if(null===d[e].offsetParent){var t=d[e].closest("nav");if(t&&t.classList.contains("toggled")){var o=t.getElementsByTagName("ul")[0],n=o.getElementsByTagName("li"),r=o.getElementsByTagName("ul");document.activeElement.blur(),t.classList.remove("toggled"),u.classList.remove("mobile-menu-open"),d[e].setAttribute("aria-expanded","false");for(var l=0;l<n.length;l++)n[l].classList.remove("sfHover");for(var s=0;s<r.length;s++)r[s].classList.remove("toggled-on");if(o&&o.removeAttribute("aria-hidden"),c.classList.contains("dropdown-hover"))for(var i=t.querySelectorAll("li.menu-item-has-children"),a=0;a<i.length;a++)i[a].querySelector(".dropdown-menu-toggle").removeAttribute("tabindex"),i[a].querySelector(".dropdown-menu-toggle").setAttribute("role","presentation"),i[a].querySelector(".dropdown-menu-toggle").removeAttribute("aria-expanded")}}};if(window.addEventListener("resize",l,!1),window.addEventListener("orientationchange",l,!1),c.classList.contains("dropdown-hover"))for(n=0;n<t.length;n++)t[n].addEventListener("click",function(e){if(this.hostname!==window.location.hostname&&document.activeElement.blur(),this.closest("nav").classList.contains("toggled")||u.classList.contains("slide-opened")){var t=this.getAttribute("href");if("#"==t||""==t){e.preventDefault();var o=this.closest("li");o.classList.toggle("sfHover");var n=o.querySelector(".sub-menu");n&&n.classList.toggle("toggled-on")}}},!1)}}();
/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var e,t=location.hash.substring(1);/^[A-z0-9_-]+$/.test(t)&&(e=document.getElementById(t))&&(/^(?:a|select|input|button|textarea)$/i.test(e.tagName)||(e.tabIndex=-1),e.focus())},!1),function(){"use strict";if("querySelector"in document&&"addEventListener"in window){var e=document.body;e.addEventListener("mousedown",function(){e.classList.add("using-mouse")}),e.addEventListener("keydown",function(){e.classList.remove("using-mouse")})}}(),function(){"use strict";if("querySelector"in document&&"addEventListener"in window&&document.body.classList.contains("dropdown-hover"))for(var e=document.querySelectorAll("nav ul a"),n=document.querySelectorAll(".sf-menu .menu-item-has-children"),t=function(){if(!this.closest("nav").classList.contains("toggled")&&!this.closest("nav").classList.contains("slideout-navigation"))for(var e=this;-1===e.className.indexOf("main-nav");)"li"===e.tagName.toLowerCase()&&(-1!==e.className.indexOf("sfHover")?e.className=e.className.replace(" sfHover",""):e.className+=" sfHover"),e=e.parentElement},o=0;o<e.length;o++)e[o].addEventListener("focus",t),e[o].addEventListener("blur",t);if("touchend"in document.documentElement)for(o=0;o<n.length;o++)n[o].addEventListener("touchend",function(e){if(!n[o].closest("nav").classList.contains("toggled")&&1===e.touches.length&&(e.stopPropagation(),!this.classList.contains("sfHover"))){e.target!==this&&e.target.parentNode!==this||e.preventDefault();var t=n[o].closest("nav").querySelectorAll("ul.toggled-on");if(t&&!this.closest("ul").classList.contains("toggled-on")&&!this.closest("li").classList.contains("sfHover"))for(var s=0;s<t.length;s++)t[s].classList.remove("toggled-on"),t[s].closest("li").classList.remove("sfHover");this.classList.add("sfHover"),document.addEventListener("touchend",closeDropdown=function(e){e.stopPropagation(),this.classList.remove("sfHover"),document.removeEventListener("touchend",closeDropdown)})}},!0)}();
!function(){"use strict";if("querySelector"in document&&"addEventListener"in window){var e=function(e,t){if(e.preventDefault(),!t)t=this;var a=t.closest("nav");t.getAttribute("data-nav")&&(a=document.querySelector(this.getAttribute("data-nav")));var s=a.querySelector(".navigation-search"),c=document.querySelectorAll('a[href], area[href], input:not([disabled]):not(.navigation-search), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), [tabindex="0"]');if(s.classList.contains("nav-search-active")){t.classList.remove("close-search"),t.classList.remove("active"),document.activeElement.blur(),t.classList.remove("sfHover"),s.classList.remove("nav-search-active"),t.style.float="";for(var i=0;i<c.length;i++)c[i].closest(".navigation-search")||c[i].closest(".search-item")||c[i].removeAttribute("tabindex")}else{t.classList.add("active"),s.classList.add("nav-search-active"),s.querySelector(".search-field").focus();for(i=0;i<c.length;i++)c[i].closest(".navigation-search")||c[i].closest(".search-item")||c[i].setAttribute("tabindex","-1");setTimeout(function(){t.classList.add("sfHover")},50),document.body.classList.contains("nav-aligned-center")?(t.style.opacity=0,setTimeout(function(){t.classList.add("close-search"),t.style.opacity=1,document.body.classList.contains("rtl")?t.style.float="left":t.style.float="right"},250)):t.classList.add("close-search")}};if(document.body.classList.contains("nav-search-enabled")){for(var t=document.querySelectorAll(".search-item"),a=0;a<t.length;a++)t[a].addEventListener("click",e,!1);document.addEventListener("click",function(t){if(document.querySelector(".navigation-search.nav-search-active")&&!t.target.closest(".navigation-search")&&!t.target.closest(".search-item"))for(var a=document.querySelectorAll(".search-item.active"),s=0;s<a.length;s++)e(t,a[s])},!1),document.addEventListener("keydown",function(t){if(document.querySelector(".navigation-search.nav-search-active")&&27===(t.which||t.keyCode))for(var a=document.querySelectorAll(".search-item.active"),s=0;s<a.length;s++)e(t,a[s])},!1)}}}();
var addComment={moveForm:function(a,b,c,d){var e,f,g,h,i=this,j=i.I(a),k=i.I(c),l=i.I("cancel-comment-reply-link"),m=i.I("comment_parent"),n=i.I("comment_post_ID"),o=k.getElementsByTagName("form")[0];if(j&&k&&l&&m&&o){i.respondId=c,d=d||!1,i.I("wp-temp-form-div")||(e=document.createElement("div"),e.id="wp-temp-form-div",e.style.display="none",k.parentNode.insertBefore(e,k)),j.parentNode.insertBefore(k,j.nextSibling),n&&d&&(n.value=d),m.value=b,l.style.display="",l.onclick=function(){var a=addComment,b=a.I("wp-temp-form-div"),c=a.I(a.respondId);if(b&&c)return a.I("comment_parent").value="0",b.parentNode.insertBefore(c,b),b.parentNode.removeChild(b),this.style.display="none",this.onclick=null,!1};try{for(var p=0;p<o.elements.length;p++)if(f=o.elements[p],h=!1,"getComputedStyle"in window?g=window.getComputedStyle(f):document.documentElement.currentStyle&&(g=f.currentStyle),(f.offsetWidth<=0&&f.offsetHeight<=0||"hidden"===g.visibility)&&(h=!0),"hidden"!==f.type&&!f.disabled&&!h){f.focus();break}}catch(q){}return!1}},I:function(a){return document.getElementById(a)}};
var TVE_Dash=TVE_Dash||{};if(!ThriveGlobal||!ThriveGlobal.$j){var __thrive_$oJ=window.$,ThriveGlobal={$j:jQuery.noConflict()};__thrive_$oJ&&(window.$=__thrive_$oJ)}!function(a){TVE_Dash.ajax_sent=!1;var b={},c={};TVE_Dash.add_load_item=function(d,e,f){if("function"!=typeof f&&(f=a.noop),TVE_Dash.ajax_sent){var g={},h={};return g[d]=e,h[d]=f,this.send_ajax(g,h),!0}return e?(b[d]&&console.error&&console.error(d+" ajax action already defined"),b[d]=e,c[d]=f,!0):(console.error&&console.error("missing ajax data"),!1)},TVE_Dash.ajax_load_css=function(b){a.each(b,function(b,c){b+="-css",a("link#"+b).length||a('<link rel="stylesheet" id="'+b+'" type="text/css" href="'+c+'"/>').appendTo("head")})},TVE_Dash.ajax_load_js=function(b){var c=document.body;a.each(b,function(d,e){if(-1!==d.indexOf("_before"))return!0;var f=document.createElement("script");if(b[d+"_before"]){a('<script type="text/javascript">'+b[d+"_before"]+"</script>").after(c.lastChild)}d&&(f.id=d+"-script"),f.src=e,c.appendChild(f)})},TVE_Dash.send_ajax=function(b,c){a.ajax({url:tve_dash_front.ajaxurl,xhrFields:{withCredentials:!0},data:{action:"tve_dash_front_ajax",tve_dash_data:b},dataType:"json",type:"post"}).done(function(b){b&&a.isPlainObject(b)&&(b.__resources&&(b.__resources.css&&TVE_Dash.ajax_load_css(b.__resources.css),b.__resources.js&&TVE_Dash.ajax_load_js(b.__resources.js),delete b.__resources),a.each(b,function(a,b){if("function"!=typeof c[a])return!0;c[a].call(null,b)}))})},a(function(){setTimeout(function(){var d=new a.Event("tve-dash.load");return a(document).trigger(d),!a.isEmptyObject(b)&&(!(!tve_dash_front.force_ajax_send&&tve_dash_front.is_crawler)&&(TVE_Dash.send_ajax(b,c),void(TVE_Dash.ajax_sent=!0)))})})}(ThriveGlobal.$j);
function q2w3_sidebar_init(){for(var a=0;a<q2w3_sidebar_options.length;a++)q2w3_sidebar(q2w3_sidebar_options[a]);jQuery(window).on("resize",function(){for(var a=0;a<q2w3_sidebar_options.length;a++)q2w3_sidebar(q2w3_sidebar_options[a])});var b=function(){for(var a=["WebKit","Moz","O","Ms",""],b=0;b<a.length;b++)if(a[b]+"MutationObserver"in window)return window[a[b]+"MutationObserver"];return!1}();if(0==q2w3_sidebar_options[0].disable_mo_api&&b){q2w3Refresh=!1;var c=new b(function(a){a.forEach(function(a){q2w3_exclude_mutations_array(q2w3_sidebar_options).indexOf(a.target.id)==-1&&a.target.className.indexOf("q2w3-fixed-widget-container")==-1&&(q2w3Refresh=!0)})});c.observe(document.body,{childList:!0,attributes:!0,attributeFilter:["style","class"],subtree:!0}),setInterval(function(){if(q2w3Refresh){for(var a=0;a<q2w3_sidebar_options.length;a++)q2w3_sidebar(q2w3_sidebar_options[a]);q2w3Refresh=!1}},300)}else console.log("MutationObserver not supported or disabled!"),q2w3_sidebar_options[0].refresh_interval>0&&setInterval(function(){for(var a=0;a<q2w3_sidebar_options.length;a++)q2w3_sidebar(q2w3_sidebar_options[a])},q2w3_sidebar_options[0].refresh_interval)}function q2w3_exclude_mutations_array(a){for(var b=new Array,c=0;c<a.length;c++)if(a[c].widgets.length>0)for(var d=0;d<a[c].widgets.length;d++)b.push(a[c].widgets[d]),b.push(a[c].widgets[d]+"_clone");return b}function q2w3_sidebar(a){function b(){}function j(b){var c=b.offset_top-b.fixed_margin_top,f=e-a.margin_bottom;a.stop_id&&jQuery("#"+a.stop_id).length&&(f=jQuery("#"+a.stop_id).offset().top-a.margin_bottom);var g;g=a.width_inherit?"inherit":b.obj.css("width");var h=!1,i=!1,j=!1;jQuery(window).on("scroll."+a.sidebar,function(e){if(jQuery(window).width()<=a.screen_max_width||jQuery(window).height()<=a.screen_max_height)j||(b.obj.css("position",""),b.obj.css("top",""),b.obj.css("bottom",""),b.obj.css("width",""),b.obj.css("margin",""),b.obj.css("padding",""),widget_obj.parent().css("height",""),jQuery("#"+b.clone_id).length>0&&jQuery("#"+b.clone_id).remove(),j=!0,h=!1,i=!1);else{var k=jQuery(this).scrollTop();k+b.fixed_margin_bottom>=f?(i||(b.obj.css("position","fixed"),b.obj.css("top",""),b.obj.css("width",g),jQuery("#"+b.clone_id).length<=0&&b.obj.before(b.clone),i=!0,h=!1,j=!1),b.obj.css("bottom",k+d+b.next_widgets_height-f)):k>=c?h||(b.obj.css("position","fixed"),b.obj.css("top",b.fixed_margin_top),b.obj.css("bottom",""),b.obj.css("width",g),jQuery("#"+b.clone_id).length<=0&&b.obj.before(b.clone),h=!0,i=!1,j=!1):j||(b.obj.css("position",""),b.obj.css("top",""),b.obj.css("bottom",""),b.obj.css("width",""),jQuery("#"+b.clone_id).length>0&&jQuery("#"+b.clone_id).remove(),j=!0,h=!1,i=!1)}}).trigger("scroll."+a.sidebar)}if(!a)return!1;if(!a.widgets)return!1;if(a.widgets.length<1)return!1;a.sidebar||(a.sidebar="q2w3-default-sidebar");var c=new Array,d=jQuery(window).height(),e=jQuery(document).height(),f=a.margin_top;jQuery("#wpadminbar").length&&(f=a.margin_top+jQuery("#wpadminbar").height()),jQuery(".q2w3-widget-clone-"+a.sidebar).remove();for(var g=0;g<a.widgets.length;g++)widget_obj=jQuery("#"+a.widgets[g]),widget_obj.css("position",""),widget_obj.attr("id")?(c[g]=new b,c[g].obj=widget_obj,c[g].clone=widget_obj.clone(),c[g].clone.children().remove(),c[g].clone_id=widget_obj.attr("id")+"_clone",c[g].clone.addClass("q2w3-widget-clone-"+a.sidebar),c[g].clone.attr("id",c[g].clone_id),c[g].clone.css("height",widget_obj.height()),c[g].clone.css("visibility","hidden"),c[g].offset_top=widget_obj.offset().top,c[g].fixed_margin_top=f,c[g].height=widget_obj.outerHeight(!0),c[g].fixed_margin_bottom=f+c[g].height,f+=c[g].height):c[g]=!1;for(var i,h=0,g=c.length-1;g>=0;g--)c[g]&&(c[g].next_widgets_height=h,c[g].fixed_margin_bottom+=h,h+=c[g].height,i||(i=widget_obj.parent(),i.addClass("q2w3-fixed-widget-container"),i.css("height",""),i.height(i.height())));jQuery(window).off("scroll."+a.sidebar);for(var g=0;g<c.length;g++)c[g]&&j(c[g])}"undefined"!=typeof q2w3_sidebar_options&&q2w3_sidebar_options.length>0?window.jQuery?q2w3_sidebar_options[0].window_load_hook?jQuery(window).load(q2w3_sidebar_init()):jQuery(document).ready(q2w3_sidebar_init()):console.log("jQuery is not loaded!"):console.log("q2w3_sidebar_options not found!");
window.advadsGAAjaxAds={};
window.advadsGAPassiveAds={};
(function($){
if(typeof advanced_ads_pro!=='undefined'){
advanced_ads_pro.observers.add(function(event){
if(event.event==='inject_passive_ads'){
var server='all';
if($.isArray(event.ad_ids)&&!event.ad_ids.length){
event.ad_ids={};}
advadsGAPassiveAds=advads_tracking_utils('concat', advadsGAPassiveAds, event.ad_ids);
var filteredIds=removeDelayedAdId(event.ad_ids);
var advads_ad_ids;
if(advadsTracking.method==='frontend'){
advads_ad_ids=advads_tracking_utils('concat', advads_tracking_ads, filteredIds);
advads_tracking_ads=[];
}else{
advads_ad_ids=filteredIds;
server='passive';
}
advads_track_ads(advads_ad_ids, server);
}
if(event.event==='inject_ajax_ads'){
if($.isArray(event.ad_ids)&&!event.ad_ids.length){
event.ad_ids={};}
advadsGAAjaxAds=advads_tracking_utils('concat', advadsGAAjaxAds,  event.ad_ids);
var filteredIds=removeDelayedAdId(event.ad_ids);
advads_track_ads(filteredIds, 'analytics');
}});
}}(jQuery));
function removeDelayedAdId(ids){
if(jQuery('[data-delayedgatrackid]').length){
jQuery('[data-delayedgatrackid]').each(function(){
var id=parseInt(jQuery(this).attr('data-delayedgatrackid'));
var bid=parseInt(jQuery(this).attr('data-delayedgabid'));
if(advads_tracking_utils('hasAd', ids)){
if('undefined'!=typeof ids[bid]){
var index=ids[bid].indexOf(id);
if(-1!=index){
ids[bid].splice(index, 1);
}}
}});
}
return ids;
}
jQuery(document).ready(function($){
if('undefined'==typeof advads_tracking_ads) return;
advads_tracking_ads=removeDelayedAdId(advads_tracking_ads);
if(typeof advanced_ads_pro==='undefined'){
if(advads_tracking_utils('hasAd', advads_tracking_ads)){
for(var bid in advads_tracking_ads){
if('frontend'==advads_tracking_methods[bid]){
advads_track_ads(advads_tracking_ads);
advads_tracking_ads={1:[]};}}
}}
});
jQuery(document).on('advads_track_ads', function(e, ad_ids){
advads_track_ads(ad_ids);
});
jQuery(document).on('advads-layer-trigger', function(e){
if('undefined'==typeof advadsGATracking){
return;
}
advads_delayed_track_event(e);
})
jQuery(document).on('advads-sticky-trigger', function(e){
if('undefined'==typeof advadsGATracking){
return;
}
advads_delayed_track_event(e);
});
function advads_delayed_track_event(ev){
var $el=jQuery(ev.target);
var $vector=[];
if($el.attr('data-delayedgatrackid')){
$vector=$el;
}else{
$vector=$el.find('[data-delayedgatrackid]');
}
if($vector.length){
var ids={};
$vector.each(function(){
var bid=parseInt(jQuery(this).attr('data-delayedgabid'));
if('undefined'==typeof ids[bid]){
ids[bid]=[];
}
ids[bid].push(parseInt(jQuery(this).attr('data-delayedgatrackid')));
});
if('undefined'==typeof advadsGATracking.delayedAds){
advadsGATracking.delayedAds={};}
advadsGATracking.delayedAds=advads_tracking_utils('concat', advadsGATracking.delayedAds, ids);
advads_track_ads(advadsGATracking.delayedAds, 'delayed');
}}
function advads_tracking_utils(){
if(!arguments.hasOwnProperty(0)) return;
var fn=arguments[0];
var args=Array.prototype.slice.call(arguments, 1);
var utils={
hasAd: function(data){
for(var i in data){
if(jQuery.isArray(data[i])){
if(data[i].length){
return true;
}}
}
return false;
},
concat: function(){
var result={};
for(var i in args){
for(var j in args[i]){
if('undefined'==typeof result[j]){
result[j]=args[i][j];
}else{
result[j]=result[j].concat(args[i][j]);
}}
}
return result;
},
blogUseGA: function(bid){
if('ga'!=advads_tracking_methods[bid]&&false===advads_tracking_parallel[bid]){
return false;
}
if(''==advads_gatracking_uids[bid]){
return false;
}
return true;
},
adsByBlog: function(ads, bid){
var result={};
if('undefined'!=typeof ads[bid]){
result[bid]=ads[bid];
return result;
}
return {};},
};
if('function'==typeof utils[fn]){
return utils[fn].apply(null, args);
}}
function advads_track_ads(advads_ad_ids, server){
if(!advads_tracking_utils('hasAd', advads_ad_ids)) return;
if('undefined'==typeof server) server='all';
for(var bid in advads_ad_ids){
var data={
ads: advads_ad_ids[bid],
};
if(advads_tracking_utils('blogUseGA', bid)){
if('undefined'==typeof advadsGATracking){
window.advadsGATracking={};}
if('undefined'==typeof advadsGATracking.deferedAds){
window.advadsGATracking.deferedAds={};}
if('local'!=server){
advadsGATracking.deferedAds=advads_tracking_utils(
'concat',
advadsGATracking.deferedAds,
advads_tracking_utils('adsByBlog', advads_ad_ids, bid)
);
if('delayed'==server){
jQuery(document).trigger('advadsGADelayedTrack');
var passiveDelayed={};
passiveDelayed[bid]=[];
if(-1==['frontend','ga'].indexOf(advads_tracking_methods[bid])){
if(advads_tracking_utils('hasAd', advads_tracking_utils('adsByBlog', advadsGAPassiveAds, bid))){
for(var i in advads_ad_ids[bid]){
if(-1!=advadsGAPassiveAds[bid].indexOf(advads_ad_ids[bid][i])){
passiveDelayed[bid].push(advads_ad_ids[i]);
}}
}
if(passiveDelayed[bid].length){
for(var j in passiveDelayed[bid]){
advadsGAPassiveAds[bid].splice(advadsGAPassiveAds[bid].indexOf(passiveDelayed[j]), 1);
}
jQuery.post(advads_tracking_urls[bid], {ads:passiveDelayed[bid]}, function(response){});
}}
}else{
if('passive'==server &&
advads_tracking_utils('hasAd', advads_tracking_utils('adsByBlog', advads_ad_ids, bid)) &&
-1!=['onrequest','shutdown'].indexOf(advads_tracking_methods[bid])
){
jQuery.post(advads_tracking_urls[bid], data, function(response){});
}
jQuery(document).trigger('advadsGADeferedTrack');
}}
if(advads_tracking_parallel[bid]&&'analytics'!=server&&advads_tracking_methods[bid]=='frontend'){
if(advads_tracking_utils('hasAd', advads_tracking_utils('adsByBlog', advadsGAAjaxAds, bid))){
var removed=[];
for(var i in advadsGAAjaxAds[bid]){
var index=data.ads.indexOf(advadsGAAjaxAds[bid][i]);
if(-1!=index){
data.ads.splice(index, 1);
removed.push(advadsGAAjaxAds[bid][i]);
}}
if(removed.length){
for(var j in removed){
index=advadsGAAjaxAds[bid].indexOf(removed[j]);
advadsGAAjaxAds[bid].splice(index, 1);
}}
}
if(data.ads.length){
jQuery.post(advads_tracking_urls[bid], data, function(response){});
}}
}else{
if('analytics'!=server){
jQuery.post(advads_tracking_urls[bid], {ads:data.ads}, function(response){});
}}
}};
!function(e){var n=!1;if("function"==typeof define&&define.amd&&(define(e),n=!0),"object"==typeof exports&&(module.exports=e(),n=!0),!n){var o=window.Cookies,t=window.Cookies=e();t.noConflict=function(){return window.Cookies=o,t}}}(function(){function e(){for(var e=0,n={};e<arguments.length;e++){var o=arguments[e];for(var t in o)n[t]=o[t]}return n}function n(o){function t(n,r,i){var c;if("undefined"!=typeof document){if(arguments.length>1){if(i=e({path:"/"},t.defaults,i),"number"==typeof i.expires){var a=new Date;a.setMilliseconds(a.getMilliseconds()+864e5*i.expires),i.expires=a}i.expires=i.expires?i.expires.toUTCString():"";try{c=JSON.stringify(r),/^[\{\[]/.test(c)&&(r=c)}catch(e){}r=o.write?o.write(r,n):encodeURIComponent(String(r)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g,decodeURIComponent),n=encodeURIComponent(String(n)),n=n.replace(/%(23|24|26|2B|5E|60|7C)/g,decodeURIComponent),n=n.replace(/[\(\)]/g,escape);var f="";for(var s in i)i[s]&&(f+="; "+s,i[s]!==!0&&(f+="="+i[s]));return document.cookie=n+"="+r+f}n||(c={});for(var p=document.cookie?document.cookie.split("; "):[],d=0;d<p.length;d++){var u=p[d].split("="),l=u.slice(1).join("=");'"'===l.charAt(0)&&(l=l.slice(1,-1));try{var g=u[0].replace(/(%[0-9A-Z]{2})+/g,decodeURIComponent);if(l=o.read?o.read(l,g):o(l,g)||l.replace(/(%[0-9A-Z]{2})+/g,decodeURIComponent),this.json)try{l=JSON.parse(l)}catch(e){}if(n===g){c=l;break}n||(c[g]=l)}catch(e){}}return c}}return t.set=t,t.get=function(e){return t.call(t,e)},t.getJSON=function(){return t.apply({json:!0},[].slice.call(arguments))},t.defaults={},t.remove=function(n,o){t(n,"",e(o,{expires:-1}))},t.withConverter=n,t}return n(function(){})});
;(function($){
$.fn.cardtable=function(options){
var $tables=this,
defaults={headIndex:0},
settings=$.extend({}, defaults, options),
headIndex;
if(options&&options.headIndex)
headIndex=options.headIndex;
else
headIndex=0;
return $tables.each(function(){
var $table=$(this);
if($table.hasClass('stacktable')){
return;
}
var table_css=$(this).prop('class');
var $stacktable=$('<div></div>');
if(typeof settings.myClass!=='undefined') $stacktable.addClass(settings.myClass);
var markup='';
var $caption, $topRow, headMarkup, bodyMarkup, tr_class;
$table.addClass('stacktable large-only');
$caption=$table.find(">caption").clone();
$topRow=$table.find('>thead>tr,>tbody>tr,>tfoot>tr,>tr').eq(0);
$table.siblings().filter('.small-only').remove();
$table.find('>tbody>tr').each(function(){
headMarkup='';
bodyMarkup='';
tr_class=$(this).prop('class');
$(this).find('>td,>th').each(function(cellIndex){
if($(this).html()!==''){
bodyMarkup +='<tr class="' + tr_class +'">';
if($topRow.find('>td,>th').eq(cellIndex).html()){
bodyMarkup +='<td class="st-key">'+$topRow.find('>td,>th').eq(cellIndex).html()+'</td>';
}else{
bodyMarkup +='<td class="st-key"></td>';
}
bodyMarkup +='<td class="st-val '+$(this).prop('class')  +'">'+$(this).html()+'</td>';
bodyMarkup +='</tr>';
}});
markup +='<table class=" '+ table_css +' stacktable small-only"><tbody>' + headMarkup + bodyMarkup + '</tbody></table>';
});
$table.find('>tfoot>tr>td').each(function(rowIndex,value){
if($.trim($(value).text())!==''){
markup +='<table class="'+ table_css + ' stacktable small-only"><tbody><tr><td>' + $(value).html() + '</td></tr></tbody></table>';
}});
$stacktable.prepend($caption);
$stacktable.append($(markup));
$table.before($stacktable);
});
};
$.fn.stacktable=function(options){
var $tables=this,
defaults={headIndex:0,displayHeader:true},
settings=$.extend({}, defaults, options),
headIndex;
if(options&&options.headIndex)
headIndex=options.headIndex;
else
headIndex=0;
return $tables.each(function(){
var table_css=$(this).prop('class');
var $stacktable=$('<table class="'+ table_css +' stacktable small-only"><tbody></tbody></table>');
if(typeof settings.myClass!=='undefined') $stacktable.addClass(settings.myClass);
var markup='';
var $table, $caption, $topRow, headMarkup, bodyMarkup, tr_class, displayHeader;
$table=$(this);
$table.addClass('stacktable large-only');
$caption=$table.find(">caption").clone();
$topRow=$table.find('>thead>tr,>tbody>tr,>tfoot>tr').eq(0);
displayHeader=$table.data('display-header')===undefined ? settings.displayHeader:$table.data('display-header');
$table.find('>tbody>tr, >thead>tr').each(function(rowIndex){
headMarkup='';
bodyMarkup='';
tr_class=$(this).prop('class');
if(rowIndex===0){
if(displayHeader){
markup +='<tr class=" '+tr_class +' "><th class="st-head-row st-head-row-main" colspan="2">'+$(this).find('>th,>td').eq(headIndex).html()+'</th></tr>';
}}else{
$(this).find('>td,>th').each(function(cellIndex){
if(cellIndex===headIndex){
headMarkup='<tr class="'+ tr_class+'"><th class="st-head-row" colspan="2">'+$(this).html()+'</th></tr>';
}else{
if($(this).html()!==''){
bodyMarkup +='<tr class="' + tr_class +'">';
if($topRow.find('>td,>th').eq(cellIndex).html()){
bodyMarkup +='<td class="st-key">'+$topRow.find('>td,>th').eq(cellIndex).html()+'</td>';
}else{
bodyMarkup +='<td class="st-key"></td>';
}
bodyMarkup +='<td class="st-val '+$(this).prop('class')  +'">'+$(this).html()+'</td>';
bodyMarkup +='</tr>';
}}
});
markup +=headMarkup + bodyMarkup;
}});
$stacktable.prepend($caption);
$stacktable.append($(markup));
$table.before($stacktable);
});
};
$.fn.stackcolumns=function(options){
var $tables=this,
defaults={},
settings=$.extend({}, defaults, options);
return $tables.each(function(){
var $table=$(this);
var $caption=$table.find(">caption").clone();
var num_cols=$table.find('>thead>tr,>tbody>tr,>tfoot>tr').eq(0).find('>td,>th').length;
if(num_cols<3)
return;
var $stackcolumns=$('<table class="stacktable small-only"></table>');
if(typeof settings.myClass!=='undefined') $stackcolumns.addClass(settings.myClass);
$table.addClass('stacktable large-only');
var tb=$('<tbody></tbody>');
var col_i=1;
while (col_i < num_cols){
$table.find('>thead>tr,>tbody>tr,>tfoot>tr').each(function(index){
var tem=$('<tr></tr>');
if(index===0) tem.addClass("st-head-row st-head-row-main");
var first=$(this).find('>td,>th').eq(0).clone().addClass("st-key");
var target=col_i;
if($(this).find("*[colspan]").length){
var i=0;
$(this).find('>td,>th').each(function(){
var cs=$(this).attr("colspan");
if(cs){
cs=parseInt(cs, 10);
target -=cs-1;
if((i+cs) > (col_i))
target +=i + cs - col_i -1;
i +=cs;
}else{
i++;
}
if(i > col_i)
return false;
});
}
var second=$(this).find('>td,>th').eq(target).clone().addClass("st-val").removeAttr("colspan");
tem.append(first, second);
tb.append(tem);
});
++col_i;
}
$stackcolumns.append($(tb));
$stackcolumns.prepend($caption);
$table.before($stackcolumns);
});
};}(jQuery));
(function($){
var selectors=[];
var check_binded=false;
var check_lock=false;
var defaults={
interval: 250,
force_process: false
};
var $window=$(window);
var $prior_appeared=[];
function process(){
check_lock=false;
for (var index=0, selectorsLength=selectors.length; index < selectorsLength; index++){
var $appeared=$(selectors[index]).filter(function(){
return $(this).is(':appeared');
});
$appeared.trigger('wpr_appear', [$appeared]);
if($prior_appeared[index]){
var $disappeared=$prior_appeared[index].not($appeared);
$disappeared.trigger('wpr_disappear', [$disappeared]);
}
$prior_appeared[index]=$appeared;
}};
function add_selector(selector){
selectors.push(selector);
$prior_appeared.push();
}
$.expr[':']['appeared']=function(element){
var $element=$(element);
if(!$element.is(':visible')){
return false;
}
var window_left=$window.scrollLeft();
var window_top=$window.scrollTop();
var offset=$element.offset();
var left=offset.left;
var top=offset.top;
if(top + $element.height() >=window_top &&
top - ($element.data('appear-top-offset')||0) <=window_top + $window.height() &&
left + $element.width() >=window_left &&
left - ($element.data('appear-left-offset')||0) <=window_left + $window.width()){
return true;
}else{
return false;
}};
$.fn.extend({
wpr_appear: function(options){
var opts=$.extend({}, defaults, options||{});
var selector=this.selector||this;
if(!check_binded){
var on_check=function(){
if(check_lock){
return;
}
check_lock=true;
setTimeout(process, opts.interval);
};
$(window).scroll(on_check).resize(on_check);
check_binded=true;
}
if(opts.force_process){
setTimeout(process, opts.interval);
}
add_selector(selector);
return $(selector);
}});
$.extend({
wpr_force_appear: function(){
if(check_binded){
process();
return true;
}
return false;
}});
})(function(){
if(typeof module!=='undefined'){
return require('jquery');
}else{
return jQuery;
}}());
!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):a("object"==typeof exports?require("jquery"):window.jQuery||window.Zepto)}(function(a){var b,c,d,e,f,g,h="Close",i="BeforeClose",j="AfterClose",k="BeforeAppend",l="MarkupParse",m="Open",n="Change",o="mfp",p="."+o,q="mfp-ready",r="mfp-removing",s="mfp-prevent-close",t=function(){},u=!!window.jQuery,v=a(window),w=function(a,c){b.ev.on(o+a+p,c)},x=function(b,c,d,e){var f=document.createElement("div");return f.className="mfp-"+b,d&&(f.innerHTML=d),e?c&&c.appendChild(f):(f=a(f),c&&f.appendTo(c)),f},y=function(c,d){b.ev.triggerHandler(o+c,d),b.st.callbacks&&(c=c.charAt(0).toLowerCase()+c.slice(1),b.st.callbacks[c]&&b.st.callbacks[c].apply(b,a.isArray(d)?d:[d]))},z=function(c){return c===g&&b.currTemplate.closeBtn||(b.currTemplate.closeBtn=a(b.st.closeMarkup.replace("%title%",b.st.tClose)),g=c),b.currTemplate.closeBtn},A=function(){a.magnificPopup.instance||(b=new t,b.init(),a.magnificPopup.instance=b)},B=function(){var a=document.createElement("p").style,b=["ms","O","Moz","Webkit"];if(void 0!==a.transition)return!0;for(;b.length;)if(b.pop()+"Transition"in a)return!0;return!1};t.prototype={constructor:t,init:function(){var c=navigator.appVersion;b.isLowIE=b.isIE8=document.all&&!document.addEventListener,b.isAndroid=/android/gi.test(c),b.isIOS=/iphone|ipad|ipod/gi.test(c),b.supportsTransition=B(),b.probablyMobile=b.isAndroid||b.isIOS||/(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent),d=a(document),b.popupsCache={}},open:function(c){var e;if(c.isObj===!1){b.items=c.items.toArray(),b.index=0;var g,h=c.items;for(e=0;e<h.length;e++)if(g=h[e],g.parsed&&(g=g.el[0]),g===c.el[0]){b.index=e;break}}else b.items=a.isArray(c.items)?c.items:[c.items],b.index=c.index||0;if(b.isOpen)return void b.updateItemHTML();b.types=[],f="",c.mainEl&&c.mainEl.length?b.ev=c.mainEl.eq(0):b.ev=d,c.key?(b.popupsCache[c.key]||(b.popupsCache[c.key]={}),b.currTemplate=b.popupsCache[c.key]):b.currTemplate={},b.st=a.extend(!0,{},a.magnificPopup.defaults,c),b.fixedContentPos="auto"===b.st.fixedContentPos?!b.probablyMobile:b.st.fixedContentPos,b.st.modal&&(b.st.closeOnContentClick=!1,b.st.closeOnBgClick=!1,b.st.showCloseBtn=!1,b.st.enableEscapeKey=!1),b.bgOverlay||(b.bgOverlay=x("bg").on("click"+p,function(){b.close()}),b.wrap=x("wrap").attr("tabindex",-1).on("click"+p,function(a){b._checkIfClose(a.target)&&b.close()}),b.container=x("container",b.wrap)),b.contentContainer=x("content"),b.st.preloader&&(b.preloader=x("preloader",b.container,b.st.tLoading));var i=a.magnificPopup.modules;for(e=0;e<i.length;e++){var j=i[e];j=j.charAt(0).toUpperCase()+j.slice(1),b["init"+j].call(b)}y("BeforeOpen"),b.st.showCloseBtn&&(b.st.closeBtnInside?(w(l,function(a,b,c,d){c.close_replaceWith=z(d.type)}),f+=" mfp-close-btn-in"):b.wrap.append(z())),b.st.alignTop&&(f+=" mfp-align-top"),b.fixedContentPos?b.wrap.css({overflow:b.st.overflowY,overflowX:"hidden",overflowY:b.st.overflowY}):b.wrap.css({top:v.scrollTop(),position:"absolute"}),(b.st.fixedBgPos===!1||"auto"===b.st.fixedBgPos&&!b.fixedContentPos)&&b.bgOverlay.css({height:d.height(),position:"absolute"}),b.st.enableEscapeKey&&d.on("keyup"+p,function(a){27===a.keyCode&&b.close()}),v.on("resize"+p,function(){b.updateSize()}),b.st.closeOnContentClick||(f+=" mfp-auto-cursor"),f&&b.wrap.addClass(f);var k=b.wH=v.height(),n={};if(b.fixedContentPos&&b._hasScrollBar(k)){var o=b._getScrollbarSize();o&&(n.marginRight=o)}b.fixedContentPos&&(b.isIE7?a("body, html").css("overflow","hidden"):n.overflow="hidden");var r=b.st.mainClass;return b.isIE7&&(r+=" mfp-ie7"),r&&b._addClassToMFP(r),b.updateItemHTML(),y("BuildControls"),a("html").css(n),b.bgOverlay.add(b.wrap).prependTo(b.st.prependTo||a(document.body)),b._lastFocusedEl=document.activeElement,setTimeout(function(){b.content?(b._addClassToMFP(q),b._setFocus()):b.bgOverlay.addClass(q),d.on("focusin"+p,b._onFocusIn)},16),b.isOpen=!0,b.updateSize(k),y(m),c},close:function(){b.isOpen&&(y(i),b.isOpen=!1,b.st.removalDelay&&!b.isLowIE&&b.supportsTransition?(b._addClassToMFP(r),setTimeout(function(){b._close()},b.st.removalDelay)):b._close())},_close:function(){y(h);var c=r+" "+q+" ";if(b.bgOverlay.detach(),b.wrap.detach(),b.container.empty(),b.st.mainClass&&(c+=b.st.mainClass+" "),b._removeClassFromMFP(c),b.fixedContentPos){var e={marginRight:""};b.isIE7?a("body, html").css("overflow",""):e.overflow="",a("html").css(e)}d.off("keyup"+p+" focusin"+p),b.ev.off(p),b.wrap.attr("class","mfp-wrap").removeAttr("style"),b.bgOverlay.attr("class","mfp-bg"),b.container.attr("class","mfp-container"),!b.st.showCloseBtn||b.st.closeBtnInside&&b.currTemplate[b.currItem.type]!==!0||b.currTemplate.closeBtn&&b.currTemplate.closeBtn.detach(),b.st.autoFocusLast&&b._lastFocusedEl&&a(b._lastFocusedEl).focus(),b.currItem=null,b.content=null,b.currTemplate=null,b.prevHeight=0,y(j)},updateSize:function(a){if(b.isIOS){var c=document.documentElement.clientWidth/window.innerWidth,d=window.innerHeight*c;b.wrap.css("height",d),b.wH=d}else b.wH=a||v.height();b.fixedContentPos||b.wrap.css("height",b.wH),y("Resize")},updateItemHTML:function(){var c=b.items[b.index];b.contentContainer.detach(),b.content&&b.content.detach(),c.parsed||(c=b.parseEl(b.index));var d=c.type;if(y("BeforeChange",[b.currItem?b.currItem.type:"",d]),b.currItem=c,!b.currTemplate[d]){var f=b.st[d]?b.st[d].markup:!1;y("FirstMarkupParse",f),f?b.currTemplate[d]=a(f):b.currTemplate[d]=!0}e&&e!==c.type&&b.container.removeClass("mfp-"+e+"-holder");var g=b["get"+d.charAt(0).toUpperCase()+d.slice(1)](c,b.currTemplate[d]);b.appendContent(g,d),c.preloaded=!0,y(n,c),e=c.type,b.container.prepend(b.contentContainer),y("AfterChange")},appendContent:function(a,c){b.content=a,a?b.st.showCloseBtn&&b.st.closeBtnInside&&b.currTemplate[c]===!0?b.content.find(".mfp-close").length||b.content.append(z()):b.content=a:b.content="",y(k),b.container.addClass("mfp-"+c+"-holder"),b.contentContainer.append(b.content)},parseEl:function(c){var d,e=b.items[c];if(e.tagName?e={el:a(e)}:(d=e.type,e={data:e,src:e.src}),e.el){for(var f=b.types,g=0;g<f.length;g++)if(e.el.hasClass("mfp-"+f[g])){d=f[g];break}e.src=e.el.attr("data-mfp-src"),e.src||(e.src=e.el.attr("href"))}return e.type=d||b.st.type||"inline",e.index=c,e.parsed=!0,b.items[c]=e,y("ElementParse",e),b.items[c]},addGroup:function(a,c){var d=function(d){d.mfpEl=this,b._openClick(d,a,c)};c||(c={});var e="click.magnificPopup";c.mainEl=a,c.items?(c.isObj=!0,a.off(e).on(e,d)):(c.isObj=!1,c.delegate?a.off(e).on(e,c.delegate,d):(c.items=a,a.off(e).on(e,d)))},_openClick:function(c,d,e){var f=void 0!==e.midClick?e.midClick:a.magnificPopup.defaults.midClick;if(f||!(2===c.which||c.ctrlKey||c.metaKey||c.altKey||c.shiftKey)){var g=void 0!==e.disableOn?e.disableOn:a.magnificPopup.defaults.disableOn;if(g)if(a.isFunction(g)){if(!g.call(b))return!0}else if(v.width()<g)return!0;c.type&&(c.preventDefault(),b.isOpen&&c.stopPropagation()),e.el=a(c.mfpEl),e.delegate&&(e.items=d.find(e.delegate)),b.open(e)}},updateStatus:function(a,d){if(b.preloader){c!==a&&b.container.removeClass("mfp-s-"+c),d||"loading"!==a||(d=b.st.tLoading);var e={status:a,text:d};y("UpdateStatus",e),a=e.status,d=e.text,b.preloader.html(d),b.preloader.find("a").on("click",function(a){a.stopImmediatePropagation()}),b.container.addClass("mfp-s-"+a),c=a}},_checkIfClose:function(c){if(!a(c).hasClass(s)){var d=b.st.closeOnContentClick,e=b.st.closeOnBgClick;if(d&&e)return!0;if(!b.content||a(c).hasClass("mfp-close")||b.preloader&&c===b.preloader[0])return!0;if(c===b.content[0]||a.contains(b.content[0],c)){if(d)return!0}else if(e&&a.contains(document,c))return!0;return!1}},_addClassToMFP:function(a){b.bgOverlay.addClass(a),b.wrap.addClass(a)},_removeClassFromMFP:function(a){this.bgOverlay.removeClass(a),b.wrap.removeClass(a)},_hasScrollBar:function(a){return(b.isIE7?d.height():document.body.scrollHeight)>(a||v.height())},_setFocus:function(){(b.st.focus?b.content.find(b.st.focus).eq(0):b.wrap).focus()},_onFocusIn:function(c){return c.target===b.wrap[0]||a.contains(b.wrap[0],c.target)?void 0:(b._setFocus(),!1)},_parseMarkup:function(b,c,d){var e;d.data&&(c=a.extend(d.data,c)),y(l,[b,c,d]),a.each(c,function(c,d){if(void 0===d||d===!1)return!0;if(e=c.split("_"),e.length>1){var f=b.find(p+"-"+e[0]);if(f.length>0){var g=e[1];"replaceWith"===g?f[0]!==d[0]&&f.replaceWith(d):"img"===g?f.is("img")?f.attr("src",d):f.replaceWith(a("<img>").attr("src",d).attr("class",f.attr("class"))):f.attr(e[1],d)}}else b.find(p+"-"+c).html(d)})},_getScrollbarSize:function(){if(void 0===b.scrollbarSize){var a=document.createElement("div");a.style.cssText="width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;",document.body.appendChild(a),b.scrollbarSize=a.offsetWidth-a.clientWidth,document.body.removeChild(a)}return b.scrollbarSize}},a.magnificPopup={instance:null,proto:t.prototype,modules:[],open:function(b,c){return A(),b=b?a.extend(!0,{},b):{},b.isObj=!0,b.index=c||0,this.instance.open(b)},close:function(){return a.magnificPopup.instance&&a.magnificPopup.instance.close()},registerModule:function(b,c){c.options&&(a.magnificPopup.defaults[b]=c.options),a.extend(this.proto,c.proto),this.modules.push(b)},defaults:{disableOn:0,key:null,midClick:!1,mainClass:"",preloader:!0,focus:"",closeOnContentClick:!1,closeOnBgClick:!0,closeBtnInside:!0,showCloseBtn:!0,enableEscapeKey:!0,modal:!1,alignTop:!1,removalDelay:0,prependTo:null,fixedContentPos:"auto",fixedBgPos:"auto",overflowY:"auto",closeMarkup:'<button title="%title%" type="button" class="mfp-close">&#215;</button>',tClose:"Close (Esc)",tLoading:"Loading...",autoFocusLast:!0}},a.fn.magnificPopup=function(c){A();var d=a(this);if("string"==typeof c)if("open"===c){var e,f=u?d.data("magnificPopup"):d[0].magnificPopup,g=parseInt(arguments[1],10)||0;f.items?e=f.items[g]:(e=d,f.delegate&&(e=e.find(f.delegate)),e=e.eq(g)),b._openClick({mfpEl:e},d,f)}else b.isOpen&&b[c].apply(b,Array.prototype.slice.call(arguments,1));else c=a.extend(!0,{},c),u?d.data("magnificPopup",c):d[0].magnificPopup=c,b.addGroup(d,c);return d};var C,D,E,F="inline",G=function(){E&&(D.after(E.addClass(C)).detach(),E=null)};a.magnificPopup.registerModule(F,{options:{hiddenClass:"hide",markup:"",tNotFound:"Content not found"},proto:{initInline:function(){b.types.push(F),w(h+"."+F,function(){G()})},getInline:function(c,d){if(G(),c.src){var e=b.st.inline,f=a(c.src);if(f.length){var g=f[0].parentNode;g&&g.tagName&&(D||(C=e.hiddenClass,D=x(C),C="mfp-"+C),E=f.after(D).detach().removeClass(C)),b.updateStatus("ready")}else b.updateStatus("error",e.tNotFound),f=a("<div>");return c.inlineElement=f,f}return b.updateStatus("ready"),b._parseMarkup(d,{},c),d}}});var H,I="ajax",J=function(){H&&a(document.body).removeClass(H)},K=function(){J(),b.req&&b.req.abort()};a.magnificPopup.registerModule(I,{options:{settings:null,cursor:"mfp-ajax-cur",tError:'<a href="%url%">The content</a> could not be loaded.'},proto:{initAjax:function(){b.types.push(I),H=b.st.ajax.cursor,w(h+"."+I,K),w("BeforeChange."+I,K)},getAjax:function(c){H&&a(document.body).addClass(H),b.updateStatus("loading");var d=a.extend({url:c.src,success:function(d,e,f){var g={data:d,xhr:f};y("ParseAjax",g),b.appendContent(a(g.data),I),c.finished=!0,J(),b._setFocus(),setTimeout(function(){b.wrap.addClass(q)},16),b.updateStatus("ready"),y("AjaxContentAdded")},error:function(){J(),c.finished=c.loadError=!0,b.updateStatus("error",b.st.ajax.tError.replace("%url%",c.src))}},b.st.ajax.settings);return b.req=a.ajax(d),""}}});var L,M=function(c){if(c.data&&void 0!==c.data.title)return c.data.title;var d=b.st.image.titleSrc;if(d){if(a.isFunction(d))return d.call(b,c);if(c.el)return c.el.attr(d)||""}return""};a.magnificPopup.registerModule("image",{options:{markup:'<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',cursor:"mfp-zoom-out-cur",titleSrc:"title",verticalFit:!0,tError:'<a href="%url%">The image</a> could not be loaded.'},proto:{initImage:function(){var c=b.st.image,d=".image";b.types.push("image"),w(m+d,function(){"image"===b.currItem.type&&c.cursor&&a(document.body).addClass(c.cursor)}),w(h+d,function(){c.cursor&&a(document.body).removeClass(c.cursor),v.off("resize"+p)}),w("Resize"+d,b.resizeImage),b.isLowIE&&w("AfterChange",b.resizeImage)},resizeImage:function(){var a=b.currItem;if(a&&a.img&&b.st.image.verticalFit){var c=0;b.isLowIE&&(c=parseInt(a.img.css("padding-top"),10)+parseInt(a.img.css("padding-bottom"),10)),a.img.css("max-height",b.wH-c)}},_onImageHasSize:function(a){a.img&&(a.hasSize=!0,L&&clearInterval(L),a.isCheckingImgSize=!1,y("ImageHasSize",a),a.imgHidden&&(b.content&&b.content.removeClass("mfp-loading"),a.imgHidden=!1))},findImageSize:function(a){var c=0,d=a.img[0],e=function(f){L&&clearInterval(L),L=setInterval(function(){return d.naturalWidth>0?void b._onImageHasSize(a):(c>200&&clearInterval(L),c++,void(3===c?e(10):40===c?e(50):100===c&&e(500)))},f)};e(1)},getImage:function(c,d){var e=0,f=function(){c&&(c.img[0].complete?(c.img.off(".mfploader"),c===b.currItem&&(b._onImageHasSize(c),b.updateStatus("ready")),c.hasSize=!0,c.loaded=!0,y("ImageLoadComplete")):(e++,200>e?setTimeout(f,100):g()))},g=function(){c&&(c.img.off(".mfploader"),c===b.currItem&&(b._onImageHasSize(c),b.updateStatus("error",h.tError.replace("%url%",c.src))),c.hasSize=!0,c.loaded=!0,c.loadError=!0)},h=b.st.image,i=d.find(".mfp-img");if(i.length){var j=document.createElement("img");j.className="mfp-img",c.el&&c.el.find("img").length&&(j.alt=c.el.find("img").attr("alt")),c.img=a(j).on("load.mfploader",f).on("error.mfploader",g),j.src=c.src,i.is("img")&&(c.img=c.img.clone()),j=c.img[0],j.naturalWidth>0?c.hasSize=!0:j.width||(c.hasSize=!1)}return b._parseMarkup(d,{title:M(c),img_replaceWith:c.img},c),b.resizeImage(),c.hasSize?(L&&clearInterval(L),c.loadError?(d.addClass("mfp-loading"),b.updateStatus("error",h.tError.replace("%url%",c.src))):(d.removeClass("mfp-loading"),b.updateStatus("ready")),d):(b.updateStatus("loading"),c.loading=!0,c.hasSize||(c.imgHidden=!0,d.addClass("mfp-loading"),b.findImageSize(c)),d)}}});var N,O=function(){return void 0===N&&(N=void 0!==document.createElement("p").style.MozTransform),N};a.magnificPopup.registerModule("zoom",{options:{enabled:!1,easing:"ease-in-out",duration:300,opener:function(a){return a.is("img")?a:a.find("img")}},proto:{initZoom:function(){var a,c=b.st.zoom,d=".zoom";if(c.enabled&&b.supportsTransition){var e,f,g=c.duration,j=function(a){var b=a.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),d="all "+c.duration/1e3+"s "+c.easing,e={position:"fixed",zIndex:9999,left:0,top:0,"-webkit-backface-visibility":"hidden"},f="transition";return e["-webkit-"+f]=e["-moz-"+f]=e["-o-"+f]=e[f]=d,b.css(e),b},k=function(){b.content.css("visibility","visible")};w("BuildControls"+d,function(){if(b._allowZoom()){if(clearTimeout(e),b.content.css("visibility","hidden"),a=b._getItemToZoom(),!a)return void k();f=j(a),f.css(b._getOffset()),b.wrap.append(f),e=setTimeout(function(){f.css(b._getOffset(!0)),e=setTimeout(function(){k(),setTimeout(function(){f.remove(),a=f=null,y("ZoomAnimationEnded")},16)},g)},16)}}),w(i+d,function(){if(b._allowZoom()){if(clearTimeout(e),b.st.removalDelay=g,!a){if(a=b._getItemToZoom(),!a)return;f=j(a)}f.css(b._getOffset(!0)),b.wrap.append(f),b.content.css("visibility","hidden"),setTimeout(function(){f.css(b._getOffset())},16)}}),w(h+d,function(){b._allowZoom()&&(k(),f&&f.remove(),a=null)})}},_allowZoom:function(){return"image"===b.currItem.type},_getItemToZoom:function(){return b.currItem.hasSize?b.currItem.img:!1},_getOffset:function(c){var d;d=c?b.currItem.img:b.st.zoom.opener(b.currItem.el||b.currItem);var e=d.offset(),f=parseInt(d.css("padding-top"),10),g=parseInt(d.css("padding-bottom"),10);e.top-=a(window).scrollTop()-f;var h={width:d.width(),height:(u?d.innerHeight():d[0].offsetHeight)-g-f};return O()?h["-moz-transform"]=h.transform="translate("+e.left+"px,"+e.top+"px)":(h.left=e.left,h.top=e.top),h}}});var P="iframe",Q="//about:blank",R=function(a){if(b.currTemplate[P]){var c=b.currTemplate[P].find("iframe");c.length&&(a||(c[0].src=Q),b.isIE8&&c.css("display",a?"block":"none"))}};a.magnificPopup.registerModule(P,{options:{markup:'<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',srcAction:"iframe_src",patterns:{youtube:{index:"youtube.com",id:"v=",src:"//www.youtube.com/embed/%id%?autoplay=1"},vimeo:{index:"vimeo.com/",id:"/",src:"//player.vimeo.com/video/%id%?autoplay=1"},gmaps:{index:"//maps.google.",src:"%id%&output=embed"}}},proto:{initIframe:function(){b.types.push(P),w("BeforeChange",function(a,b,c){b!==c&&(b===P?R():c===P&&R(!0))}),w(h+"."+P,function(){R()})},getIframe:function(c,d){var e=c.src,f=b.st.iframe;a.each(f.patterns,function(){return e.indexOf(this.index)>-1?(this.id&&(e="string"==typeof this.id?e.substr(e.lastIndexOf(this.id)+this.id.length,e.length):this.id.call(this,e)),e=this.src.replace("%id%",e),!1):void 0});var g={};return f.srcAction&&(g[f.srcAction]=e),b._parseMarkup(d,g,c),b.updateStatus("ready"),d}}});var S=function(a){var c=b.items.length;return a>c-1?a-c:0>a?c+a:a},T=function(a,b,c){return a.replace(/%curr%/gi,b+1).replace(/%total%/gi,c)};a.magnificPopup.registerModule("gallery",{options:{enabled:!1,arrowMarkup:'<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',preload:[0,2],navigateByImgClick:!0,arrows:!0,tPrev:"Previous (Left arrow key)",tNext:"Next (Right arrow key)",tCounter:"%curr% of %total%"},proto:{initGallery:function(){var c=b.st.gallery,e=".mfp-gallery";return b.direction=!0,c&&c.enabled?(f+=" mfp-gallery",w(m+e,function(){c.navigateByImgClick&&b.wrap.on("click"+e,".mfp-img",function(){return b.items.length>1?(b.next(),!1):void 0}),d.on("keydown"+e,function(a){37===a.keyCode?b.prev():39===a.keyCode&&b.next()})}),w("UpdateStatus"+e,function(a,c){c.text&&(c.text=T(c.text,b.currItem.index,b.items.length))}),w(l+e,function(a,d,e,f){var g=b.items.length;e.counter=g>1?T(c.tCounter,f.index,g):""}),w("BuildControls"+e,function(){if(b.items.length>1&&c.arrows&&!b.arrowLeft){var d=c.arrowMarkup,e=b.arrowLeft=a(d.replace(/%title%/gi,c.tPrev).replace(/%dir%/gi,"left")).addClass(s),f=b.arrowRight=a(d.replace(/%title%/gi,c.tNext).replace(/%dir%/gi,"right")).addClass(s);e.click(function(){b.prev()}),f.click(function(){b.next()}),b.container.append(e.add(f))}}),w(n+e,function(){b._preloadTimeout&&clearTimeout(b._preloadTimeout),b._preloadTimeout=setTimeout(function(){b.preloadNearbyImages(),b._preloadTimeout=null},16)}),void w(h+e,function(){d.off(e),b.wrap.off("click"+e),b.arrowRight=b.arrowLeft=null})):!1},next:function(){b.direction=!0,b.index=S(b.index+1),b.updateItemHTML()},prev:function(){b.direction=!1,b.index=S(b.index-1),b.updateItemHTML()},goTo:function(a){b.direction=a>=b.index,b.index=a,b.updateItemHTML()},preloadNearbyImages:function(){var a,c=b.st.gallery.preload,d=Math.min(c[0],b.items.length),e=Math.min(c[1],b.items.length);for(a=1;a<=(b.direction?e:d);a++)b._preloadItem(b.index+a);for(a=1;a<=(b.direction?d:e);a++)b._preloadItem(b.index-a)},_preloadItem:function(c){if(c=S(c),!b.items[c].preloaded){var d=b.items[c];d.parsed||(d=b.parseEl(c)),y("LazyLoad",d),"image"===d.type&&(d.img=a('<img class="mfp-img" />').on("load.mfploader",function(){d.hasSize=!0}).on("error.mfploader",function(){d.hasSize=!0,d.loadError=!0,y("LazyLoadError",d)}).attr("src",d.src)),d.preloaded=!0}}}});var U="retina";a.magnificPopup.registerModule(U,{options:{replaceSrc:function(a){return a.src.replace(/\.\w+$/,function(a){return"@2x"+a})},ratio:1},proto:{initRetina:function(){if(window.devicePixelRatio>1){var a=b.st.retina,c=a.ratio;c=isNaN(c)?c():c,c>1&&(w("ImageHasSize."+U,function(a,b){b.img.css({"max-width":b.img[0].naturalWidth/c,width:"100%"})}),w("ElementParse."+U,function(b,d){d.src=a.replaceSrc(d,c)}))}}}}),A()});
(function($){
$.exitIntent=function(el, callback, options){
var base=this;
base.delayTimer=null;
base.$el=$(el);
base.el=el;
base.disabled=false;
base.$el.data("exitIntent", base);
base.init=function(){
base.options=$.extend({},$.exitIntent.defaultOptions, options);
base.$el.mouseleave(function(e){
if(e.clientY > 0||Math.abs(e.clientY) < base.options.minexitspeed||(base.disabled&&!base.options.repeat)) return;
base.delayTimer=setTimeout(base.runCallback, base.options.delay);
}).mouseenter(function(event){
if(base.delayTimer){
clearTimeout(base.delayTimer);
base.delayTimer=null;
}});
if(base.options.keyboard){
base.$el.keydown(function(e){
if(base.disabled&&!base.options.repeat) return;
else if(e.keyCode!==8&&(!e.metaKey||e.keyCode!==76)) return;
base.runCallback();
});
}};
base.runCallback=function(){
if(typeof callback=='function'){
callback.call(this);
}
base.disabled=true;
};
base.init();
};
$.exitIntent.defaultOptions={
minexitspeed: 0,
delay: 0,
repeat: false,
keyboard: true
};
$.fn.exitIntent=function(callback, options){
return this.each(function(){
(new $.exitIntent(this, callback, options));
});
};})(jQuery);
(function(){function n(n){function t(t,r,e,u,i,o){for(;i>=0&&o>i;i+=n){var a=u?u[i]:i;e=r(e,t[a],a,t)}return e}return function(r,e,u,i){e=b(e,i,4);var o=!k(r)&&m.keys(r),a=(o||r).length,c=n>0?0:a-1;return arguments.length<3&&(u=r[o?o[c]:c],c+=n),t(r,e,u,o,c,a)}}function t(n){return function(t,r,e){r=x(r,e);for(var u=O(t),i=n>0?0:u-1;i>=0&&u>i;i+=n)if(r(t[i],i,t))return i;return-1}}function r(n,t,r){return function(e,u,i){var o=0,a=O(e);if("number"==typeof i)n>0?o=i>=0?i:Math.max(i+a,o):a=i>=0?Math.min(i+1,a):i+a+1;else if(r&&i&&a)return i=r(e,u),e[i]===u?i:-1;if(u!==u)return i=t(l.call(e,o,a),m.isNaN),i>=0?i+o:-1;for(i=n>0?o:a-1;i>=0&&a>i;i+=n)if(e[i]===u)return i;return-1}}function e(n,t){var r=I.length,e=n.constructor,u=m.isFunction(e)&&e.prototype||a,i="constructor";for(m.has(n,i)&&!m.contains(t,i)&&t.push(i);r--;)i=I[r],i in n&&n[i]!==u[i]&&!m.contains(t,i)&&t.push(i)}var u=this,i=u._,o=Array.prototype,a=Object.prototype,c=Function.prototype,f=o.push,l=o.slice,s=a.toString,p=a.hasOwnProperty,h=Array.isArray,v=Object.keys,g=c.bind,y=Object.create,d=function(){},m=function(n){return n instanceof m?n:this instanceof m?void(this._wrapped=n):new m(n)};"undefined"!=typeof exports?("undefined"!=typeof module&&module.exports&&(exports=module.exports=m),exports._=m):u._=m,m.VERSION="1.8.3";var b=function(n,t,r){if(t===void 0)return n;switch(null==r?3:r){case 1:return function(r){return n.call(t,r)};case 2:return function(r,e){return n.call(t,r,e)};case 3:return function(r,e,u){return n.call(t,r,e,u)};case 4:return function(r,e,u,i){return n.call(t,r,e,u,i)}}return function(){return n.apply(t,arguments)}},x=function(n,t,r){return null==n?m.identity:m.isFunction(n)?b(n,t,r):m.isObject(n)?m.matcher(n):m.property(n)};m.iteratee=function(n,t){return x(n,t,1/0)};var _=function(n,t){return function(r){var e=arguments.length;if(2>e||null==r)return r;for(var u=1;e>u;u++)for(var i=arguments[u],o=n(i),a=o.length,c=0;a>c;c++){var f=o[c];t&&r[f]!==void 0||(r[f]=i[f])}return r}},j=function(n){if(!m.isObject(n))return{};if(y)return y(n);d.prototype=n;var t=new d;return d.prototype=null,t},w=function(n){return function(t){return null==t?void 0:t[n]}},A=Math.pow(2,53)-1,O=w("length"),k=function(n){var t=O(n);return"number"==typeof t&&t>=0&&A>=t};m.each=m.forEach=function(n,t,r){t=b(t,r);var e,u;if(k(n))for(e=0,u=n.length;u>e;e++)t(n[e],e,n);else{var i=m.keys(n);for(e=0,u=i.length;u>e;e++)t(n[i[e]],i[e],n)}return n},m.map=m.collect=function(n,t,r){t=x(t,r);for(var e=!k(n)&&m.keys(n),u=(e||n).length,i=Array(u),o=0;u>o;o++){var a=e?e[o]:o;i[o]=t(n[a],a,n)}return i},m.reduce=m.foldl=m.inject=n(1),m.reduceRight=m.foldr=n(-1),m.find=m.detect=function(n,t,r){var e;return e=k(n)?m.findIndex(n,t,r):m.findKey(n,t,r),e!==void 0&&e!==-1?n[e]:void 0},m.filter=m.select=function(n,t,r){var e=[];return t=x(t,r),m.each(n,function(n,r,u){t(n,r,u)&&e.push(n)}),e},m.reject=function(n,t,r){return m.filter(n,m.negate(x(t)),r)},m.every=m.all=function(n,t,r){t=x(t,r);for(var e=!k(n)&&m.keys(n),u=(e||n).length,i=0;u>i;i++){var o=e?e[i]:i;if(!t(n[o],o,n))return!1}return!0},m.some=m.any=function(n,t,r){t=x(t,r);for(var e=!k(n)&&m.keys(n),u=(e||n).length,i=0;u>i;i++){var o=e?e[i]:i;if(t(n[o],o,n))return!0}return!1},m.contains=m.includes=m.include=function(n,t,r,e){return k(n)||(n=m.values(n)),("number"!=typeof r||e)&&(r=0),m.indexOf(n,t,r)>=0},m.invoke=function(n,t){var r=l.call(arguments,2),e=m.isFunction(t);return m.map(n,function(n){var u=e?t:n[t];return null==u?u:u.apply(n,r)})},m.pluck=function(n,t){return m.map(n,m.property(t))},m.where=function(n,t){return m.filter(n,m.matcher(t))},m.findWhere=function(n,t){return m.find(n,m.matcher(t))},m.max=function(n,t,r){var e,u,i=-1/0,o=-1/0;if(null==t&&null!=n){n=k(n)?n:m.values(n);for(var a=0,c=n.length;c>a;a++)e=n[a],e>i&&(i=e)}else t=x(t,r),m.each(n,function(n,r,e){u=t(n,r,e),(u>o||u===-1/0&&i===-1/0)&&(i=n,o=u)});return i},m.min=function(n,t,r){var e,u,i=1/0,o=1/0;if(null==t&&null!=n){n=k(n)?n:m.values(n);for(var a=0,c=n.length;c>a;a++)e=n[a],i>e&&(i=e)}else t=x(t,r),m.each(n,function(n,r,e){u=t(n,r,e),(o>u||1/0===u&&1/0===i)&&(i=n,o=u)});return i},m.shuffle=function(n){for(var t,r=k(n)?n:m.values(n),e=r.length,u=Array(e),i=0;e>i;i++)t=m.random(0,i),t!==i&&(u[i]=u[t]),u[t]=r[i];return u},m.sample=function(n,t,r){return null==t||r?(k(n)||(n=m.values(n)),n[m.random(n.length-1)]):m.shuffle(n).slice(0,Math.max(0,t))},m.sortBy=function(n,t,r){return t=x(t,r),m.pluck(m.map(n,function(n,r,e){return{value:n,index:r,criteria:t(n,r,e)}}).sort(function(n,t){var r=n.criteria,e=t.criteria;if(r!==e){if(r>e||r===void 0)return 1;if(e>r||e===void 0)return-1}return n.index-t.index}),"value")};var F=function(n){return function(t,r,e){var u={};return r=x(r,e),m.each(t,function(e,i){var o=r(e,i,t);n(u,e,o)}),u}};m.groupBy=F(function(n,t,r){m.has(n,r)?n[r].push(t):n[r]=[t]}),m.indexBy=F(function(n,t,r){n[r]=t}),m.countBy=F(function(n,t,r){m.has(n,r)?n[r]++:n[r]=1}),m.toArray=function(n){return n?m.isArray(n)?l.call(n):k(n)?m.map(n,m.identity):m.values(n):[]},m.size=function(n){return null==n?0:k(n)?n.length:m.keys(n).length},m.partition=function(n,t,r){t=x(t,r);var e=[],u=[];return m.each(n,function(n,r,i){(t(n,r,i)?e:u).push(n)}),[e,u]},m.first=m.head=m.take=function(n,t,r){return null==n?void 0:null==t||r?n[0]:m.initial(n,n.length-t)},m.initial=function(n,t,r){return l.call(n,0,Math.max(0,n.length-(null==t||r?1:t)))},m.last=function(n,t,r){return null==n?void 0:null==t||r?n[n.length-1]:m.rest(n,Math.max(0,n.length-t))},m.rest=m.tail=m.drop=function(n,t,r){return l.call(n,null==t||r?1:t)},m.compact=function(n){return m.filter(n,m.identity)};var S=function(n,t,r,e){for(var u=[],i=0,o=e||0,a=O(n);a>o;o++){var c=n[o];if(k(c)&&(m.isArray(c)||m.isArguments(c))){t||(c=S(c,t,r));var f=0,l=c.length;for(u.length+=l;l>f;)u[i++]=c[f++]}else r||(u[i++]=c)}return u};m.flatten=function(n,t){return S(n,t,!1)},m.without=function(n){return m.difference(n,l.call(arguments,1))},m.uniq=m.unique=function(n,t,r,e){m.isBoolean(t)||(e=r,r=t,t=!1),null!=r&&(r=x(r,e));for(var u=[],i=[],o=0,a=O(n);a>o;o++){var c=n[o],f=r?r(c,o,n):c;t?(o&&i===f||u.push(c),i=f):r?m.contains(i,f)||(i.push(f),u.push(c)):m.contains(u,c)||u.push(c)}return u},m.union=function(){return m.uniq(S(arguments,!0,!0))},m.intersection=function(n){for(var t=[],r=arguments.length,e=0,u=O(n);u>e;e++){var i=n[e];if(!m.contains(t,i)){for(var o=1;r>o&&m.contains(arguments[o],i);o++);o===r&&t.push(i)}}return t},m.difference=function(n){var t=S(arguments,!0,!0,1);return m.filter(n,function(n){return!m.contains(t,n)})},m.zip=function(){return m.unzip(arguments)},m.unzip=function(n){for(var t=n&&m.max(n,O).length||0,r=Array(t),e=0;t>e;e++)r[e]=m.pluck(n,e);return r},m.object=function(n,t){for(var r={},e=0,u=O(n);u>e;e++)t?r[n[e]]=t[e]:r[n[e][0]]=n[e][1];return r},m.findIndex=t(1),m.findLastIndex=t(-1),m.sortedIndex=function(n,t,r,e){r=x(r,e,1);for(var u=r(t),i=0,o=O(n);o>i;){var a=Math.floor((i+o)/2);r(n[a])<u?i=a+1:o=a}return i},m.indexOf=r(1,m.findIndex,m.sortedIndex),m.lastIndexOf=r(-1,m.findLastIndex),m.range=function(n,t,r){null==t&&(t=n||0,n=0),r=r||1;for(var e=Math.max(Math.ceil((t-n)/r),0),u=Array(e),i=0;e>i;i++,n+=r)u[i]=n;return u};var E=function(n,t,r,e,u){if(!(e instanceof t))return n.apply(r,u);var i=j(n.prototype),o=n.apply(i,u);return m.isObject(o)?o:i};m.bind=function(n,t){if(g&&n.bind===g)return g.apply(n,l.call(arguments,1));if(!m.isFunction(n))throw new TypeError("Bind must be called on a function");var r=l.call(arguments,2),e=function(){return E(n,e,t,this,r.concat(l.call(arguments)))};return e},m.partial=function(n){var t=l.call(arguments,1),r=function(){for(var e=0,u=t.length,i=Array(u),o=0;u>o;o++)i[o]=t[o]===m?arguments[e++]:t[o];for(;e<arguments.length;)i.push(arguments[e++]);return E(n,r,this,this,i)};return r},m.bindAll=function(n){var t,r,e=arguments.length;if(1>=e)throw new Error("bindAll must be passed function names");for(t=1;e>t;t++)r=arguments[t],n[r]=m.bind(n[r],n);return n},m.memoize=function(n,t){var r=function(e){var u=r.cache,i=""+(t?t.apply(this,arguments):e);return m.has(u,i)||(u[i]=n.apply(this,arguments)),u[i]};return r.cache={},r},m.delay=function(n,t){var r=l.call(arguments,2);return setTimeout(function(){return n.apply(null,r)},t)},m.defer=m.partial(m.delay,m,1),m.throttle=function(n,t,r){var e,u,i,o=null,a=0;r||(r={});var c=function(){a=r.leading===!1?0:m.now(),o=null,i=n.apply(e,u),o||(e=u=null)};return function(){var f=m.now();a||r.leading!==!1||(a=f);var l=t-(f-a);return e=this,u=arguments,0>=l||l>t?(o&&(clearTimeout(o),o=null),a=f,i=n.apply(e,u),o||(e=u=null)):o||r.trailing===!1||(o=setTimeout(c,l)),i}},m.debounce=function(n,t,r){var e,u,i,o,a,c=function(){var f=m.now()-o;t>f&&f>=0?e=setTimeout(c,t-f):(e=null,r||(a=n.apply(i,u),e||(i=u=null)))};return function(){i=this,u=arguments,o=m.now();var f=r&&!e;return e||(e=setTimeout(c,t)),f&&(a=n.apply(i,u),i=u=null),a}},m.wrap=function(n,t){return m.partial(t,n)},m.negate=function(n){return function(){return!n.apply(this,arguments)}},m.compose=function(){var n=arguments,t=n.length-1;return function(){for(var r=t,e=n[t].apply(this,arguments);r--;)e=n[r].call(this,e);return e}},m.after=function(n,t){return function(){return--n<1?t.apply(this,arguments):void 0}},m.before=function(n,t){var r;return function(){return--n>0&&(r=t.apply(this,arguments)),1>=n&&(t=null),r}},m.once=m.partial(m.before,2);var M=!{toString:null}.propertyIsEnumerable("toString"),I=["valueOf","isPrototypeOf","toString","propertyIsEnumerable","hasOwnProperty","toLocaleString"];m.keys=function(n){if(!m.isObject(n))return[];if(v)return v(n);var t=[];for(var r in n)m.has(n,r)&&t.push(r);return M&&e(n,t),t},m.allKeys=function(n){if(!m.isObject(n))return[];var t=[];for(var r in n)t.push(r);return M&&e(n,t),t},m.values=function(n){for(var t=m.keys(n),r=t.length,e=Array(r),u=0;r>u;u++)e[u]=n[t[u]];return e},m.mapObject=function(n,t,r){t=x(t,r);for(var e,u=m.keys(n),i=u.length,o={},a=0;i>a;a++)e=u[a],o[e]=t(n[e],e,n);return o},m.pairs=function(n){for(var t=m.keys(n),r=t.length,e=Array(r),u=0;r>u;u++)e[u]=[t[u],n[t[u]]];return e},m.invert=function(n){for(var t={},r=m.keys(n),e=0,u=r.length;u>e;e++)t[n[r[e]]]=r[e];return t},m.functions=m.methods=function(n){var t=[];for(var r in n)m.isFunction(n[r])&&t.push(r);return t.sort()},m.extend=_(m.allKeys),m.extendOwn=m.assign=_(m.keys),m.findKey=function(n,t,r){t=x(t,r);for(var e,u=m.keys(n),i=0,o=u.length;o>i;i++)if(e=u[i],t(n[e],e,n))return e},m.pick=function(n,t,r){var e,u,i={},o=n;if(null==o)return i;m.isFunction(t)?(u=m.allKeys(o),e=b(t,r)):(u=S(arguments,!1,!1,1),e=function(n,t,r){return t in r},o=Object(o));for(var a=0,c=u.length;c>a;a++){var f=u[a],l=o[f];e(l,f,o)&&(i[f]=l)}return i},m.omit=function(n,t,r){if(m.isFunction(t))t=m.negate(t);else{var e=m.map(S(arguments,!1,!1,1),String);t=function(n,t){return!m.contains(e,t)}}return m.pick(n,t,r)},m.defaults=_(m.allKeys,!0),m.create=function(n,t){var r=j(n);return t&&m.extendOwn(r,t),r},m.clone=function(n){return m.isObject(n)?m.isArray(n)?n.slice():m.extend({},n):n},m.tap=function(n,t){return t(n),n},m.isMatch=function(n,t){var r=m.keys(t),e=r.length;if(null==n)return!e;for(var u=Object(n),i=0;e>i;i++){var o=r[i];if(t[o]!==u[o]||!(o in u))return!1}return!0};var N=function(n,t,r,e){if(n===t)return 0!==n||1/n===1/t;if(null==n||null==t)return n===t;n instanceof m&&(n=n._wrapped),t instanceof m&&(t=t._wrapped);var u=s.call(n);if(u!==s.call(t))return!1;switch(u){case"[object RegExp]":case"[object String]":return""+n==""+t;case"[object Number]":return+n!==+n?+t!==+t:0===+n?1/+n===1/t:+n===+t;case"[object Date]":case"[object Boolean]":return+n===+t}var i="[object Array]"===u;if(!i){if("object"!=typeof n||"object"!=typeof t)return!1;var o=n.constructor,a=t.constructor;if(o!==a&&!(m.isFunction(o)&&o instanceof o&&m.isFunction(a)&&a instanceof a)&&"constructor"in n&&"constructor"in t)return!1}r=r||[],e=e||[];for(var c=r.length;c--;)if(r[c]===n)return e[c]===t;if(r.push(n),e.push(t),i){if(c=n.length,c!==t.length)return!1;for(;c--;)if(!N(n[c],t[c],r,e))return!1}else{var f,l=m.keys(n);if(c=l.length,m.keys(t).length!==c)return!1;for(;c--;)if(f=l[c],!m.has(t,f)||!N(n[f],t[f],r,e))return!1}return r.pop(),e.pop(),!0};m.isEqual=function(n,t){return N(n,t)},m.isEmpty=function(n){return null==n?!0:k(n)&&(m.isArray(n)||m.isString(n)||m.isArguments(n))?0===n.length:0===m.keys(n).length},m.isElement=function(n){return!(!n||1!==n.nodeType)},m.isArray=h||function(n){return"[object Array]"===s.call(n)},m.isObject=function(n){var t=typeof n;return"function"===t||"object"===t&&!!n},m.each(["Arguments","Function","String","Number","Date","RegExp","Error"],function(n){m["is"+n]=function(t){return s.call(t)==="[object "+n+"]"}}),m.isArguments(arguments)||(m.isArguments=function(n){return m.has(n,"callee")}),"function"!=typeof/./&&"object"!=typeof Int8Array&&(m.isFunction=function(n){return"function"==typeof n||!1}),m.isFinite=function(n){return isFinite(n)&&!isNaN(parseFloat(n))},m.isNaN=function(n){return m.isNumber(n)&&n!==+n},m.isBoolean=function(n){return n===!0||n===!1||"[object Boolean]"===s.call(n)},m.isNull=function(n){return null===n},m.isUndefined=function(n){return n===void 0},m.has=function(n,t){return null!=n&&p.call(n,t)},m.noConflict=function(){return u._=i,this},m.identity=function(n){return n},m.constant=function(n){return function(){return n}},m.noop=function(){},m.property=w,m.propertyOf=function(n){return null==n?function(){}:function(t){return n[t]}},m.matcher=m.matches=function(n){return n=m.extendOwn({},n),function(t){return m.isMatch(t,n)}},m.times=function(n,t,r){var e=Array(Math.max(0,n));t=b(t,r,1);for(var u=0;n>u;u++)e[u]=t(u);return e},m.random=function(n,t){return null==t&&(t=n,n=0),n+Math.floor(Math.random()*(t-n+1))},m.now=Date.now||function(){return(new Date).getTime()};var B={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;"},T=m.invert(B),R=function(n){var t=function(t){return n[t]},r="(?:"+m.keys(n).join("|")+")",e=RegExp(r),u=RegExp(r,"g");return function(n){return n=null==n?"":""+n,e.test(n)?n.replace(u,t):n}};m.escape=R(B),m.unescape=R(T),m.result=function(n,t,r){var e=null==n?void 0:n[t];return e===void 0&&(e=r),m.isFunction(e)?e.call(n):e};var q=0;m.uniqueId=function(n){var t=++q+"";return n?n+t:t},m.templateSettings={evaluate:/<%([\s\S]+?)%>/g,interpolate:/<%=([\s\S]+?)%>/g,escape:/<%-([\s\S]+?)%>/g};var K=/(.)^/,z={"'":"'","\\":"\\","\r":"r","\n":"n","\u2028":"u2028","\u2029":"u2029"},D=/\\|'|\r|\n|\u2028|\u2029/g,L=function(n){return"\\"+z[n]};m.template=function(n,t,r){!t&&r&&(t=r),t=m.defaults({},t,m.templateSettings);var e=RegExp([(t.escape||K).source,(t.interpolate||K).source,(t.evaluate||K).source].join("|")+"|$","g"),u=0,i="__p+='";n.replace(e,function(t,r,e,o,a){return i+=n.slice(u,a).replace(D,L),u=a+t.length,r?i+="'+\n((__t=("+r+"))==null?'':_.escape(__t))+\n'":e?i+="'+\n((__t=("+e+"))==null?'':__t)+\n'":o&&(i+="';\n"+o+"\n__p+='"),t}),i+="';\n",t.variable||(i="with(obj||{}){\n"+i+"}\n"),i="var __t,__p='',__j=Array.prototype.join,"+"print=function(){__p+=__j.call(arguments,'');};\n"+i+"return __p;\n";try{var o=new Function(t.variable||"obj","_",i)}catch(a){throw a.source=i,a}var c=function(n){return o.call(this,n,m)},f=t.variable||"obj";return c.source="function("+f+"){\n"+i+"}",c},m.chain=function(n){var t=m(n);return t._chain=!0,t};var P=function(n,t){return n._chain?m(t).chain():t};m.mixin=function(n){m.each(m.functions(n),function(t){var r=m[t]=n[t];m.prototype[t]=function(){var n=[this._wrapped];return f.apply(n,arguments),P(this,r.apply(m,n))}})},m.mixin(m),m.each(["pop","push","reverse","shift","sort","splice","unshift"],function(n){var t=o[n];m.prototype[n]=function(){var r=this._wrapped;return t.apply(r,arguments),"shift"!==n&&"splice"!==n||0!==r.length||delete r[0],P(this,r)}}),m.each(["concat","join","slice"],function(n){var t=o[n];m.prototype[n]=function(){return P(this,t.apply(this._wrapped,arguments))}}),m.prototype.value=function(){return this._wrapped},m.prototype.valueOf=m.prototype.toJSON=m.prototype.value,m.prototype.toString=function(){return""+this._wrapped},"function"==typeof define&&define.amd&&define("underscore",[],function(){return m})}).call(this);
window.wp=window.wp||{},function(a){var b="undefined"==typeof _wpUtilSettings?{}:_wpUtilSettings;wp.template=_.memoize(function(b){var c,d={evaluate:/<#([\s\S]+?)#>/g,interpolate:/\{\{\{([\s\S]+?)\}\}\}/g,escape:/\{\{([^\}]+?)\}\}(?!\})/g,variable:"data"};return function(e){return(c=c||_.template(a("#tmpl-"+b).html(),d))(e)}}),wp.ajax={settings:b.ajax||{},post:function(a,b){return wp.ajax.send({data:_.isObject(a)?a:_.extend(b||{},{action:a})})},send:function(b,c){var d,e;return _.isObject(b)?c=b:(c=c||{},c.data=_.extend(c.data||{},{action:b})),c=_.defaults(c||{},{type:"POST",url:wp.ajax.settings.url,context:this}),e=a.Deferred(function(b){c.success&&b.done(c.success),c.error&&b.fail(c.error),delete c.success,delete c.error,b.jqXHR=a.ajax(c).done(function(a){"1"!==a&&1!==a||(a={success:!0}),_.isObject(a)&&!_.isUndefined(a.success)?b[a.success?"resolveWith":"rejectWith"](this,[a.data]):b.rejectWith(this,[a])}).fail(function(){b.rejectWith(this,arguments)})}),d=e.promise(),d.abort=function(){return e.jqXHR.abort(),this},d}}}(jQuery);
(function($, wpreview, Cookies){
"use strict";
wpreview.initNotificationBar=function(){
if($('#hello-bar').length){
$('body').addClass('has-hello-bar');
}
$('#hello-bar.hello-bar--top:not(.hello-bar--floating)').prependTo('body');
if($('#hello-bar.hello-bar--top.hello-bar--floating').length){
$('body').css({ paddingTop: $('#hello-bar').height() + 10 });
}};
wpreview.getAnimateDuration=function(animation){
if(! animation){
return 0;
}
switch(animation){
case 'flipOutX':
case 'flipOutY':
case 'bounceIn':
case 'bounceOut':
return 750;
case 'hinge':
return 2000;
}
return 1000;
};
wpreview.openPopup=function(popup){
if(! popup){
popup='#wp-review-popup';
}
$.magnificPopup.open({
items: {
src: popup,
type: 'inline'
},
removalDelay: wpreview.getAnimateDuration(wpreview.popup.animation_out),
callbacks: {
beforeOpen: function(){
this.st.mainClass='animated ' + wpreview.popup.animation_in;
},
beforeClose: function(){
var $wrap=this.wrap,
$bg=$wrap.prev(),
$mfp=$wrap.add($bg);
$mfp.removeClass(wpreview.popup.animation_in).addClass(wpreview.popup.animation_out);
}}
});
};
wpreview.initPopup=function(){
if(! $('#wp-review-popup').length){
return;
}
var popupShown=false,
expiration=parseInt(wpreview.popup.expiration),
cookieName=wpreview.popup.cookie_name||'wpr-popup';
function canShowPopup(){
if(popupShown){
return false;
}
if(expiration&&Cookies.get(cookieName)){
return false;
}
if(wpreview.popup.screen_size_check&&$(window).width() <=parseInt(wpreview.popup.screen_width)){
return false;
}
return true;
}
function showPopup(){
wpreview.openPopup('#wp-review-popup');
popupShown=true;
if(expiration){
Cookies.set(cookieName, 1, {
expires: expiration
});
}}
if(wpreview.popup.show_on_load){
var delay=parseInt(wpreview.popup.delay) * 1000;
setTimeout(function(){
if(! canShowPopup()){
return;
}
showPopup();
}, delay);
}
if(wpreview.popup.show_on_reach_bottom&&$('#wp-review-content-bottom').length){
var offsetTop=$('#wp-review-content-bottom').offset().top;
$(window).on('scroll', function(){
if(! canShowPopup()){
return;
}
var scrollTop=$(window).scrollTop();
if(scrollTop >=offsetTop){
showPopup();
}});
}
if(wpreview.popup.exit_intent){
$(document).exitIntent(function(){
if(! canShowPopup()){
return;
}
showPopup();
});
}};
wpreview.loadReviews=function($el, options){
$el.html('<div class="loading"></div>');
function onSuccess(response){
$el.removeClass('js-reviews-placeholder loading').html(response);
};
function onError(response){
console.log(response);
};
wp.ajax.send('wp-review-load-reviews', {
success: onSuccess,
error: onError,
data: options
});
};
wpreview.ajaxReviewsLoading=function(){
$('.js-reviews-placeholder').each(function(){
var options=$(this).attr('data-options') ? JSON.parse($(this).attr('data-options')):{};
wpreview.loadReviews($(this), options);
});
$(document).on('click', '.reviews-pagination a', function(ev){
ev.preventDefault();
var $pagination, $reviews, options, page;
$pagination=$(this).closest('.reviews-pagination');
$reviews=$pagination.closest('.wp-reviews-list');
options=$reviews.attr('data-options') ? JSON.parse($reviews.attr('data-options')):{};
page=$pagination.attr('data-page') ? parseInt($pagination.attr('data-page')):1;
options.page=$(this).hasClass('previous') ?(page - 1):(page + 1);
options.no_cache=true;
wpreview.loadReviews($reviews, options);
});
};
wpreview.featuresRating=function($wrapper){
var data=$wrapper.data();
if(! data.rating){
return;
}
data.action='wpr-visitor-features-rating';
$.ajax ({
beforeSend: function(){
$wrapper.addClass('wp-review-loading');
},
data: data,
type: 'post',
url: wpreview.ajaxurl,
success: function(response){
$wrapper.removeClass('wp-review-loading');
if(typeof response!='object'){
response=JSON.parse(response);
}
if('ok'!=response.status){
console.error(response);
return;
}
response.html=response.html.replace('delay-animation', '');
$wrapper.closest('#review').replaceWith(response.html);
Cookies.set('wpr_visitor_has_reviewed_post_' + data.post_id, 1, {
expires: 315360000000 
});
},
error: function(response){
$wrapper.removeClass('wp-review-loading');
console.log(response);
}});
};
wpreview.initResponsiveTable=function(){
$('.comparison-table').stacktable();
};
wpreview.addVerifiedPurchase=function(){
$('.wp_review_comment.verified cite, .wp_review_comment.verified .fn').after('<em> ' + wpreview.verifiedPurchase + '</em>');
};
$(document).ready(function(){
wpreview.initNotificationBar();
wpreview.initPopup();
wpreview.ajaxReviewsLoading();
wpreview.initResponsiveTable();
wpreview.addVerifiedPurchase();
$('[data-wp-review-tabs] .tab-title:first-child').addClass('active');
$('[data-wp-review-tabs] .tab-content:first-of-type').fadeIn();
$('[data-wp-review-tabs] .tab-title button').on('click', function(ev){
ev.preventDefault();
var $btn, $tabs, href;
$btn=$(this);
$tabs=$btn.closest('[data-wp-review-tabs]');
href=$btn.attr('data-href');
$tabs.find('.tab-title').removeClass('active');
$btn.closest('.tab-title').addClass('active');
$tabs.find('.tab-content').hide();
$tabs.find(href).fadeIn();
});
$('#commentform').on('submit', function(ev){
$(this).find('.wpr-error').remove();
if($(this).hasClass('wpr-uncompleted-rating')){
$(this).append('<div class="wpr-error">' + wpreview.rateAllFeatures + '</div>');
ev.preventDefault();
}});
});
})(jQuery, window.wpreview||{}, Cookies);
jQuery(document).ready(function($){
$('.wp-review-comment-field.allowed-to-rate a').on('click', function(){
var $this=$(this),
$elem=$this.closest('.wp-review-comment-field');
if($elem.hasClass('allowed-to-rate')){
$elem.removeClass('has-not-rated-yet');
$elem.find('.review-result').css('width', parseInt($this.data('input-value'))*20+'%');
$elem.find('.wp_review_comment_rating').val($this.data('input-value'));
}});
if($('.review-wrapper').length){
$('.review-wrapper').wpr_appear().on('wpr_appear', function(event){
var $this=$(this);
if($this.hasClass('delay-animation')){
$this.removeClass('delay-animation');
if($this.find('.wp-review-circle-rating').length){
$this.find('.wp-review-circle-rating').each(function(index, el){
if($(el).closest('.wp-review-user-rating').length)
return true;
var initial_value=$(el).data('initial_value');
$({value: 0}).animate({value: initial_value}, {
duration: 2000,
easing:'swing',
step: function(){
$(el).val(Math.floor(this.value)).trigger('change');
},
complete: function(){
$(el).val(initial_value).trigger('change');
}});
});
}}
}).on('wpr_disappear', function(event){
var $this=$(this);
});
$(window).load(function(){
$.wpr_force_appear();
});
}
var $commentFeedback=$('.wp-review-feedback');
$commentFeedback.on('click', 'a', function(e){
var $this=$(this);
e.preventDefault();
if($this.hasClass('voted')||$this.siblings().hasClass('voted')||$commentFeedback.hasClass('processing')) return;
$.ajax({
type: 'POST',
url: wpreview.ajaxurl,
beforeSend: function(){
$commentFeedback.addClass('processing');
},
data: { action: 'mts_review_feedback', isHelpful: $this.data('value'), commentId: $this.data('comment-id') },
success: function(data){
$this.closest('.wp-review-feedback').find('a').removeClass('voted');
$this.addClass('voted').find('.feedback-count').text('('+data+')');
},
error: function(jqXHR){
alert(jqXHR.responseText);
},
complete: function(){
$commentFeedback.removeClass('processing');
}});
});
if($('#wp-review-comment-title-field').length){
$('#wp-review-comment-title-field').closest('form').addClass('wp-review-comment-form');
}
$(document).on('click', '.wp-review-comment-img-field a', function(e){
e.preventDefault();
$(this).parents('.wp-review-comment-form-photo').find('.hide').removeClass('hide');
$(this).parent().addClass('hide').find('input').val('');
return false;
});
$(document).on('change', '.wp-review-comment-attachment-source .input-file', function(e){
e.preventDefault();
var $this=$(this);
if($this.parents('.wp-review-comment-form-photo').find('#comment_image_spinner').length!=0){
return;
}
$this.parents('form').find('input[type="submit"]').attr('disabled', 'disabled');
$('<i id="comment_image_spinner" class="fa fa-spinner fa-spin"></i>').insertAfter($this.parent('p'));
var $fd=new FormData(),
files=$(this)[0].files[0];
$fd.append("files[]", files);
$fd.append('action', 'wpr-upload-comment-image');
$.ajax({
type: 'POST',
url: wpreview.ajaxurl,
processData: false,
contentType: false,
data: $fd,
success: function (response){
if(response){
$this.next('input').val(response);
}else{
alert('Something went wrong. Please upload different image.');
}
$this.parents('form').find('input[type="submit"]').removeAttr('disabled');
$this.parents('.wp-review-comment-form-photo').find('#comment_image_spinner').remove();
},
error: function(){
alert('Something went wrong. Please upload different image.');
$this.parents('form').find('input[type="submit"]').removeAttr('disabled');
$this.parents('.wp-review-comment-form-photo').find('#comment_image_spinner').remove();
}});
return false;
});
});
function wp_review_rate($elem){
var is_comment_rating=($elem.is('.wp-review-comment-rating-star')||!!$elem.closest('.wp-review-comment-rating-star').length);
if(is_comment_rating){
return '';
}
var rating=$elem.find('.wp-review-user-rating-val').val();
var postId=$elem.find('.wp-review-user-rating-postid').val();
var token=$elem.find('.wp-review-user-rating-nonce').val();
var $target=$elem;
if(! $target.is('.wp-review-user-rating'))
$target=$elem.closest('.wp-review-user-rating');
if(rating==0){
return '';
}
jQuery.ajax ({
beforeSend: function(){
$target.addClass('wp-review-loading');
},
data: { action: 'wp_review_rate', post_id: postId, nonce: token, review: rating },
type: 'post',
dataType: 'json',
url: wpreview.ajaxurl,
success: function(response){
$target.removeClass('wp-review-loading');
if(typeof response.html!=='undefined'&&response.html!=''){
$target.empty().append(response.html).addClass('has-rated').removeClass('wp-review-user-rating');
}
if(typeof response.rating_total!=='undefined'&&response.rating_total!=''){
$target.parent().find('.wp-review-user-rating-total').text(response.rating_total);
}
if(typeof response.rating_count!=='undefined'&&response.rating_count!=''){
$target.parent().find('.wp-review-user-rating-counter').text(response.rating_count);
}
if(response.awaiting_moderation!=undefined){
$target.parent().find('.user-total-wrapper .awaiting-response-wrapper').text(response.awaiting_moderation);
}
Cookies.set('wpr_visitor_has_reviewed_post_' + postId, 1, {
expires: 315360000000 
});
}});
};
(function (factory){
if(typeof exports==='object'){
module.exports=factory(require('jquery'));
}else if(typeof define==='function'&&define.amd){
define(['jquery'], factory);
}else{
factory(jQuery);
}}(function ($){
"use strict";
var k={},
max=Math.max,
min=Math.min;
k.c={};
k.c.d=$(document);
k.c.t=function (e){
return e.originalEvent.touches.length - 1;
};
k.o=function (){
var s=this;
this.o=null;
this.$=null;
this.i=null;
this.g=null;
this.v=null;
this.cv=null;
this.x=0;
this.y=0;
this.w=0;
this.h=0;
this.$c=null;
this.c=null;
this.t=0;
this.isInit=false;
this.fgColor=null;
this.pColor=null;
this.dH=null;
this.cH=null;
this.eH=null;
this.rH=null;
this.scale=1;
this.relative=false;
this.relativeWidth=false;
this.relativeHeight=false;
this.$div=null;
this.run=function (){
var cf=function (e, conf){
var k;
for (k in conf){
s.o[k]=conf[k];
}
s._carve().init();
s._configure()
._draw();
};
if(this.$.data('kontroled')) return;
this.$.data('kontroled', true);
this.extend();
this.o=$.extend({
min: this.$.data('min')!==undefined ? this.$.data('min'):0,
max: this.$.data('max')!==undefined ? this.$.data('max'):100,
stopper: true,
readOnly: this.$.data('readonly')||(this.$.attr('readonly')==='readonly'),
cursor: this.$.data('cursor')===true&&30
|| this.$.data('cursor')||0,
thickness: this.$.data('thickness')
&& Math.max(Math.min(this.$.data('thickness'), 1), 0.01)
|| 0.35,
lineCap: this.$.data('linecap')||'butt',
width: this.$.data('width')||200,
height: this.$.data('height')||200,
displayInput: this.$.data('displayinput')==null||this.$.data('displayinput'),
displayPrevious: this.$.data('displayprevious'),
fgColor: this.$.data('fgcolor')||'#87CEEB',
inputColor: this.$.data('inputcolor'),
font: this.$.data('font')||'Arial',
fontWeight: this.$.data('font-weight')||'bold',
inline: false,
step: this.$.data('step')||1,
rotation: this.$.data('rotation'),
draw: null,
change: null,
cancel: null,
release: null,
format: function(v){
return v;
},
parse: function (v){
return parseFloat(v);
}}, this.o
);
this.o.flip=this.o.rotation==='anticlockwise'||this.o.rotation==='acw';
if(!this.o.inputColor){
this.o.inputColor=this.o.fgColor;
}
if(this.$.is('fieldset')){
this.v={};
this.i=this.$.find('input');
this.i.each(function(k){
var $this=$(this);
s.i[k]=$this;
s.v[k]=s.o.parse($this.val());
$this.bind('change blur',
function (){
var val={};
val[k]=$this.val();
s.val(s._validate(val));
}
);
});
this.$.find('legend').remove();
}else{
this.i=this.$;
this.v=this.o.parse(this.$.val());
this.v===''&&(this.v=this.o.min);
this.$.bind('change blur',
function (){
s.val(s._validate(s.o.parse(s.$.val())));
}
);
}
!this.o.displayInput&&this.$.hide();
this.$c=$(document.createElement('canvas')).attr({
width: this.o.width,
height: this.o.height
});
this.$div=$('<div style="'
+ (this.o.inline ? 'display:inline;':'')
+ 'width:' + this.o.width + 'px;height:' + this.o.height + 'px;'
+ '"></div>');
this.$.wrap(this.$div).before(this.$c);
this.$div=this.$.parent();
if(typeof G_vmlCanvasManager!=='undefined'){
G_vmlCanvasManager.initElement(this.$c[0]);
}
this.c=this.$c[0].getContext ? this.$c[0].getContext('2d'):null;
if(!this.c){
throw {
name:        "CanvasNotSupportedException",
message:     "Canvas not supported. Please use excanvas on IE8.0.",
toString:    function(){return this.name + ": " + this.message}}
}
this.scale=(window.devicePixelRatio||1) / (
this.c.webkitBackingStorePixelRatio ||
this.c.mozBackingStorePixelRatio ||
this.c.msBackingStorePixelRatio ||
this.c.oBackingStorePixelRatio ||
this.c.backingStorePixelRatio||1
);
this.relativeWidth=this.o.width % 1!==0
&& this.o.width.indexOf('%');
this.relativeHeight=this.o.height % 1!==0
&& this.o.height.indexOf('%');
this.relative=this.relativeWidth||this.relativeHeight;
this._carve();
if(this.v instanceof Object){
this.cv={};
this.copy(this.v, this.cv);
}else{
this.cv=this.v;
}
this.$
.bind("configure", cf)
.parent()
.bind("configure", cf);
this._listen()
._configure()
._xy()
.init();
this.isInit=true;
this.$.val(this.o.format(this.v));
this._draw();
return this;
};
this._carve=function(){
if(this.relative){
var w=this.relativeWidth ?
this.$div.parent().width() *
parseInt(this.o.width) / 100
: this.$div.parent().width(),
h=this.relativeHeight ?
this.$div.parent().height() *
parseInt(this.o.height) / 100
: this.$div.parent().height();
this.w=this.h=Math.min(w, h);
}else{
this.w=this.o.width;
this.h=this.o.height;
}
this.$div.css({
'width': this.w + 'px',
'height': this.h + 'px'
});
this.$c.attr({
width: this.w,
height: this.h
});
if(this.scale!==1){
this.$c[0].width=this.$c[0].width * this.scale;
this.$c[0].height=this.$c[0].height * this.scale;
this.$c.width(this.w);
this.$c.height(this.h);
}
return this;
};
this._draw=function (){
var d=true;
s.g=s.c;
s.clear();
s.dH&&(d=s.dH());
d!==false&&s.draw();
};
this._touch=function (e){
var touchMove=function (e){
var v=s.xy2val(
e.originalEvent.touches[s.t].pageX,
e.originalEvent.touches[s.t].pageY
);
if(v==s.cv) return;
if(s.cH&&s.cH(v)===false) return;
s.change(s._validate(v));
s._draw();
};
this.t=k.c.t(e);
touchMove(e);
k.c.d
.bind("touchmove.k", touchMove)
.bind("touchend.k",
function (){
k.c.d.unbind('touchmove.k touchend.k');
s.val(s.cv);
}
);
return this;
};
this._mouse=function (e){
var mouseMove=function (e){
var v=s.xy2val(e.pageX, e.pageY);
if(v==s.cv) return;
if(s.cH&&(s.cH(v)===false)) return;
s.change(s._validate(v));
s._draw();
};
mouseMove(e);
k.c.d
.bind("mousemove.k", mouseMove)
.bind("keyup.k",
function (e){
if(e.keyCode===27){
k.c.d.unbind("mouseup.k mousemove.k keyup.k");
if(s.eH&&s.eH()===false)
return;
s.cancel();
}}
)
.bind("mouseup.k",
function (e){
k.c.d.unbind('mousemove.k mouseup.k keyup.k');
s.val(s.cv);
}
);
return this;
};
this._xy=function (){
var o=this.$c.offset();
this.x=o.left;
this.y=o.top;
return this;
};
this._listen=function (){
if(!this.o.readOnly){
this.$c
.bind("mousedown",
function (e){
e.preventDefault();
s._xy()._mouse(e);
}
)
.bind("touchstart",
function (e){
e.preventDefault();
s._xy()._touch(e);
}
);
this.listen();
}else{
this.$.attr('readonly', 'readonly');
}
if(this.relative){
$(window).resize(function(){
s._carve().init();
s._draw();
});
}
return this;
};
this._configure=function (){
if(this.o.draw) this.dH=this.o.draw;
if(this.o.change) this.cH=this.o.change;
if(this.o.cancel) this.eH=this.o.cancel;
if(this.o.release) this.rH=this.o.release;
if(this.o.displayPrevious){
this.pColor=this.h2rgba(this.o.fgColor, "0.4");
this.fgColor=this.h2rgba(this.o.fgColor, "0.6");
}else{
this.fgColor=this.o.fgColor;
}
return this;
};
this._clear=function (){
this.$c[0].width=this.$c[0].width;
};
this._validate=function (v){
var val=(~~ (((v < 0) ? -0.5:0.5) + (v/this.o.step))) * this.o.step;
return Math.round(val * 100) / 100;
};
this.listen=function (){};
this.extend=function (){};
this.init=function (){};
this.change=function (v){};
this.val=function (v){};
this.xy2val=function (x, y){};
this.draw=function (){};
this.clear=function (){ this._clear(); };
this.h2rgba=function (h, a){
var rgb;
h=h.substring(1,7);
rgb=[
parseInt(h.substring(0,2), 16),
parseInt(h.substring(2,4), 16),
parseInt(h.substring(4,6), 16)
];
return "rgba(" + rgb[0] + "," + rgb[1] + "," + rgb[2] + "," + a + ")";
};
this.copy=function (f, t){
for (var i in f){
t[i]=f[i];
}};};
k.Dial=function (){
k.o.call(this);
this.startAngle=null;
this.xy=null;
this.radius=null;
this.lineWidth=null;
this.cursorExt=null;
this.w2=null;
this.PI2=2*Math.PI;
this.extend=function (){
this.o=$.extend({
bgColor: this.$.data('bgcolor')||'#e4e4e4',
angleOffset: this.$.data('angleoffset')||0,
angleArc: this.$.data('anglearc')||360,
inline: true
}, this.o);
};
this.val=function (v, triggerRelease){
if(null!=v){
v=this.o.parse(v);
if(triggerRelease!==false
&& v!=this.v
&& this.rH
&& this.rH(v)===false){ return; }
this.cv=this.o.stopper ? max(min(v, this.o.max), this.o.min):v;
this.v=this.cv;
this.$.val(this.o.format(this.v));
this._draw();
}else{
return this.v;
}};
this.xy2val=function (x, y){
var a, ret;
a=Math.atan2(
x - (this.x + this.w2),
- (y - this.y - this.w2)
) - this.angleOffset;
if(this.o.flip){
a=this.angleArc - a - this.PI2;
}
if(this.angleArc!=this.PI2&&(a < 0)&&(a > -0.5)){
a=0;
}else if(a < 0){
a +=this.PI2;
}
ret=(a * (this.o.max - this.o.min) / this.angleArc) + this.o.min;
this.o.stopper&&(ret=max(min(ret, this.o.max), this.o.min));
return ret;
};
this.listen=function (){
var s=this, mwTimerStop,
mwTimerRelease,
mw=function (e){
e.preventDefault();
var ori=e.originalEvent,
deltaX=ori.detail||ori.wheelDeltaX,
deltaY=ori.detail||ori.wheelDeltaY,
v=s._validate(s.o.parse(s.$.val()))
+ (
deltaX > 0||deltaY > 0
? s.o.step
: deltaX < 0||deltaY < 0 ? -s.o.step:0
);
v=max(min(v, s.o.max), s.o.min);
s.val(v, false);
if(s.rH){
clearTimeout(mwTimerStop);
mwTimerStop=setTimeout(function (){
s.rH(v);
mwTimerStop=null;
}, 100);
if(!mwTimerRelease){
mwTimerRelease=setTimeout(function (){
if(mwTimerStop)
s.rH(v);
mwTimerRelease=null;
}, 200);
}}
},
kval,
to,
m=1,
kv={
37: -s.o.step,
38: s.o.step,
39: s.o.step,
40: -s.o.step
};
this.$
.bind("keydown",
function (e){
var kc=e.keyCode;
if(kc >=96&&kc <=105){
kc=e.keyCode=kc - 48;
}
kval=parseInt(String.fromCharCode(kc));
if(isNaN(kval)){
(kc!==13)
&& kc!==8 
&& kc!==9 
&& kc!==189 
&& (kc!==190
|| s.$.val().match(/\./))
&& e.preventDefault();
if($.inArray(kc,[37,38,39,40]) > -1){
e.preventDefault();
var v=s.o.parse(s.$.val()) + kv[kc] * m;
s.o.stopper&&(v=max(min(v, s.o.max), s.o.min));
s.change(s._validate(v));
s._draw();
to=window.setTimeout(function (){
m *=2;
}, 30);
}}
}
)
.bind("keyup",
function (e){
if(isNaN(kval)){
if(to){
window.clearTimeout(to);
to=null;
m=1;
s.val(s.$.val());
}}else{
(s.$.val() > s.o.max&&s.$.val(s.o.max))
|| (s.$.val() < s.o.min&&s.$.val(s.o.min));
}}
);
};
this.init=function (){
if(this.v < this.o.min
|| this.v > this.o.max){ this.v=this.o.min; }
this.$.val(this.v);
this.w2=this.w / 2;
this.cursorExt=this.o.cursor / 100;
this.xy=this.w2 * this.scale;
this.lineWidth=this.xy * this.o.thickness;
this.lineCap=this.o.lineCap;
this.radius=this.xy - this.lineWidth / 2;
this.o.angleOffset
&& (this.o.angleOffset=isNaN(this.o.angleOffset) ? 0:this.o.angleOffset);
this.o.angleArc
&& (this.o.angleArc=isNaN(this.o.angleArc) ? this.PI2:this.o.angleArc);
this.angleOffset=this.o.angleOffset * Math.PI / 180;
this.angleArc=this.o.angleArc * Math.PI / 180;
this.startAngle=1.5 * Math.PI + this.angleOffset;
this.endAngle=1.5 * Math.PI + this.angleOffset + this.angleArc;
var s=max(
String(Math.abs(this.o.max)).length,
String(Math.abs(this.o.min)).length,
2
) + 2;
this.o.displayInput
&& this.i.css({
'width':((this.w / 2 + 4) >> 0) + 'px',
'height':((this.w / 3) >> 0) + 'px',
'position':'absolute',
'vertical-align':'middle',
'margin-top':((this.w / 3) >> 0) + 'px',
'margin-left':'-' + ((this.w * 3 / 4 + 2) >> 0) + 'px',
'border':0,
'background':'none',
'font':this.o.fontWeight + ' ' + ((this.w / s) >> 0) + 'px ' + this.o.font,
'text-align':'center',
'color':this.o.inputColor||this.o.fgColor,
'padding':'0px',
'-webkit-appearance': 'none'
})||this.i.css({
'width': '0px',
'visibility': 'hidden'
});
};
this.change=function (v){
this.cv=v;
this.$.val(this.o.format(v));
};
this.angle=function (v){
return (v - this.o.min) * this.angleArc / (this.o.max - this.o.min);
};
this.arc=function (v){
var sa, ea;
v=this.angle(v);
if(this.o.flip){
sa=this.endAngle + 0.00001;
ea=sa - v - 0.00001;
}else{
sa=this.startAngle - 0.00001;
ea=sa + v + 0.00001;
}
this.o.cursor
&& (sa=ea - this.cursorExt)
&& (ea=ea + this.cursorExt);
return {
s: sa,
e: ea,
d: this.o.flip&&!this.o.cursor
};};
this.draw=function (){
var c=this.g,
a=this.arc(this.cv),
pa,
r=1;
c.lineWidth=this.lineWidth;
c.lineCap=this.lineCap;
if(this.o.bgColor!=="none"){
c.beginPath();
c.strokeStyle=this.o.bgColor;
c.arc(this.xy, this.xy, this.radius, this.endAngle - 0.00001, this.startAngle + 0.00001, true);
c.stroke();
}
if(this.o.displayPrevious){
pa=this.arc(this.v);
c.beginPath();
c.strokeStyle=this.pColor;
c.arc(this.xy, this.xy, this.radius, pa.s, pa.e, pa.d);
c.stroke();
r=this.cv==this.v;
}
c.beginPath();
c.strokeStyle=r ? this.o.fgColor:this.fgColor ;
c.arc(this.xy, this.xy, this.radius, a.s, a.e, a.d);
c.stroke();
};
this.cancel=function (){
this.val(this.v);
};};
$.fn.dial=$.fn.knob=function (o){
return this.each(function (){
var d=new k.Dial();
d.o=o;
d.$=$(this);
d.run();
}
).parent();
};}));
!function(a,b){"use strict";function c(){if(!e){e=!0;var a,c,d,f,g=-1!==navigator.appVersion.indexOf("MSIE 10"),h=!!navigator.userAgent.match(/Trident.*rv:11\./),i=b.querySelectorAll("iframe.wp-embedded-content");for(c=0;c<i.length;c++){if(d=i[c],!d.getAttribute("data-secret"))f=Math.random().toString(36).substr(2,10),d.src+="#?secret="+f,d.setAttribute("data-secret",f);if(g||h)a=d.cloneNode(!0),a.removeAttribute("security"),d.parentNode.replaceChild(a,d)}}}var d=!1,e=!1;if(b.querySelector)if(a.addEventListener)d=!0;if(a.wp=a.wp||{},!a.wp.receiveEmbedMessage)if(a.wp.receiveEmbedMessage=function(c){var d=c.data;if(d)if(d.secret||d.message||d.value)if(!/[^a-zA-Z0-9]/.test(d.secret)){var e,f,g,h,i,j=b.querySelectorAll('iframe[data-secret="'+d.secret+'"]'),k=b.querySelectorAll('blockquote[data-secret="'+d.secret+'"]');for(e=0;e<k.length;e++)k[e].style.display="none";for(e=0;e<j.length;e++)if(f=j[e],c.source===f.contentWindow){if(f.removeAttribute("style"),"height"===d.message){if(g=parseInt(d.value,10),g>1e3)g=1e3;else if(~~g<200)g=200;f.height=g}if("link"===d.message)if(h=b.createElement("a"),i=b.createElement("a"),h.href=f.getAttribute("src"),i.href=d.value,i.host===h.host)if(b.activeElement===f)a.top.location.href=d.value}else;}},d)a.addEventListener("message",a.wp.receiveEmbedMessage,!1),b.addEventListener("DOMContentLoaded",c,!1),a.addEventListener("load",c,!1)}(window,document);