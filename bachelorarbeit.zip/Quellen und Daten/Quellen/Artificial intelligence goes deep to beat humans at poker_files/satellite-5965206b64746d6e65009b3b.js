//console.log('hello box');
var hello_box = document.createElement("div");
hello_box.classList.add("layout-item", "box--standout");
hello_box.style.marginBottom = "30px";

var p1 = document.createTextNode("News from ");
hello_box.appendChild(p1);

var c1 = document.createElement("cite");
var c1t = document.createTextNode("Science");
c1.appendChild(c1t);   
hello_box.appendChild(c1);

var p2 = document.createTextNode(" has ");
hello_box.appendChild(p2);

var a1 = document.createElement("a");
a1.href = "//www.sciencemag.org/about/metered-access-faqs";
var b1 = document.createElement("b");
var b1t = document.createTextNode("introduced a metered paywall");
b1.appendChild(b1t);             
a1.appendChild(b1);   
hello_box.appendChild(a1);   
       
var div2 = document.createTextNode(". Full access to all news content is included in ");
hello_box.appendChild(div2);

var a2 = document.createElement("a");
a2.href = _satellite.getVar('paywall_hello_url');
var b2 = document.createElement("b");
var b2t = document.createTextNode("AAAS membership.");
b2.appendChild(b2t);             
a2.appendChild(b2);   
hello_box.appendChild(a2);

var paywall_div = document.getElementById('paywall-hello');
paywall_div.appendChild(hello_box); 
