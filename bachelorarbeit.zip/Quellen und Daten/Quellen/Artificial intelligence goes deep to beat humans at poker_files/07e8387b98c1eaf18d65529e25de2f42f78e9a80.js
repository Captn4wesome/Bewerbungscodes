hawkeye_target={"content": ["181116-WebinarTarget", "190214-Eppendorf", "030119-CYRUS", "030119-10X"], "madgex": [{"campaignid": 71, "jobcount": 61, "campaignname": "Computer Science"}]};
hawkeye_insert_madgex_widget(hawkeye_target.madgex);
