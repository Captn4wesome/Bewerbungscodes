_satellite.pushAsyncScript(function(event, target, $variables){
  /*var children = document.getElementsByClassName('article__body')[0].children;
var p_count = 1;

for(var i = 0; i < children.length; i++) {
  if(children[i].nodeName === "P") {
    if(p_count >= 3 && typeof p_index === "undefined") {
      if(children[i + 1].nodeName === "P") {
    		var p_index = i;        
      }
    }
    p_count++;
  }
}

if(typeof p_index !== "undefined") {
	var target = children[p_index];

  my_form=document.createElement('FORM');
  my_form.name='myForm';
  my_form.method='POST';
  my_form.action='http://pages.aaas.sciencepubs.org/newsletters/signup';
  my_form.setAttribute("id", "daily_news_sign_up");
  my_form.className="form-inline form-newsletter";

  my_h3=document.createElement('h3');
  my_h3_text=document.createTextNode('Sign up for our daily newsletter');
  my_h3.appendChild(my_h3_text); 
  my_h3.className="overline";

  my_form.appendChild(my_h3);  

  my_p=document.createElement('P');
	my_p.classList.add('priority-2');  
  my_p_text=document.createTextNode(_satellite.getVar('int_msg'));  
  my_p.appendChild(my_p_text); ;   
  
  my_form.appendChild(my_p);    

  my_tb=document.createElement('INPUT');
  my_tb.type='TEXT';
  my_tb.name='EmailAddress';
  my_tb.placeholder='Email Address';
  my_tb.classNam="newsletter-field";

  my_sub=document.createElement('INPUT');
  my_sub.type='SUBMIT';
  my_sub.value='Sign Up';
  my_sub.classNam="btn newsletter-submit";

  my_cont=document.createElement('P');
  my_cont.className="field-container--inline"; 
  my_cont.appendChild(my_tb);
  my_cont.appendChild(my_sub); 
  
  my_form.appendChild(my_cont); 

  my_pri=document.createElement('P');
  my_pri.setAttribute("class","priority-3");  
  var my_pri_text=document.createTextNode("You agree to share your email address with the publication. Information provided here is subject to Science's ");  
  var my_pri_a=document.createElement('A');  
  my_pri_a.setAttribute("href","http://www.sciencemag.org/about/privacy-policy");  
  var my_pri_a_text = document.createTextNode("privacy policy.");
  my_pri_a.appendChild(my_pri_a_text);  
  my_pri.appendChild(my_pri_text);   
  my_pri.appendChild(my_pri_a);   

  my_form.appendChild(my_pri);     
  
  my_hid1=document.createElement('INPUT');
  my_hid1.type='HIDDEN';
  my_hid1.name='35 Science Latest News and Headlines';
  my_hid1.value='true';

  my_hid2=document.createElement('INPUT');
  my_hid2.type='HIDDEN';
  my_hid2.name='__successPage';
  my_hid2.setAttribute("id", "__successPage");
  my_hid2.value='http://www.sciencemag.org/subscribe/thank-you';

  my_hid3=document.createElement('INPUT');
  my_hid3.type='HIDDEN';
  my_hid3.name='__errorPage';
  my_hid3.setAttribute("id", "__errorPage");
  my_hid3.value='http://www.sciencemag.org/subscribe/oops';

  my_hid4=document.createElement('INPUT');
  my_hid4.type='HIDDEN';
  my_hid4.name='__contextName';
  my_hid4.setAttribute("id", "__contextName");
  my_hid4.value='FormPost';

  my_hid5=document.createElement('INPUT');
  my_hid5.type='HIDDEN';
  my_hid5.name='__executionContext';
  my_hid5.setAttribute("id", "__executionContext");
  my_hid5.value='Post';      
  
  my_form.appendChild(my_hid1);
  my_form.appendChild(my_hid2);
  my_form.appendChild(my_hid3);
  my_form.appendChild(my_hid4);
  my_form.appendChild(my_hid5);  
  
  var interstitial=document.createElement('DIV');
  interstitial.classList.add('interstitial');
  interstitial.style.marginTop="10px";
  interstitial.style.padding="10px 0px";
  interstitial.style.borderTop="1px solid #DDD"; 
  interstitial.style.borderBottom="1px solid #DDD";
  
  interstitial.appendChild(my_form);
  
  target.appendChild(interstitial);
}*/
});
