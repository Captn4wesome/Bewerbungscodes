/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package championsleague0708;

/**
 *
 * @author captn4wesome
 */
public class Club {
    String name = "";
    String country = "";
    char group = ' ';
    int seed = 0;
    boolean drawn = false; //Ob in der Gruppenauslosung dieses Team schon gezogen wurde
    int goalsShot = 0;  //Tore geschossen
    int goalsTaken = 0; //Tore kassiert
    int goalsAway = 0;  //Auswärtstore
    int points = 0;     //Gruppenpunkte
    boolean sortFlag = false; //Flag, die aktiviert wird, falls der Club (vorerst) beim Sortieralgorithmus bereits einsortiert ist
    int position = 0;   //Tabellenplatz
    
    public Club(String clubName, String clubCountry, int clubSeed){
        this.name = clubName;
        this.country = clubCountry;
        this.seed = clubSeed;
        //Gruppe wird erst bei der Auslosung gesetzt
    }
    //Setter
    public void setGroup(char newGroup){
        this.group = newGroup;
    }
    public void setDrawn(boolean newBool){
        this.drawn = newBool;
    }
    //Kein Setter für Name, Seed und Country, da unveränderlich (Seed zumindest in der Saison)
    public void resetGoals(){
        //Tore werden zurückgesetzt, sobald eine Runde vorbei ist
        this.goalsShot = 0;
        this.goalsTaken = 0;
        this.goalsAway = 0;
    }
    public void increaseGoals(int goals){
        this.goalsShot += goals;
    }
    public void increaseGoalsAway(int goals){
        this.goalsShot += goals;
        this.goalsAway += goals;
    }
    public void increaseGoalsTaken(int goals){
        this.goalsTaken += goals;
    }
    public void increasePoints(int pointsWon){
        this.points += pointsWon;
    }
    public void setSortFlag(boolean flag){
        this.sortFlag = flag;
    }
    public void setPosition(int pos){
        this.position = pos;
    }
    
    //Getter
    public String getName(){
        return this.name;
    }
    public String getCountry(){
        return this.country;
    }
    public char getGroup(){
        return this.group;
    }
    public int getSeed(){
        return this.seed;
    }
    public boolean getDrawn(){
        return this.drawn;
    }
    public int getPoints(){
        return this.points;
    }
    public int getGoalsShot(){
        return this.goalsShot;
    }
    public int getGoalsTaken(){
        return this.goalsTaken;
    }
    public int getGoalsAway(){
        return this.goalsAway;
    }
    public boolean isSorted(){
        return this.sortFlag;
    }
    public int getPosition(){
        return this.position;
    }
    
}
