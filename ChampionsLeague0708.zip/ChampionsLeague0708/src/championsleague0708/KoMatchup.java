/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package championsleague0708;

/**
 *
 * @author captn4wesome
 */
public class KoMatchup {
    Club groupClubs[] = new Club[2];
    Match groupMatches[] = new Match[2]; //Weil 12 Gruppenspiele insgesamt; Historie wird für die Tiebreaker benötigt
    
    public KoMatchup(Club club1, Club club2){
        groupClubs[0] = club1; //Winner
        groupClubs[1] = club2; //Runner-Up
    }
    
    public String getClubName(int pos){
        return groupClubs[(pos-1)].getName();
    }
    public Club getClub(int pos){
        return groupClubs[(pos-1)];
    }
    
    //Setter
    public void setMatch(int matchID, Club homeClub, int homeGoals, Club awayClub, int awayGoals){
        //Hier wird ein Match aus der Gruppenphase im Array oben eingetragen
        groupMatches[matchID] = new Match(homeClub, homeGoals, awayClub, awayGoals);
    }
    public void setFirstClub(Club club1){
        groupClubs[0] = club1;
    }
    public void setSecondClub(Club club2){
        groupClubs[1] = club2;
    }
}
