
package championsleague0708;

/**
 *
 * @author captn4wesome
 */
public class main {
    static long sleepTimer = 1000;
    static Club clubs[] = new Club[32];
    static Group group[] = new Group[8];
    static KoMatchup matchup[] = new KoMatchup[8];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Zuerst werden die 32 qualifizierten Clubs initalisiert
        createDataBase();
        //Jetzt wird gelost
        drawGroups();
        //Sobald die Gruppen feststehen, fängt die Gruppenphase an
        playGroupPhase();
        //Jetzt beginnt die KO-Runde mit dem Achtelfinale
        drawEighthFinals();
        //Und dann können die Matches auch schon beginnen
        playEighthFinals();
        //Viertel- und Halbfinallose werden einfacher, weil keine Restriktionen mehr bei der Ziehung
        drawQuarterFinals();
        //Viertelfinale wird ausgespielt
        playQuarterFinals();
        //Neue Losung fürs Halbfinale
        drawSemiFinals();
        //Halbfinale
        playSemiFinals();
        //Fürs Finale muss nicht mehr gezogen werden, da ja schon eh nur noch zwei Teams über sind
        playFinals();
    }
    
    public static void createDataBase(){
        //Bei Datenbankeinträgen könnte man alle Clubs in ner for-Schleife initialisieren
        //So muss gehardcoded werden ;)
        clubs[0] = new Club("Juventus Turin", "Italien", 1);
        clubs[1] = new Club("FC Bayern München", "Deutschland", 2);
        clubs[2] = new Club("FC Brugge", "Belgien", 3);
        clubs[3] = new Club("Rapid Wien", "Österreich", 4);
        clubs[4] = new Club("FC Barcelona", "Spanien", 1);
        clubs[5] = new Club("Werder Bremen", "Deutschland", 2);
        clubs[6] = new Club("Udinese Calcio", "Italien", 3);
        clubs[7] = new Club("Panathinaikos Athen", "Griechenland", 4);
        clubs[8] = new Club("AC Mailand", "Italien", 1);
        clubs[9] = new Club("PSV Eindhoven", "Niederlande", 2);
        clubs[10] = new Club("FC Schalke 04", "Deutschland", 3);
        clubs[11] = new Club("Fenerbahce Istanbul", "Türkei", 4);
        clubs[12] = new Club("FC Liverpool", "England", 1);
        clubs[13] = new Club("FC Chelsea", "England", 2);
        clubs[14] = new Club("Betis Sevilla", "Spanien", 3);
        clubs[15] = new Club("RSC Anderlecht", "Belgien", 4);
        clubs[16] = new Club("Arsenal London", "England", 1);
        clubs[17] = new Club("Ajax Amsterdam", "Niederlande", 2);
        clubs[18] = new Club("FC Thun", "Schweiz", 3);
        clubs[19] = new Club("Sparta Prag", "Tschechien", 4);
        clubs[20] = new Club("FC Villareal", "Spanien", 1);
        clubs[21] = new Club("Benfica Lissabon", "Portugal", 2);
        clubs[22] = new Club("OSC Lille", "Frankreich", 3);
        clubs[23] = new Club("Manchester United", "England", 4);
        clubs[24] = new Club("Olympique Lyon", "Frankreich", 1);
        clubs[25] = new Club("Real Madrid", "Spanien", 2);
        clubs[26] = new Club("Rosenborg Trondheim", "Norwegen", 3);
        clubs[27] = new Club("Olympiacos Piräus", "Griechenland", 4);
        clubs[28] = new Club("Inter Mailand", "Italien", 1);
        clubs[29] = new Club("Glasgow Rangers", "Schottland", 2);
        clubs[30] = new Club("Artmedia Bratislava", "Slowakei", 3);
        clubs[31] = new Club("FC Porto", "Portugal", 4);
    }
    
    public static void drawGroups(){
        //Jetzt wird gelost
        int los = -1; //Zufallsvariabel, die für die Losziehung verwendet wird
        Club groupClub[] = new Club[4]; //Hilfsvariablen für den Konstruktor der Klasse "Group"
                                        //damit eine geloste Gruppe sofort gesetzt werden kann
        for(int h = 0; h < 4; h++){
            groupClub[h] = new Club(" ", " ", 0);
        }
        
        //Hier erstmal jede einzelne Gruppe, von A bis H
        for(int i = 0; i < 8; i++){
            //und hier die vier Teams jeder Gruppe; hier spielt der Seed eine Rolle, weil diese
            //Seeds den aktuellen Lostopf repräsentieren, aus dem gerade gezogen wird
            for(int j = 0; j < 4; j++){
                //Es wird gezogen
                los = ((int)(Math.random() * 32));
                if(clubs[los].getSeed() == (j+1) && !clubs[los].getDrawn()){
                    //der richtige Topf wurde gezogen UND die Mannschaft war noch im Topf vorhanden
                    //Falls noch kein Team aus der selben Nation vertreten ist, wird die Mannschaft
                    //hier gesetzt, ansonsten wird wieder neu gezogen
                    if(!(groupClub[0].getCountry().equals(clubs[los].getCountry())) && !(groupClub[1].getCountry().equals(clubs[los].getCountry())) && !(groupClub[2].getCountry().equals(clubs[los].getCountry())) && !(groupClub[3].getCountry().equals(clubs[los].getCountry()))){
                        //Mannschaft wird in die Gruppe gesetzt und Flag gesetzt, weil nicht mehr im Topf
                        groupClub[j] = clubs[los];
                        clubs[los].setGroup((char) (i+65)); //65 = 'A', 66 = 'B', etc.
                        clubs[los].setDrawn(true);
                    }else{
                        j--; //damit der Zug wiederholt wird
                    }
                }else{
                    j--; //damit der Zug wiederholt wird
                }
            }
            //Sobald alle 4 Mannschaften der aktuellen Gruppe ermittelt wurden, wird die Gruppe generiert
            //Die Hilfsvariablen zurückgesetzt, es kann für die neue Gruppe neu gelost werden
            group[i] = new Group(groupClub[0], groupClub[1], groupClub[2], groupClub[3]);
            for(int h = 0; h < 4; h++){
                groupClub[h] = new Club(" ", " ", 0);
            }
        }
        //Ab hier wird geprinted, sobald alle Gruppen fix sind
        System.out.println("---AUSLOSUNG DER GRUPPEN---\n");
        System.out.println("Gruppe A");
        System.out.println("-------------");
        System.out.println(group[0].getClubName(1)+"\n"+group[0].getClubName(2)+"\n"+group[0].getClubName(3)+"\n"+group[0].getClubName(4)+"\n\n");
        System.out.println("Gruppe B");
        System.out.println("-------------");
        System.out.println(group[1].getClubName(1)+"\n"+group[1].getClubName(2)+"\n"+group[1].getClubName(3)+"\n"+group[1].getClubName(4)+"\n\n");
        System.out.println("Gruppe C");
        System.out.println("-------------");
        System.out.println(group[2].getClubName(1)+"\n"+group[2].getClubName(2)+"\n"+group[2].getClubName(3)+"\n"+group[2].getClubName(4)+"\n\n");
        System.out.println("Gruppe D");
        System.out.println("-------------");
        System.out.println(group[3].getClubName(1)+"\n"+group[3].getClubName(2)+"\n"+group[3].getClubName(3)+"\n"+group[3].getClubName(4)+"\n\n");
        System.out.println("Gruppe E");
        System.out.println("-------------");
        System.out.println(group[4].getClubName(1)+"\n"+group[4].getClubName(2)+"\n"+group[4].getClubName(3)+"\n"+group[4].getClubName(4)+"\n\n");
        System.out.println("Gruppe F");
        System.out.println("-------------");
        System.out.println(group[5].getClubName(1)+"\n"+group[5].getClubName(2)+"\n"+group[5].getClubName(3)+"\n"+group[5].getClubName(4)+"\n\n");
        System.out.println("Gruppe G");
        System.out.println("-------------");
        System.out.println(group[6].getClubName(1)+"\n"+group[6].getClubName(2)+"\n"+group[6].getClubName(3)+"\n"+group[6].getClubName(4)+"\n\n");
        System.out.println("Gruppe H");
        System.out.println("-------------");
        System.out.println(group[7].getClubName(1)+"\n"+group[7].getClubName(2)+"\n"+group[7].getClubName(3)+"\n"+group[7].getClubName(4)+"\n\n");
    }
    
    public static void playGroupPhase(){
        System.out.println("---GRUPPENPHASE---\n------------------");
        for(int i = 0; i < 8; i++){
            System.out.println("Gruppe "+((char)(i+65))+"\n------------------");
            //für jede einzelne Gruppe werden nun alle Gruppenspiele simuliert, nach dem Schema der Regel 6.04
            playGroupMatch(group[i].getClub(2),group[i].getClub(3),0,i);
            playGroupMatch(group[i].getClub(4),group[i].getClub(1),1,i);
            System.out.println("");
            playGroupMatch(group[i].getClub(1),group[i].getClub(2),2,i);
            playGroupMatch(group[i].getClub(3),group[i].getClub(4),3,i);
            System.out.println("");
            playGroupMatch(group[i].getClub(3),group[i].getClub(1),4,i);
            playGroupMatch(group[i].getClub(2),group[i].getClub(4),5,i);
            System.out.println("");
            playGroupMatch(group[i].getClub(1),group[i].getClub(3),6,i);
            playGroupMatch(group[i].getClub(4),group[i].getClub(2),7,i);
            System.out.println("");
            playGroupMatch(group[i].getClub(3),group[i].getClub(2),8,i);
            playGroupMatch(group[i].getClub(1),group[i].getClub(4),9,i);
            System.out.println("");
            playGroupMatch(group[i].getClub(2),group[i].getClub(1),10,i);
            playGroupMatch(group[i].getClub(4),group[i].getClub(3),11,i);
            System.out.println("");
            //Anhand der Matches wird nun eine Tabelle ausgegeben
            System.out.println("---Tabelle Gruppe "+((char)(i+65))+"---");
            group[i].createFinalTable();
            /*System.out.println(group[i].getClub(1).getName()+" "+group[i].getClub(1).getPoints());
            System.out.println(group[i].getClub(2).getName()+" "+group[i].getClub(2).getPoints());
            System.out.println(group[i].getClub(3).getName()+" "+group[i].getClub(3).getPoints());
            System.out.println(group[i].getClub(4).getName()+" "+group[i].getClub(4).getPoints());*/
            System.out.println("------------------\n");
        }
    }
    
    public static void playGroupMatch(Club home, Club away, int matchNumber, int groupID){
        //Match wird ausgespielt
        int homeScore = ((int)(Math.random()*4));
        int awayScore = ((int)(Math.random()*4));
        System.out.println(home.getName()+" - "+away.getName()+" "+homeScore+":"+awayScore+"");
        //Tore werden in der Club-Statistik eingetragen
        home.increaseGoals(homeScore);
        home.increaseGoalsTaken(awayScore);
        away.increaseGoalsAway(awayScore);
        away.increaseGoalsTaken(homeScore);
        //Punkte werden vergeben
        if(homeScore > awayScore){
            home.increasePoints(3);
        }else if(awayScore > homeScore){
            away.increasePoints(3);
        }else{
            home.increasePoints(1);
            away.increasePoints(1);
        }
        //Zu guter Letzt werden die Matches noch festgehalten (für die Tiebreaker)
        group[groupID].setMatch(matchNumber, home, homeScore, away, awayScore);
    }
    
    public static void drawEighthFinals(){
        //Falls die Mannschaften weitergekommen sind, kommen sie wieder in den Lostopf
        //-->DrawFlag = false
        for(int i = 0; i < 32; i++){
            if(clubs[i].getPosition() < 3){
                clubs[i].setDrawn(false);
            }
        }
        //Ab hier werden nun Matchups generiert, die ähnlich wie Gruppen funktionieren,
        //nur gezielt für den Zweck von zwei Mannschaften, die im KO-System aufeinander treffen
        for(int h = 0; h < 8; h++){
            matchup[h] = new KoMatchup(null, null);
        }
        int los = -1;
        System.out.println("---ACHTELFINAL-AUSLOSUNG!---");
        //Und jetzt wird wieder gezogen, erstmal die Gruppensieger
        for(int i = 0; i < 8; i++){
            los = ((int)(Math.random()*32));
            if(!clubs[los].getDrawn() && clubs[los].getPosition() == 1){
                matchup[i].setFirstClub(clubs[los]);
                clubs[los].setDrawn(true);
            }else{
                i--; //Um nochmal zu ziehen
            }
        }
        //Und jetzt die Gruppenzweiten
        for(int i = 0; i < 8; i++){
            los = ((int)(Math.random()*32));
            //Nun wird der passende Gruppenzweite gesucht, und zwar die, die noch im Topf sind und NICHT in der selben Gruppe und Nation sind/waren
            if(!clubs[los].getDrawn() && clubs[los].getPosition() == 2 && !(matchup[i].getClub(1).getCountry().equals(clubs[los].getCountry())) && matchup[i].getClub(1).getGroup() != clubs[los].getGroup()){
                matchup[i].setSecondClub(clubs[los]);
                clubs[los].setDrawn(true);
                System.out.println(matchup[i].getClubName(1)+" - "+matchup[i].getClubName(2));
            }else{
                i--; //Um nochmal zu ziehen
            }
        }
        System.out.println("");
    }
    
    public static void playEighthFinals(){
        System.out.println("--------ACHTELFINALE--------");
        //Hier wird jedes Matchup gleich zweimal gespielt...Runner-Up beginnt mit Heimrecht
        for(int i = 0; i < 8; i++){
            //Erstmal Tore zurücksetzen (weil Auswärtstorregelung und Aggregate
            matchup[i].getClub(1).resetGoals();
            matchup[i].getClub(2).resetGoals();
            //jetzt die Spiele (Hin- und Rückrunde
            playKoMatch(matchup[i].getClub(2), matchup[i].getClub(1),i);
            playKoMatch(matchup[i].getClub(1), matchup[i].getClub(2),i);
            //Wer kommt weiter?
            if(matchup[i].getClub(1).getGoalsShot() == matchup[i].getClub(2).getGoalsShot()){
                if(matchup[i].getClub(1).getGoalsAway() == matchup[i].getClub(2).getGoalsAway()){
                    if(Math.random() < 0.5){
                        matchup[i].getClub(1).increaseGoals(1);
                        System.out.println(matchup[i].getClubName(1)+" erzielt noch ein Extrator und erreicht das Viertelfinale!");
                        matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs 1/4-Finale
                    }else{
                        matchup[i].getClub(2).increaseGoals(1);
                        System.out.println(matchup[i].getClubName(2)+" erzielt noch ein Extrator und erreicht das Viertelfinale!");
                        matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs 1/4-Finale
                    }
                }else if(matchup[i].getClub(1).getGoalsShot() > matchup[i].getClub(2).getGoalsShot()){
                    System.out.println(matchup[i].getClubName(1)+" erreicht das Viertelfinale!");
                    matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs 1/4-Finale
                }else{
                    System.out.println(matchup[i].getClubName(2)+" erreicht das Viertelfinale!");
                    matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs 1/4-Finale
                }
            }else if(matchup[i].getClub(1).getGoalsShot() > matchup[i].getClub(2).getGoalsShot()){
                System.out.println(matchup[i].getClubName(1)+" erreicht das Viertelfinale!");
                matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs 1/4-Finale
            }else{
                System.out.println(matchup[i].getClubName(2)+" erreicht das Viertelfinale!");
                matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs 1/4-Finale
            }
            System.out.println("");
        }
    }
    
    public static void playQuarterFinals(){
        System.out.println("--------VIERTELFINALE--------");
        //Hier wird jedes Matchup gleich zweimal gespielt...Runner-Up beginnt mit Heimrecht
        for(int i = 0; i < 4; i++){
            //Erstmal Tore zurücksetzen (weil Auswärtstorregelung und Aggregate
            matchup[i].getClub(1).resetGoals();
            matchup[i].getClub(2).resetGoals();
            //jetzt die Spiele (Hin- und Rückrunde
            playKoMatch(matchup[i].getClub(2), matchup[i].getClub(1),i);
            playKoMatch(matchup[i].getClub(1), matchup[i].getClub(2),i);
            //Wer kommt weiter?
            if(matchup[i].getClub(1).getGoalsShot() == matchup[i].getClub(2).getGoalsShot()){
                if(matchup[i].getClub(1).getGoalsAway() == matchup[i].getClub(2).getGoalsAway()){
                    if(Math.random() < 0.5){
                        matchup[i].getClub(1).increaseGoals(1);
                        System.out.println(matchup[i].getClubName(1)+" erzielt noch ein Extrator und erreicht das Halbfinale!");
                        matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs 1/2-Finale
                    }else{
                        matchup[i].getClub(2).increaseGoals(1);
                        System.out.println(matchup[i].getClubName(2)+" erzielt noch ein Extrator und erreicht das Halbfinale!");
                        matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs 1/2-Finale
                    }
                }else if(matchup[i].getClub(1).getGoalsShot() > matchup[i].getClub(2).getGoalsShot()){
                    System.out.println(matchup[i].getClubName(1)+" erreicht das Halbfinale!");
                    matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs 1/2-Finale
                }else{
                    System.out.println(matchup[i].getClubName(2)+" erreicht das Halbfinale!");
                    matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs 1/2-Finale
                }
            }else if(matchup[i].getClub(1).getGoalsShot() > matchup[i].getClub(2).getGoalsShot()){
                System.out.println(matchup[i].getClubName(1)+" erreicht das Halbfinale!");
                matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs 1/2-Finale
            }else{
                System.out.println(matchup[i].getClubName(2)+" erreicht das Halbfinale!");
                matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs 1/2-Finale
            }
            System.out.println("");
        }
    }
    
    public static void playSemiFinals(){
        System.out.println("--------HALBFINALE--------");
        //Hier wird jedes Matchup gleich zweimal gespielt...Runner-Up beginnt mit Heimrecht
        for(int i = 0; i < 2; i++){
            //Erstmal Tore zurücksetzen (weil Auswärtstorregelung und Aggregate
            matchup[i].getClub(1).resetGoals();
            matchup[i].getClub(2).resetGoals();
            //jetzt die Spiele (Hin- und Rückrunde
            playKoMatch(matchup[i].getClub(2), matchup[i].getClub(1),i);
            playKoMatch(matchup[i].getClub(1), matchup[i].getClub(2),i);
            //Wer kommt weiter?
            if(matchup[i].getClub(1).getGoalsShot() == matchup[i].getClub(2).getGoalsShot()){
                if(matchup[i].getClub(1).getGoalsAway() == matchup[i].getClub(2).getGoalsAway()){
                    if(Math.random() < 0.5){
                        matchup[i].getClub(1).increaseGoals(1);
                        System.out.println(matchup[i].getClubName(1)+" erzielt noch ein Extrator und erreicht das Finale!");
                        matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs Finale
                    }else{
                        matchup[i].getClub(2).increaseGoals(1);
                        System.out.println(matchup[i].getClubName(2)+" erzielt noch ein Extrator und erreicht das Finale!");
                        matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs Finale
                    }
                }else if(matchup[i].getClub(1).getGoalsShot() > matchup[i].getClub(2).getGoalsShot()){
                    System.out.println(matchup[i].getClubName(1)+" erreicht das Finale!");
                    matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs Finale
                }else{
                    System.out.println(matchup[i].getClubName(2)+" erreicht das Finale!");
                    matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs Finale
                }
            }else if(matchup[i].getClub(1).getGoalsShot() > matchup[i].getClub(2).getGoalsShot()){
                System.out.println(matchup[i].getClubName(1)+" erreicht das Finale!");
                matchup[i].getClub(1).setDrawn(false);//Kommt ins Lostopf fürs Finale
            }else{
                System.out.println(matchup[i].getClubName(2)+" erreicht das Finale!");
                matchup[i].getClub(2).setDrawn(false);//Kommt ins Lostopf fürs Finale
            }
            System.out.println("");
        }
    }
    
    public static void playFinals(){
        System.out.println("--------FINALE DER CHAMPIONS LEAGUE--------");
        System.out.println("-----------Sie sind die Besten!!!----------");
        //Finales Matchup generieren
        KoMatchup finals = new KoMatchup(null, null);
        //Die beiden Finalisten heraussuchen (Reihenfolge nach Implementierung, spielt eh keine Rolle
        for(int i = 0; i < 32; i++){
            if(!clubs[i].getDrawn()){
                finals.setFirstClub(clubs[i]);
                clubs[i].setDrawn(true);
                break;
            }
        }
        for(int i = 0; i < 32; i++){
            if(!clubs[i].getDrawn()){
                finals.setSecondClub(clubs[i]);
                clubs[i].setDrawn(true);
                break;
            }
        }
        //Erstmal Tore zurücksetzen (nur der Vollständigkeit halber)
        finals.getClub(1).resetGoals();
        finals.getClub(2).resetGoals();
        //Jetzt gehts ans Eingemachte....wer wird Champions-League-Sieger?
        int firstScore = ((int)(Math.random()*4));
        int secondScore = ((int)(Math.random()*4));
        System.out.println(finals.getClubName(1)+" - "+finals.getClubName(2)+" "+firstScore+":"+secondScore);
        if(firstScore == secondScore){
            if(Math.random() < 0.5){
                System.out.println("AUS, AUS nach einer packenden Verlängerung!!!");
                System.out.println(finals.getClubName(1)+" ist neuer Champions-League-Sieger!!!");
            }else{
                System.out.println("AUS, AUS nach einer packenden Verlängerung!!!");
                System.out.println(finals.getClubName(2)+" ist neuer Champions-League-Sieger!!!");
            }
        }else if(firstScore > secondScore){
            System.out.println("AUS, AUS...Das Spiel ist aus!!!");
            System.out.println(finals.getClubName(1)+" ist neuer Champions-League-Sieger!!!");
        }else{
            System.out.println("AUS, AUS...Das Spiel ist aus!!!");
            System.out.println(finals.getClubName(2)+" ist neuer Champions-League-Sieger!!!");
        }            
    }
    
    public static void playKoMatch(Club first, Club second, int matchID){
        //Match wird ausgespielt
        int homeScore = ((int)(Math.random()*4));
        int awayScore = ((int)(Math.random()*4));
        System.out.println(first.getName()+" - "+second.getName()+" "+homeScore+":"+awayScore+"");
        //Tore werden in der Club-Statistik eingetragen
        first.increaseGoals(homeScore);
        first.increaseGoalsTaken(awayScore);
        second.increaseGoalsAway(awayScore);
        second.increaseGoalsTaken(homeScore);
    }
    
    public static void drawQuarterFinals(){
        //Ab hier werden nun Matchups generiert, die ähnlich wie Gruppen funktionieren,
        //nur gezielt für den Zweck von zwei Mannschaften, die im KO-System aufeinander treffen
        matchup = new KoMatchup[4];
        for(int h = 0; h < 4; h++){
            matchup[h] = new KoMatchup(null, null);
        }
        int los = -1;
        System.out.println("---VIERTELFINAL-AUSLOSUNG!---");
        //Hier werden die ersten Teams der 4 Viertelfinal-Partien ausgelost
        for(int i = 0; i < 4; i++){
            los = ((int)(Math.random()*32));
            if(!clubs[los].getDrawn()){
                matchup[i].setFirstClub(clubs[los]);
                clubs[los].setDrawn(true);
            }else{
                i--; //Um nochmal zu ziehen
            }
        }
        //Und jetzt die zweiten
        for(int i = 0; i < 4; i++){
            los = ((int)(Math.random()*32));
            if(!clubs[los].getDrawn()){
                matchup[i].setSecondClub(clubs[los]);
                clubs[los].setDrawn(true);
                System.out.println(matchup[i].getClubName(1)+" - "+matchup[i].getClubName(2));
            }else{
                i--; //Um nochmal zu ziehen
            }
        }
        System.out.println("");
    }
    
    public static void drawSemiFinals(){
        //Ab hier werden nun Matchups generiert, die ähnlich wie Gruppen funktionieren,
        //nur gezielt für den Zweck von zwei Mannschaften, die im KO-System aufeinander treffen
        matchup = new KoMatchup[2];
        for(int h = 0; h < 2; h++){
            matchup[h] = new KoMatchup(null, null);
        }
        int los = -1;
        System.out.println("---HALBFINAL-AUSLOSUNG!---");
        //Hier werden die ersten Teams der 4 Viertelfinal-Partien ausgelost
        for(int i = 0; i < 2; i++){
            los = ((int)(Math.random()*32));
            if(!clubs[los].getDrawn()){
                matchup[i].setFirstClub(clubs[los]);
                clubs[los].setDrawn(true);
            }else{
                i--; //Um nochmal zu ziehen
            }
        }
        //Und jetzt die zweiten
        for(int i = 0; i < 2; i++){
            los = ((int)(Math.random()*32));
            if(!clubs[los].getDrawn()){
                matchup[i].setSecondClub(clubs[los]);
                clubs[los].setDrawn(true);
                System.out.println(matchup[i].getClubName(1)+" - "+matchup[i].getClubName(2));
            }else{
                i--; //Um nochmal zu ziehen
            }
        }
        System.out.println("");
    }
    
}
