/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package championsleague0708;
//Platzhalter für die Matches, speziell in der Gruppenphase....eigentlich nur nötig, für die ersten 3 Tiebreaker
/**
 *
 * @author captn4wesome
 */
public class Match {
    Club home;
    Club away;
    int homeScore;
    int awayScore;
    
    public Match(Club homeClub, int homeGoals, Club awayClub, int awayGoals){
        this.home = homeClub;
        this.away = awayClub;
        this.homeScore = homeGoals;
        this.awayScore = awayGoals;
    }
    
    //Getter (Setter werden nicht gebraucht, da die Spiele schon gelaufen sind)
    public Club getHomeClub(){
        return this.home;
    }
    public Club getAwayClub(){
        return this.away;
    }
    public int getHomeScore(){
        return this.homeScore;
    }
    public int getAwayScore(){
        return this.awayScore;
    }
}
