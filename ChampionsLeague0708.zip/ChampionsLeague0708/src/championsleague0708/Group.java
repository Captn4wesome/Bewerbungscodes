/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package championsleague0708;
/**
 *
 * @author captn4wesome
 */
public class Group {
    Club groupClubs[] = new Club[4];
    Match groupMatches[] = new Match[12]; //Weil 12 Gruppenspiele insgesamt; Historie wird für die Tiebreaker benötigt
    
    public Group(Club club1, Club club2, Club club3, Club club4){
        groupClubs[0] = club1;
        groupClubs[1] = club2;
        groupClubs[2] = club3;
        groupClubs[3] = club4;
    }
    
    public void createFinalTable(){
        Club[] finalRanking = new Club[4]; //Platzhalter für fertige Tabelle(sortiert)
        int pos = 0; //Laufvariable für das Sortieren in der Tabelle
        int equalPoints = 0; //Zähler für Teams, die die selbe Punktzahl haben
        int maxPoints = 0;
        //Als erstes wird das Maximum an Punkten ermittelt und danach sortiert, bis Tabelle vorerst voll ist
        while(finalRanking[3] == null){
            maxPoints = 0;
            for(int i = 0; i < 4; i++){
                if(groupClubs[i].getPoints() > maxPoints && !groupClubs[i].isSorted()){
                    maxPoints = groupClubs[i].getPoints();
                }
            }
            //Dann werden diese Mannschaften entsprechend sortiert
            for(int i = 0; i < 4; i++){
                if(groupClubs[i].getPoints() == maxPoints){
                    finalRanking[pos] = groupClubs[i];
                    groupClubs[i].setSortFlag(true);
                    pos++;
                }
            }
        }
        /*
            An dieser Stelle müssten jetzt die ganzen Tie-Breaker kommen!
            Da ich aber zunächst die KO-Phase fertig machen will, bevor ich hierhin
            zurückkomme, funktioniert nur das Seeding (durch die Implementierung) als
            Breaker. Dieser Kommentar dient als Platzhalter für die restlichen...
        */
        //zum Schluss wird die fertige Tabelle erst ausgedruckt
        for(int j = 0; j < 4; j++){
            System.out.println(finalRanking[j].getName()+"\t"+finalRanking[j].getPoints()+"  "+finalRanking[j].getGoalsShot()+":"+finalRanking[j].getGoalsTaken()+" Tore");
            //In dem Schritt wird nun auch die endgültige Position in der Gruppe als Club-Variable gespeichert, was für das Achtelfinal-Los, ne Rollen spielen wird
            finalRanking[j].setPosition(j+1);
        }
        //return finalRanking;
    }
    
    //Getter
    public String getClubName(int seed){
        return groupClubs[(seed-1)].getName();
    }
    public Club getClub(int seed){
        return groupClubs[(seed-1)];
    }
    
    //Setter
    public void setMatch(int matchID, Club homeClub, int homeGoals, Club awayClub, int awayGoals){
        //Hier wird ein Match aus der Gruppenphase im Array oben eingetragen
        groupMatches[matchID] = new Match(homeClub, homeGoals, awayClub, awayGoals);
    }

}
